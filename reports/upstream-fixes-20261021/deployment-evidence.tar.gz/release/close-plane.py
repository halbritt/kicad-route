"""Close exactly the authorized seven work items after release proof is retained."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

MAIN = Path('/home/halbritt/git/kicad-route')
Q = MAIN / 'build/agent497-upstream-adoption'
PROJECT = '79dc75bd-db64-41d2-a919-fe92ec510642'
DONE = '52afe24c-af0a-465e-8b50-3bba0d7fe1be'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=MAIN, text=True).strip()


def command(argv, dest):
    assert not dest.exists(), 'Do not replay an uncertain external write: ' + str(dest)
    result = subprocess.run(argv, text=True, capture_output=True)
    dest.write_text(result.stdout)
    dest.with_suffix('.stderr').write_text(result.stderr)
    assert result.returncode == 0, (argv, result.stderr, result.stdout)
    reply = json.loads(result.stdout)
    assert reply['ok'], reply
    return reply


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    assert git('rev-parse', 'HEAD') == args.expected_head == git('rev-parse', 'origin/main')
    assert not git('status', '--porcelain')
    report = MAIN / 'reports/upstream-fixes-20261021'
    acceptance = json.loads((report / 'verification.json').read_text())
    assert acceptance['status'] == 'PASS'
    deployment = json.loads((report / 'deployment/independent-verification.json').read_text())
    assert deployment['status'] == 'PASS'
    cleanup = json.loads((report / 'cleanup.json').read_text())
    assert cleanup['status'] == 'PASS'
    assert git('rev-parse', 'HEAD:src') == acceptance['shipping_source_tree']
    items = json.loads((Q / 'issues.json').read_text())
    items.append({'id': '9d131282-5b40-42a7-9d4d-b56cf38c3c1e', 'identifier': 'KICADROUTE-89'})
    assert len(items) == 7 and len({item['id'] for item in items}) == 7
    output = Q / 'plane-closure'
    output.mkdir(exist_ok=True)
    prefix = ['plane', '--no-resolve', '-p', PROJECT]
    rows = []
    for item in items:
        key, identifier = item['id'], item['identifier']
        text = (f'Completed and locally deployed from source commit {acceptance["integrated_source_commit"]}; '
                f'owned builtin source {acceptance["engine_source_sha256"]}. '
                'The six selective upstream ports and test-only follow-up are integrated on pushed main. '
                'All 48 declared Archon attempts passed native validation, completion, preservation and '
                'the unchanged 1.10 wall/GNU-RSS/process-tree-RSS gates. The full 816 collected tests '
                'plus six subtests passed with zero skips; two strict native repeats passed. '
                'Fresh installed-main generation, offline doctor with canaries and two recorded native '
                'repeats passed independent raw verification. Original failed and one-skip runs are retained. '
                'Owned temporary containers, images and worktrees are removed. '
                'Proof: reports/upstream-fixes-20261021/README.md and verification.json; '
                f'report commit {args.expected_head}. See the report for per-family limits and parser CPU tradeoff.')
        (output / (identifier + '-comment-request.json')).write_text(json.dumps({'item': key, 'text': text}, indent=2) + '\n')
        command(prefix + ['comment', 'add', key, '--text', text], output / (identifier + '-comment.json'))
        command(prefix + ['issue', 'update', key, '--state', DONE], output / (identifier + '-update.json'))
        response = command(prefix + ['issue', 'get', key, '--fields', 'id,name,state,sequence_id'],
                           output / (identifier + '-readback.json'))
        data = response['data']
        state = data['state']
        state = state['id'] if isinstance(state, dict) else state
        assert data['id'] == key and state == DONE and data['sequence_id'] == int(identifier.rsplit('-', 1)[1])
        rows.append({'identifier': identifier, 'id': key, 'state': state,
                     'readback_sha256': hashlib.sha256((output / (identifier + '-readback.json')).read_bytes()).hexdigest()})
        print(identifier + ' Done/readback verified', flush=True)
    (output / 'summary.json').write_text(json.dumps({'status': 'PASS', 'report_commit': args.expected_head, 'items': rows}, indent=2) + '\n')


if __name__ == '__main__':
    main()
