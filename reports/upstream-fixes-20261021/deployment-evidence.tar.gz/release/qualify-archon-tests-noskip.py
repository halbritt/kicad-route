"""Run ordinary full smoke and strict recorded repeats in a separate test container."""
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path('/testwork/candidate')
STATE = Path('/testwork/state-candidate')
OUT = Path('/test-evidence')
HEAD = 'f42b8796de2006bae147e65340da99462b5fd9be'
SOURCE = '89a2efbf53057a0694b3cef365ec3acdc01b61f5f57d86bfbe8a62dc8f11db6d'
PACKAGES = ['numpy==2.5.4', 'pillow==13.0.0', 'scipy==1.18.1', 'shapely==2.2.0']


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, default=str) + '\n')


def configure():
    os.environ.update(KICAD_ROUTE_STATE=str(STATE), PYTHONDONTWRITEBYTECODE='1',
                      KICAD_ROUTE_LEDGER='off', CARGO_HOME='/testwork/cargo',
                      HOME='/testwork/home', UV_CACHE_DIR='/testwork/home/.cache/uv')
    sys.path.insert(0, str(ROOT / 'src'))
    from kicad_route import engine, statemanifest
    os.environ['KICAD_ROUTE_WHEEL_RUNTIME'] = str(engine.GENERATION / 'venv')
    return engine, statemanifest


def preflight():
    engine, statemanifest = configure()
    prep = json.loads((OUT / 'preparation/preparation.json').read_text())
    assert prep['status'] == 'PASS', prep
    assert os.getuid() == 1000
    assert subprocess.check_output(['git', '-C', ROOT, 'rev-parse', 'HEAD'], text=True).strip() == HEAD
    assert engine.source_sha256(engine.SOURCE_ROOT) == SOURCE
    assert engine.source_sha256() == SOURCE
    assert importlib.metadata.version('pytest') == '9.1.0'
    assert importlib.metadata.version('jsonschema') == '4.26.0'
    assert statemanifest.venv_packages((engine.GENERATION / 'venv')) == PACKAGES
    if not (STATE / 'vendor/freerouting').exists():
        shutil.copytree(OUT / 'freerouting', STATE / 'vendor/freerouting', symlinks=True)
    assert os.readlink(STATE / 'vendor/freerouting/current') == 'v2.5.0'
    assert sha(STATE / 'vendor/freerouting/current/freerouting-2.5.0.jar') == 'f6f51bb02245e8e717f9359bd260cc9c5c0b1bc0acc8b7cb2cd5b8ffeb5de3c7'
    manifest = statemanifest.refresh(state=STATE, written_by='archon-test-preparation')
    manifest = statemanifest.read(STATE)
    assert not statemanifest.verify(manifest, STATE)
    subprocess.run(['bwrap', '--ro-bind', '/', '/', '--unshare-net', '--', 'true'], check=True)
    assert os.environ['KICAD_ROUTE_WHEEL_RUNTIME'] == str(engine.GENERATION / 'venv')
    assert Path(os.environ['KICAD_ROUTE_WHEEL_RUNTIME']).is_dir()
    assert Path('/usr/share/kicad/footprints/Package_SO.pretty/SOIC-8_3.9x4.9mm_P1.27mm.kicad_mod').is_file()
    for package, version in [('pip', '24.0'), ('setuptools', '68.1.2'), ('wheel', '0.42.0')]:
        assert importlib.metadata.version(package) == version
    mirror = ['bwrap', '--die-with-parent', '--new-session', '--unshare-pid', '--unshare-ipc', '--unshare-uts',
              '--ro-bind', '/', '/', '--proc', '/proc', '--dev', '/dev', '--unshare-net', '--', 'true']
    probe = subprocess.run(mirror, capture_output=True, text=True)
    write('full-namespace-capability.json', {'argv': mirror, 'exit_code': probe.returncode, 'stdout': probe.stdout, 'stderr': probe.stderr, 'uid': os.getuid()})
    assert probe.returncode == 0
    tools = {}
    for name, argv in [('java', ['java', '-version']), ('pytest', ['/usr/bin/python3', '-m', 'pytest', '--version']),
                       ('python', ['/usr/bin/python3', '--version']), ('native', ['kicad-cli', '--version']),
                       ('rustc', ['rustc', '-vV']), ('uv', ['uv', '--version'])]:
        result = subprocess.run(argv, capture_output=True, text=True, check=True)
        tools[name] = {'argv': argv, 'stdout': result.stdout, 'stderr': result.stderr}
    assert '25.0.' in tools['java']['stderr']
    assert tools['native']['stdout'].strip() == '10.0.7'
    with (OUT / 'collection.log').open('w') as stream:
        result = subprocess.run(['/usr/bin/python3', '-m', 'pytest', '--collect-only', '-q', '-p', 'no:cacheprovider', str(ROOT / 'tests')],
                                cwd=OUT, stdout=stream, stderr=subprocess.STDOUT)
    assert result.returncode == 0
    nodes = [line.strip() for line in (OUT / 'collection.log').read_text().splitlines() if '::test_' in line and not line.startswith(' ')]
    assert len(nodes) == len(set(nodes)) == 816, len(nodes)
    write('collection-nodes.json', nodes)
    shutil.copy2(STATE / 'manifest.json', OUT / 'test-installed-manifest-before.json')
    receipt = {'status': 'READY', 'time_utc': now(), 'uid': os.getuid(), 'gid': os.getgid(),
               'source_commit': HEAD, 'source_sha256': SOURCE, 'generation': str(engine.GENERATION),
               'module_sha256': sha(statemanifest.extension_module((engine.GENERATION / 'venv'))), 'packages': PACKAGES,
               'manifest_sha256': sha(STATE / 'manifest.json'), 'drift': [], 'tools': tools,
               'bwrap_actual_uid_probe': 'PASS', 'collected_node_count': len(nodes),
               'wheel_runtime': os.environ['KICAD_ROUTE_WHEEL_RUNTIME'], 'full_proc_dev_namespace_probe': 'PASS',
               'affinity': sorted(os.sched_getaffinity(0)), 'nice': os.getpriority(os.PRIO_PROCESS, 0),
               'scheduler': os.sched_getscheduler(0), 'helper_sha256': sha(__file__),
               'freerouting_jar_sha256': sha(STATE / 'vendor/freerouting/current/freerouting-2.5.0.jar')}
    write('wheel-runtime-capability.json', {'status': 'READY', 'source_commit': HEAD, 'source_sha256': SOURCE,
          'generation': str(engine.GENERATION), 'wheel_runtime': os.environ['KICAD_ROUTE_WHEEL_RUNTIME'],
          'module_sha256': receipt['module_sha256'], 'numeric_packages': PACKAGES,
          'environmental_skip_audit': 'zero-skip-prerequisite-audit.json',
          'helper_sha256': sha(__file__), 'explicit_opt_in': True})
    write('test-readiness.json', receipt)
    print(json.dumps(receipt, indent=2), flush=True)


def qualify():
    engine, statemanifest = configure()
    ready = json.loads((OUT / 'test-readiness.json').read_text())
    assert ready['status'] == 'READY' and ready['source_sha256'] == engine.source_sha256() == SOURCE
    assert not statemanifest.verify(statemanifest.read(STATE), STATE)
    commands = [('smoke', ['/usr/bin/python3', str(ROOT / 'bin/kicad-route'), '--out', str(OUT / 'full-smoke'), 'smoke']),
                ('determinism', ['/usr/bin/python3', str(ROOT / 'bin/kicad-route'), '--out', str(OUT / 'repeat'),
                                 'determinism', '--backend', 'builtin', '--runs', '2', '--budget', '180',
                                 '--default-clearance', '0.4', '--record'])]
    assert not (OUT / 'full-smoke').exists() and not (OUT / 'repeat').exists()
    write('commands.json', {'state': STATE, 'source_commit': HEAD, 'source_sha256': SOURCE,
                            'commands': dict(commands), 'additional_environment': {'KICAD_ROUTE_WHEEL_RUNTIME': os.environ['KICAD_ROUTE_WHEEL_RUNTIME']}, 'environment': {k: os.environ[k] for k in
                            ['HOME', 'CARGO_HOME', 'UV_CACHE_DIR', 'KICAD_ROUTE_STATE', 'KICAD_ROUTE_LEDGER', 'PYTHONDONTWRITEBYTECODE']}})
    phases = []
    for name, argv in commands:
        phase = {'name': name, 'argv': argv, 'started_utc': now(), 'status': 'RUNNING'}
        phases.append(phase)
        write('phase-status.json', {'phases': phases})
        with (OUT / (name + '.log')).open('w') as stream:
            result = subprocess.run(argv, cwd=ROOT, env=os.environ, stdout=stream, stderr=subprocess.STDOUT)
        phase.update(exit_code=result.returncode, finished_utc=now(), status='PASS' if result.returncode == 0 else 'FAIL')
        phase['drift'] = statemanifest.verify(statemanifest.read(STATE), STATE)
        write('phase-status.json', {'phases': phases})
        print(json.dumps(phase), flush=True)
    gates = []
    def gate(name, passed, observed):
        gates.append({'name': name, 'passed': bool(passed), 'observed': observed})
    summaries = sorted((OUT / 'full-smoke/smoke').glob('*/summary.json'))
    summary_path = summaries[-1] if summaries else None
    summary = json.loads(summary_path.read_text()) if summary_path else {}
    gate('ordinary_full_smoke', summary.get('status') == 'PASS' and summary.get('pytest_exit_code') == 0, summary)
    suites = list(ET.parse(summary_path.parent / 'junit.xml').getroot().iter('testsuite')) if summary_path else []
    counts = {k: sum(int(s.get(k, 0)) for s in suites) for k in ['tests', 'failures', 'errors', 'skipped']}
    gate('complete_no_skip_population', counts['tests'] >= 816 and all(counts[k] == 0 for k in ['failures', 'errors', 'skipped']), counts)
    repeats = sorted((OUT / 'repeat/determinism').glob('*/determinism.json'))
    record = json.loads(repeats[-1].read_text()) if repeats else {}
    gate('strict_recorded_repeat', record.get('reproducible') is True and record.get('recorded_in') == str(STATE / 'manifest.json')
         and len(record.get('runs', [])) == 2 and not record.get('record_error'), record)
    tools = []
    for index, run in enumerate(record.get('runs', []), 1):
        path = Path(run['run_dir'])
        path = path if path.is_absolute() else OUT / 'repeat' / path
        result = json.loads((path / 'result.json').read_text())
        tools.append(result.get('tool_identity', {}).get('backend'))
        gate(f'repeat_{index}_native', result['exit_code'] == 0 and result['process']['status'] == 'PASS'
             and result['routing']['status'] == 'COMPLETE' and result['validation']['status'] == 'PASS'
             and not run.get('wall_clock_stop'),
             {'result': str(path / 'result.json'), 'sha256': sha(path / 'result.json'), 'exit_code': result['exit_code'],
              'process': result['process']['status'], 'routing': result['routing']['status'], 'validation': result['validation']['status'],
              'tool_identity': result.get('tool_identity')})
    gate('same_executed_backend', len(tools) == 2 and tools[0] == tools[1] and bool(tools[0]), tools)
    manifest = statemanifest.read(STATE)
    gate('same_generation', str(engine.GENERATION) == ready['generation'], str(engine.GENERATION))
    gate('source_unchanged', engine.source_sha256() == SOURCE == manifest['krt']['source_sha256'], manifest['krt']['source_sha256'])
    gate('manifest_drift', not statemanifest.verify(manifest, STATE), statemanifest.verify(manifest, STATE))
    shutil.copy2(STATE / 'manifest.json', OUT / 'test-installed-manifest-after.json')
    receipt = {'status': 'PASS' if all(g['passed'] for g in gates) and all(p['status'] == 'PASS' for p in phases) else 'FAIL',
               'finished_utc': now(), 'source_commit': HEAD, 'source_sha256': SOURCE, 'generation': str(engine.GENERATION),
               'phases': phases, 'gates': gates, 'manifest_sha256': sha(STATE / 'manifest.json')}
    write('qualification-receipt.json', receipt)
    print(json.dumps(receipt, indent=2), flush=True)
    return 0 if receipt['status'] == 'PASS' else 1


if __name__ == '__main__':
    if sys.argv[1:] == ['--preflight']:
        preflight()
    elif sys.argv[1:] == ['--qualify']:
        raise SystemExit(qualify())
    else:
        raise SystemExit('use --preflight or --qualify')
