"""Retain the verified CAS as one deterministic gzip stream in bounded parts."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

Q = Path('/home/halbritt/git/kicad-route/build/agent497-upstream-adoption')
SOURCE = Q / 'archon-tests-export'
DEST = Q / 'report-staging'
INDEX_SHA = 'aa8582f641d6be7753e96e8acd282ec1ff8362c53947569ca17359915737843c'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1 << 20), b''):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    index = SOURCE / 'test-evidence-index.json'
    assert sha(index) == INDEX_SHA
    files = sorted(path for path in SOURCE.rglob('*') if path.is_file())
    assert len(files) == 7964 and not any(path.is_symlink() for path in files)
    expected = {path.relative_to(SOURCE).as_posix(): {'sha256': sha(path), 'size': path.stat().st_size}
                for path in files}
    stream = Q / 'test-evidence.tar.gz'
    assert not stream.exists() and not list(DEST.glob('test-evidence.tar.gz.part*'))
    with stream.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=1, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for path in files:
                    info = tarfile.TarInfo('test-evidence-cas/' + path.relative_to(SOURCE).as_posix())
                    info.size, info.mode = path.stat().st_size, 0o644
                    with path.open('rb') as data:
                        archive.addfile(info, data)
    count = 0
    with tarfile.open(stream, mode='r:gz') as archive:
        for member in archive:
            assert member.isfile() and member.name.startswith('test-evidence-cas/')
            relative = member.name.removeprefix('test-evidence-cas/')
            assert relative in expected
            data = archive.extractfile(member)
            digest = hashlib.sha256()
            for chunk in iter(lambda: data.read(1 << 20), b''):
                digest.update(chunk)
            assert digest.hexdigest() == expected[relative]['sha256']
            assert member.size == expected[relative]['size']
            count += 1
    assert count == len(files)
    parts = []
    with stream.open('rb') as source:
        while chunk := source.read(80 * 1024 * 1024):
            path = DEST / f'test-evidence.tar.gz.part{len(parts) + 1:02d}'
            path.write_bytes(chunk)
            assert path.stat().st_size < 90 * 1024 * 1024
            parts.append({'path': path.name, 'size': len(chunk), 'sha256': sha(path)})
    joined = hashlib.sha256()
    for part in parts:
        with (DEST / part['path']).open('rb') as data:
            for chunk in iter(lambda: data.read(1 << 20), b''):
                joined.update(chunk)
    assert joined.hexdigest() == sha(stream)
    receipt = {'schema': 'kicad-route/retained-test-archive/1', 'status': 'PASS',
               'index_sha256': INDEX_SHA, 'regular_files_verified': count,
               'uncompressed_bytes': sum(row['size'] for row in expected.values()),
               'gzip_stream_sha256': sha(stream), 'gzip_stream_bytes': stream.stat().st_size,
               'parts': parts,
               'reconstruct': 'cat test-evidence.tar.gz.part* > test-evidence.tar.gz; tar -xzf test-evidence.tar.gz',
               'scope': 'All verified CAS bytes and profile-scoped locators retained. Every tar member rehashed before splitting; concatenated parts match the verified gzip stream.'}
    (DEST / 'test-evidence-archive.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2), flush=True)


if __name__ == '__main__':
    main()
