#!/usr/bin/env python3
"""Verify an immutable profile-scoped test CAS against an externally observed index hash."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def safe(root, relative):
    part = PurePosixPath(relative)
    require(not part.is_absolute() and '..' not in part.parts and str(part) == relative,
            'unsafe or noncanonical retained path')
    path = root / relative
    require(path.resolve().is_relative_to(root.resolve()) and not path.is_symlink(), 'retained path escapes root')
    return path


def verify(root, expected):
    root = Path(root)
    indexpath = root / 'test-evidence-index.json'
    require(sha(indexpath) == expected, 'external index digest mismatch')
    index = json.loads(indexpath.read_text())
    require(index['schema'] == 'kicad-route/profile-scoped-test-cas/1' and index['status'] == 'PASS'
            and index['omissions'] == [], 'unexpected index schema/status/omissions')
    expected_names = ['original-failed', 'sandbox-correction', 'one-skip-nonaccepting', 'final-passed']
    require([p['name'] for p in index['profiles']] == expected_names, 'profile population/order differs')
    blobs, paths = {}, {'test-evidence-index.json'}
    for blob in index['blobs']:
        digest = blob['sha256']
        require(len(digest) == 64 and all(c in '0123456789abcdef' for c in digest)
                and digest not in blobs and blob['retained'] == 'blobs/' + digest, 'invalid duplicate blob identity')
        path = safe(root, blob['retained'])
        require(path.is_file() and path.stat().st_size == blob['bytes'] < 90 * 1024 * 1024
                and sha(path) == digest, 'blob size/hash/cap differs')
        blobs[digest] = blob
        paths.add(blob['retained'])
    for item in index['transport_artifacts']:
        path = safe(root, item['retained'])
        require(sha(path) == item['sha256'], 'transport control hash differs')
        paths.add(item['retained'])
    require(index['helper_sha256'] == next(p['sha256'] for p in index['transport_artifacts']
                if p['retained'] == 'provenance/export-archon-tests.py'), 'exporter hash binding differs')
    profile_maps, represented = {}, 0
    for profile in index['profiles']:
        require(profile['omissions'] == [], 'profile omitted evidence')
        mapping = {}
        for item in profile['entries']:
            source = PurePosixPath(item['source'])
            require(source.is_absolute() and '..' not in source.parts and str(source) == item['source']
                    and item['source'] not in mapping, 'unsafe/duplicate original locator')
            mapping[item['source']] = item
            if item['kind'] in ('file', 'hardlink'):
                blob = blobs[item['sha256']]
                require(item['bytes'] == blob['bytes'] and item['retained'] == blob['retained'], 'entry/blob binding differs')
                represented += item['bytes']
            else:
                require(item['kind'] in ('directory', 'symlink', 'special_metadata_only'), 'unknown metadata type')
        profile_maps[profile['name']] = mapping
    require(len(blobs) == index['blob_count'] and sum(b['bytes'] for b in blobs.values()) == index['unique_payload_bytes']
            and represented == index['represented_regular_file_bytes'], 'derived CAS counts differ')
    actual = {str(path.relative_to(root)) for path in root.rglob('*') if path.is_file() or path.is_symlink()}
    require(actual == paths, 'unexpected/missing retained regular files')
    final = profile_maps['final-passed']
    proofs = {}
    for name in ['qualification-receipt.json', 'independent-verification.json', 'wheel-runtime-verification.json']:
        item = final['/test-evidence/' + name]
        value = json.loads(safe(root, item['retained']).read_text())
        require(value['status'] == 'PASS', 'final proof is not PASS')
        proofs[name] = item['sha256']
    independent = json.loads(safe(root, final['/test-evidence/independent-verification.json']['retained']).read_text())
    require(independent['expected_node_count'] == 816 and independent['source_commit'] ==
            'f42b8796de2006bae147e65340da99462b5fd9be', 'final proof population/source differs')
    return {'schema': 'kicad-route/test-cas-retained-verification/1', 'status': 'PASS', 'index_sha256': expected,
            'index': str(indexpath), 'profile_entry_counts': {k: len(v) for k, v in profile_maps.items()},
            'blob_count': len(blobs), 'unique_payload_bytes': index['unique_payload_bytes'],
            'represented_regular_file_bytes': represented, 'max_blob_bytes': max(b['bytes'] for b in blobs.values()),
            'all_blobs_rehashed': True, 'all_original_locator_bindings_checked': True,
            'final_proof_sha256': proofs, 'helper_sha256': sha(Path(__file__))}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--index-sha256', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    require(not args.out.exists(), 'refusing to overwrite retained verification')
    result = verify(args.root, args.index_sha256)
    args.out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
