"""Additional zero-offset native routing controls for the keepout repair."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

MAIN = Path('/home/halbritt/git/kicad-route')
Q = MAIN / 'build/agent497-upstream-adoption'
OUT = Q / 'single-ended-control-fixed'
PRIMARY = Path('/home/halbritt/.cache/agent-worktrees/kicad-route/agent497-upstream-primary')
STATE = Q / 'state-candidate'
SOURCE = '89a2efbf53057a0694b3cef365ec3acdc01b61f5f57d86bfbe8a62dc8f11db6d'
os.environ.update(KICAD_ROUTE_STATE=str(STATE), PYTHONDONTWRITEBYTECODE='1',
                  KICAD_ROUTE_KEEPOUT_OUT=str(OUT),
                  KICAD_ROUTE_KEEPOUT_FIXTURE=str(PRIMARY / 'fixtures/diff_keepouts/lvds_converter_dualclk.kicad_pcb'))
sys.path.insert(0, str(MAIN / 'src'))
from kicad_route import common, engine

generation = common.router_generation()
root = generation / 'router'
assert engine.source_sha256(root) == SOURCE
sys.path[:0] = [str(root / 'py_router'), str(root / 'tests')]
import test_diff_keepout_member_clearance as control


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert not OUT.exists(), 'Do not overwrite a previous control'
    OUT.mkdir()
    rows = []
    for kind in ('native', 'user'):
        board = Path(control._fixture(kind))
        routed = board.with_name('single-ended.kicad_pcb')
        argv = [str(generation / 'venv/bin/python'), str(root / 'py_router/route.py'), str(board),
                '--output', str(routed), '--nets', '/CLK+', '--escalation', 'off',
                '--fab-tier', 'standard', '--strict-sizes', '--no-fix-drc-settings']
        if kind == 'user':
            argv.append('--keepout')
        log = board.with_name('route.log')
        with log.open('w') as output:
            result = subprocess.run(argv, cwd=root, env=os.environ, stdout=output,
                                    stderr=subprocess.STDOUT, timeout=900)
        assert result.returncode == 0, log
        assert routed.is_file()
        parsed = control._quiet(control.parse_kicad_pcb, routed)
        net = next(i for i, n in parsed.nets.items() if n.name == '/CLK+')
        count = sum(s.net_id == net for s in parsed.segments)
        assert count > 0, 'Single-ended route must actually produce copper'
        gap = control._gaps(str(routed), '/CLK+')
        assert gap[0 if kind == 'native' else 1] > 0, gap
        prohibited = control._kicad_items_not_allowed(str(routed))
        assert prohibited == 0
        row = {'kind': kind, 'argv': argv, 'exit_code': result.returncode,
               'input': str(board), 'input_sha256': sha(board), 'board': str(routed),
               'board_sha256': sha(routed), 'log': str(log), 'net': '/CLK+',
               'routed_segment_count': count, 'copper_gap_mm': gap[0],
               'centreline_gap_mm': gap[1], 'native_items_not_allowed': prohibited,
               'native_drc': str(routed) + '.drc.json'}
        rows.append(row)
        print(json.dumps(row), flush=True)
    receipt = {'status': 'PASS', 'engine_source_sha256': SOURCE, 'generation': str(generation),
               'controls': rows,
               'scope': 'Real single-ended zero-extra-offset route.py controls for both area kinds. Native rule area has actual KiCad items_not_allowed check; User.2 uses geometry oracle. Other unrelated LVDS findings are retained, not declared clean. No benchmark or production source changes.'}
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')


if __name__ == '__main__':
    main()
