#!/usr/bin/env python3
"""Inspect installed-main proof without routing, tests, installation or state writes."""
import argparse
import ast
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys

sys.dont_write_bytecode = True
SOURCE = '89a2efbf53057a0694b3cef365ec3acdc01b61f5f57d86bfbe8a62dc8f11db6d'
PINS = ['numpy==2.5.4', 'pillow==13.0.0', 'scipy==1.18.1', 'shapely==2.2.0']
MAIN = Path('/home/halbritt/git/kicad-route')
SCHEMA = 'kicad-route/independent-deployment-verification/1'


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'missing/nonregular artifact: ' + str(path))
    return json.loads(path.read_text())


def artifact(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'missing/nonregular artifact: ' + str(path))
    return {'path': str(path), 'sha256': sha(path)}


def relative_path(value, base):
    path = PurePosixPath(value)
    require(not path.is_absolute() and '..' not in path.parts and str(path) not in ('', '.'),
            'unsafe run-relative grading/reference locator: ' + str(value))
    actual = base / str(path)
    require(actual.resolve().is_relative_to(base.resolve()), 'run-relative locator escapes via symlink')
    return actual


def locator(value, cwd):
    path = Path(value)
    return path if path.is_absolute() else cwd / path


def git(repo, *args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(repo), *args], text=True).strip()


def doctor_check(report, before, manifest_sha, generation, head):
    require(report['schema'] == 'kicad-route/doctor/1' and report['kind'] == 'doctor' and
            report['offline'] is True and report['canary'] is True and
            report['status'] == 'PASS' and report['exit_code'] == 0 and report['required_failed'] == [],
            'ordinary offline doctor/canary did not pass')
    checks = report['checks']
    require(checks and len({c['check'] for c in checks}) == len(checks) and
            all(type(c['required']) is bool and c['status'] in ('PASS', 'FAIL', 'NOT_RUN', 'UNSUPPORTED') for c in checks),
            'malformed/duplicate doctor checks')
    require(any(c['required'] for c in checks) and all(c['status'] == 'PASS' for c in checks if c['required']),
            'a required doctor check did not pass')
    require(report['state_manifest']['sha256'] == manifest_sha, 'doctor did not inspect installed pre-record manifest')
    for key in ('builtin', 'krt'):
        backend = report['versions'][key]
        require(backend['source_sha256'] == SOURCE and backend['commit'] == head and
                backend['runtime']['generation'] == str(generation), 'doctor inspected another build/generation')
    return {'required': [c['check'] for c in checks if c['required']],
            'optional': [c for c in checks if not c['required']],
            'optional_statuses_are_not_required_gates': True}


def backend_identity(before):
    k = before['krt']
    return {'name': 'builtin', 'tag': k['describe'], 'version': k['version'],
            'grid_router_version': k['grid_router_version'], 'source_sha256': SOURCE,
            'extension_module_sha256': k['extension_module']['sha256'],
            'venv_python_version': k['venv']['python_version'],
            'venv_packages_sha256': k['venv']['packages_sha256']}


def strict_command(result, repo, generation):
    names = {'KRT_FLAGS', 'KRT_ENV', 'KRT_PROTECT_EXISTING_FLAGS', 'KRT_PROTECT_EXISTING_ENV'}
    tree = ast.parse((repo / 'src/kicad_route/cli.py').read_text())
    flags = {n.targets[0].id: ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign) and
             len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and n.targets[0].id in names}
    require(set(flags) == names, 'strict adapter constants missing')
    prefix = [str(generation / 'venv/bin/python'), str(generation / 'router/py_router/route.py')]
    commands = [c for c in result['process']['commands'] if c.get('argv', [])[:2] == prefix]
    require(len(commands) == 1, 'actual builtin backend command missing/ambiguous')
    command = commands[0]; argv = command['argv']
    require(all(flag in argv for flag in flags['KRT_FLAGS'] + flags['KRT_PROTECT_EXISTING_FLAGS']),
            'strict/protected-copper worker flag missing')
    for flag, value in (('--escalation', 'off'), ('--fab-tier', 'standard')):
        require(argv.count(flag) == 1 and argv[argv.index(flag) + 1] == value, 'strict worker policy differs')
    environment = {**flags['KRT_ENV'], **flags['KRT_PROTECT_EXISTING_ENV']}
    require(all(command.get('env', {}).get(k) == v for k, v in environment.items()), 'strict worker environment differs')
    return {'argv': argv, 'strict_environment': environment}


def native_records(result, run, cwd, repo, evidence_module):
    validation = result['validation']; evidence = result['evidence']
    require(result['exit_code'] == 0 and result['process']['status'] == 'PASS' and
            result['routing']['status'] == 'COMPLETE' and result['routing']['unconnected_in_scope'] == 0 and
            validation['status'] == 'PASS' and validation['reasons'] == [], 'raw repeat native outcome not clean/complete')
    require(validation['rules_files']['not_loaded'] == [] and validation['parity_performed'] is True and
            validation['drc']['new_violations']['count'] == validation['drc']['new_parity']['count'] == 0,
            'raw repeat did not pass unchanged original-rule/native parity grading')
    require(validation['preservation'] and all(s == 'PASS' for s in validation['preservation'].values()),
            'native preservation failed/missing')
    board = locator(result['candidate']['board'], cwd)
    require(board.resolve().is_relative_to(run.resolve()), 'candidate board outside its run')
    require(sha(board) == validation['candidate_board_sha256'] == validation['validated_board_sha256'] ==
            evidence['candidate_board_sha256'], 'native/evidence hashes do not bind final board')
    require(evidence.get('candidate_hash_basis') == 'post-refill', 'candidate hash basis is not final native board')
    records = evidence['records']
    required = {'attempt.json', 'validate/preservation.json', 'validate/new-findings.json',
                'validate/candidate-drc.json', 'validate/candidate-facts.json', 'validate/pour-integrity.json'}
    require(required <= set(records), 'required raw native grading records missing')
    for name, expected in records.items():
        require(sha(relative_path(name, run)) == expected, 'native grading record hash differs: ' + name)
    rows = read(run / 'validate/preservation.json')
    require(rows and len({r['check'] for r in rows}) == len(rows) and
            {r['check']: r['status'] for r in rows} == validation['preservation'], 'raw preservation differs from result')
    findings = read(run / 'validate/new-findings.json')
    require(findings['violations'] == [] and findings['schematic_parity'] == [], 'raw native new findings not empty')
    facts = read(run / 'validate/candidate-facts.json')
    require(evidence_module.copper_signature(facts) == evidence['candidate_copper_signature'],
            'raw grading facts do not reconstruct recorded copper geometry')
    commands = validation['drc_commands']
    require(commands and all(c['exit_code'] == 0 for c in commands) and
            any('--refill-zones' in c['argv'] for c in commands) and
            any('--severity-all' in c['argv'] and '--schematic-parity' in c['argv'] for c in commands),
            'native refill/final DRC/parity command missing or failed')
    for command in commands:
        argv = command['argv']
        require(argv[:3] == ['kicad-cli', 'pcb', 'drc'] and locator(argv[-1], cwd).resolve() == board.resolve(),
                'native command graded another board')
        read(locator(argv[argv.index('-o') + 1], cwd)); artifact(locator(command['log'], cwd))
    attempt = read(run / 'attempt.json'); ref = relative_path(attempt['reference_dir'], run)
    require(attempt['backend'] == 'builtin' and evidence['reference_files'], 'reference provenance missing')
    for name, expected in evidence['reference_files'].items():
        require(sha(relative_path(name, ref)) == expected, 'original reference file hash differs')
    require(evidence['input_fingerprint'] == attempt['input_fingerprint'] == result['input']['fingerprint'],
            'raw original-input fingerprints differ')
    grading = result['input']['baseline']['identity']
    require(set(grading['grading']) == {'baselinecache.py', 'cli.py', 'pour.py', 'kicad/pour.py', 'contract.py'} and
            set(grading['result_schemas']) == {'result-1.json', 'result-2.json'}, 'baseline grader source inventory incomplete')
    for name, expected in grading['grading'].items():
        require(sha(relative_path(name, repo / 'src/kicad_route')) == expected, 'native baseline grader code changed')
    for name, expected in grading['result_schemas'].items():
        require(sha(relative_path(name, repo / 'schemas')) == expected, 'native baseline grading schema changed')
    return {'result': artifact(run / 'result.json'), 'final_board': artifact(board),
            'native_grading_records_verified': len(records), 'reference_files_verified': len(evidence['reference_files']),
            'copper_geometry_reconstructed': evidence['candidate_copper_signature']}


def verify(args):
    repo = args.repo.resolve(); state = args.state.resolve(); dest = args.deployment.resolve(); cwd = repo
    require(git(repo, 'rev-parse', 'HEAD') == args.expected_main == git(repo, 'rev-parse', 'origin/main') and
            git(repo, 'branch', '--show-current') == 'main' and not git(repo, 'status', '--porcelain'),
            'installed source is not exact clean pushed main')
    require(git(repo, 'rev-parse', 'HEAD:src') == args.expected_source_tree, 'shipping source tree differs')
    os.environ['KICAD_ROUTE_STATE'] = str(state); os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    sys.path.insert(0, str(repo / 'src'))
    from kicad_route import common, engine, statemanifest, determinism, evidence
    require(Path(common.TOOL_ROOT).resolve() == repo and common.STATE == state, 'verifier imported wrong checkout/state')
    require(sys.version.split()[0] == '3.12.3', 'deployment verifier must use system Python3.12.3')
    generation = common.router_generation(state)  # fresh selected-pointer lookup, not cached engine.GENERATION
    require(generation == args.expected_generation.resolve(), 'fresh selected installed generation differs')
    current = statemanifest.read(state); before_path = dest / 'installed-manifest-before-checks.json'; before = read(before_path)
    manifest_path = state / 'manifest.json'; before_sha = sha(before_path); current_sha = sha(manifest_path)
    require(current and not statemanifest.schema_problems(current) and not statemanifest.verify(current, state),
            'current installed manifest schema/drift failed')
    require(not statemanifest.verify(before, state), 'pre-proof installed manifest content drifted')
    require(current['kicad_route']['commit'] == before['kicad_route']['commit'] == args.expected_main and
            current['kicad_route']['dirty'] is before['kicad_route']['dirty'] is False,
            'installed manifest does not bind exact clean main')
    require((state / current['krt']['generation']).resolve() == generation and
            (state / before['krt']['generation']).resolve() == generation, 'manifest selected generation differs')
    require(engine.source_sha256(generation / 'router') == engine.source_sha256(engine.SOURCE_ROOT) ==
            current['krt']['source_sha256'] == before['krt']['source_sha256'] == SOURCE,
            'installed/checkout engine source differs from qualified89a')
    module = statemanifest.extension_module(generation / 'venv')
    require(module and sha(module) == args.expected_module_sha256 == current['krt']['extension_module']['sha256'] ==
            before['krt']['extension_module']['sha256'], 'installed native module differs')
    require(statemanifest.venv_packages(generation / 'venv') == current['krt']['venv']['packages'] ==
            before['krt']['venv']['packages'] == PINS and
            statemanifest.venv_python_version(generation / 'venv') == current['krt']['venv']['python_version'] ==
            before['krt']['venv']['python_version'] == '3.12.3', 'installed dependency/Python pins differ')
    require(current['krt']['commit'] == before['krt']['commit'] == args.expected_main and
            current['kicad']['kicad_cli']['version'] == '10.0.7', 'installed build/native version differs')
    require(sha(dest / 'installed-manifest.json') == current_sha, 'retained final installed manifest differs from active state')
    execution = read(dest / 'execution.json'); installation = read(dest / 'installation.json'); phases = read(dest / 'phases.json')
    require(execution['status'] == installation['status'] == 'PASS' and
            execution['main_commit'] == installation['main_commit'] == args.expected_main and
            execution['engine_source_sha256'] == installation['engine_source_sha256'] == SOURCE and
            execution['shipping_source_tree'] == installation['shipping_source_tree'] == args.expected_source_tree and
            execution['generation'] == installation['generation'] == str(generation) and
            execution['manifest_sha256'] == current_sha and installation['manifest_sha256'] == before_sha and
            execution['drift'] == installation['drift'] == [], 'actual installation/execution terminal receipts differ')
    expected_commands = [
        ['doctor', ['/usr/bin/python3', str(repo / 'bin/kicad-route'), '--out', str(dest / 'doctor'), 'doctor', '--offline']],
        ['determinism', ['/usr/bin/python3', str(repo / 'bin/kicad-route'), '--out', str(dest / 'repeat'),
                         'determinism', '--backend', 'builtin', '--runs', '2', '--budget', '180', '--default-clearance', '0.4', '--record']]]
    require(phases == execution['phases'] and [[p['name'], p['argv']] for p in phases] == expected_commands and
            all(p['status'] == 'PASS' and p['exit_code'] == 0 for p in phases), 'ordinary proof command/terminal phases differ')
    doctor_path = dest / 'doctor/doctor/doctor.json'; doctor = doctor_check(read(doctor_path), before, before_sha, generation, args.expected_main)
    records = list((dest / 'repeat/determinism').glob('*/determinism.json'))
    require(len(records) == 1, 'missing/extra determinism record')
    record_path = records[0]; record = read(record_path)
    require(record['backend'] == 'builtin' and record['reproducible'] is True and record['reasons'] == [] and
            record['kicad_cli'] == before['kicad']['kicad_cli']['version'] and
            not record.get('record_error') and record['recorded_in'] == str(manifest_path) and len(record['runs']) == 2 and
            record['settings'] == {'runs': 2, 'budget_s': 180, 'backend_env': [], 'default_clearance_mm': 0.4},
            'strict exactly-two recorded-repeat contract failed')
    layers = []; rows = []; identities = []; paths = []; expected_identity = backend_identity(before)
    for recorded in record['runs']:
        run = locator(recorded['run_dir'], cwd).resolve(); paths.append(run)
        require(run.is_relative_to((dest / 'repeat/runs').resolve()), 'repeat result outside fresh output namespace')
        result = read(run / 'result.json'); tool = result['tool_identity']; backend = result['backend']; settings = result['settings']
        require(not determinism.wall_clock_stops(result['process']), 'raw repeat stopped at budget/stall/kill')
        require(backend['name'] == 'builtin' and backend['source_sha256'] == SOURCE and
                backend['runtime'] == {'source': str(generation / 'router'), 'venv': str(generation / 'venv'), 'generation': str(generation)} and
                backend['execution_identity'] == expected_identity and
                tool['backend'] == {**expected_identity, 'commit': args.expected_main}, 'raw executed backend content/build differs')
        require(tool['kicad_route'] == before['kicad_route'] and tool['kicad_cli'] == before['kicad']['kicad_cli'] and
                tool['pcbnew']['build_version'] == before['kicad']['pcbnew_build_version'] and
                tool['python'] == {'version': '3.12.3', 'executable': '/usr/bin/python3'} and
                tool['state_manifest_sha256'] == before_sha and tool['state_manifest_drift'] == [], 'raw grading/source/manifest identity differs')
        require(settings['backend'] == 'builtin' and settings['budget_s'] == 180 and settings['default_clearance_mm'] == 0.4 and
                settings['backend_args'] == [] and settings['backend_env'] == {} and settings['protect'] == 'existing', 'raw strict repeat settings differ')
        require(locator(result['input']['source_dir'], cwd).resolve() == repo / 'fixtures/route_demo' and
                result['input']['source_git_head'] == args.expected_main and result['input']['source_dirty_files'] == [] and
                result['input']['fingerprint'] == record['input']['fingerprint'], 'raw repeat input source differs')
        layer = determinism.layer_record(result); require(layer == recorded, 'recorded layers differ from raw result')
        require(statemanifest.execution_build_id(tool, 'builtin') == record['build_id'], 'recorded build differs from raw execution')
        row = native_records(result, run, cwd, repo, evidence); row['strict_worker_command'] = strict_command(result, repo, generation)
        layers.append(layer); rows.append(row); identities.append(tool)
    require(len(set(paths)) == 2 and {p.resolve() for p in (dest / 'repeat/runs').rglob('result.json')} ==
            {p / 'result.json' for p in paths}, 'raw repeat population is not exactly two distinct recorded results')
    comparison = determinism.compare(layers)
    require(comparison['reproducible'] is True and comparison['reasons'] == [] and
            all(record[key] == comparison[key] for key in ('reasons', 'differs_at', 'bytes_note')) and
            record['same'] == {**comparison['same'], 'execution_build': True} and identities[0] == identities[1] and
            record['build'] == identities[0]['backend'], 'raw repeat geometry/outcome/build reconstruction differs')
    stored = {key: value for key, value in record.items() if key != 'recorded_in'}
    require(current['determinism']['krt'] == stored and statemanifest.build_id(current, 'builtin') == record['build_id'],
            'current installed determinism record does not bind executed build')
    stripped_current = {**current, 'determinism': {k: v for k, v in current['determinism'].items() if k != 'krt'}}
    stripped_before = {**before, 'determinism': {k: v for k, v in before['determinism'].items() if k != 'krt'}}
    require(stripped_current == stripped_before, 'installation metadata changed during doctor/repeats beyond builtin record')
    require(common.router_generation(state) == generation and sha(manifest_path) == current_sha and
            git(repo, 'rev-parse', 'HEAD') == args.expected_main and not git(repo, 'status', '--porcelain'),
            'installed source/state changed during read-only verification')
    return {'schema': SCHEMA, 'status': 'PASS', 'verified_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'main_commit': args.expected_main, 'shipping_source_tree': args.expected_source_tree,
            'engine_source_sha256': SOURCE, 'generation_freshly_checked': str(generation), 'module': artifact(module),
            'packages': PINS, 'manifest': artifact(manifest_path), 'manifest_before': artifact(before_path), 'manifest_drift': [],
            'installation': artifact(dest / 'installation.json'), 'execution': artifact(dest / 'execution.json'),
            'doctor': {'artifact': artifact(doctor_path), **doctor},
            'determinism': {'artifact': artifact(record_path), 'raw_population': 2, 'comparison': comparison,
                            'build_id': record['build_id'], 'raw_results': rows, 'persisted_current_build': True},
            'helper_sha256': sha(__file__), 'native_routing_or_test_reruns': False, 'source_or_state_writes': False,
            'limits': ['Read-only reconstruction of retained native checks; does not rerun KiCad or establish performance.',
                       'Optional doctor checks retain their actual NOT_RUN/UNSUPPORTED/FAIL statuses and do not become required.',
                       'Manifest verification uses ordinary bounded version/interpreter identity probes.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=MAIN); parser.add_argument('--state', type=Path, default=MAIN)
    parser.add_argument('--deployment', type=Path, default=MAIN / 'build/agent497-upstream-adoption/deployment')
    parser.add_argument('--expected-main', required=True); parser.add_argument('--expected-source-tree', required=True)
    parser.add_argument('--expected-generation', type=Path, required=True); parser.add_argument('--expected-module-sha256', required=True)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args(); out = args.out or args.deployment / 'independent-verification.json'
    require(not out.exists(), 'refusing to replace prior independent deployment verification')
    try:
        result = verify(args)
    except Exception as error:
        result = {'schema': SCHEMA, 'status': 'FAIL', 'error': f'{type(error).__name__}: {error}',
                  'verified_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'helper_sha256': sha(__file__),
                  'native_routing_or_test_reruns': False, 'source_or_state_writes': False}
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'report': str(out), 'sha256': sha(out)}))
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
