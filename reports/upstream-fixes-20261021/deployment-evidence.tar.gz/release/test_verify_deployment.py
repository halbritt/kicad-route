import ast
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('deployment_verifier',HERE/'verify-deployment.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
ROOT=Path('/home/halbritt/.cache/agent-worktrees/kicad-route/agent497-upstream-primary')


class DeploymentGuards(unittest.TestCase):
    def setUp(self):
        old=HERE/'archon-tests'
        self.before=json.loads((old/'test-installed-manifest-before.json').read_text())
        self.ready=json.loads((old/'test-readiness.json').read_text())
        self.doctor=json.loads(next((old/'full-smoke/smoke').glob('*/doctor/doctor.json')).read_text())
        self.result=json.loads(next((old/'repeat').rglob('result.json')).read_text())

    def check_doctor(self):
        return v.doctor_check(self.doctor,self.before,self.ready['manifest_sha256'],Path(self.ready['generation']),self.ready['source_commit'])

    def test_real_retained_doctor_optional_not_run_is_permitted(self):
        self.doctor['offline']=True
        # This is a metadata guard fixture, not a claim this original online
        # doctor was invoked offline: only the matching checks are reused.
        self.doctor['checks'].append({'check':'synthetic optional release lookup','required':False,'status':'NOT_RUN','detail':'offline'})
        self.assertTrue(self.check_doctor()['optional_statuses_are_not_required_gates'])

    def test_required_not_run_refused(self):
        self.doctor['offline']=True
        next(c for c in self.doctor['checks'] if c['required'])['status']='NOT_RUN'
        with self.assertRaisesRegex(RuntimeError,'required doctor check'):self.check_doctor()

    def test_online_doctor_cannot_claim_offline_proof(self):
        self.doctor['offline']=False
        with self.assertRaisesRegex(RuntimeError,'offline doctor'):self.check_doctor()

    def test_wrong_doctor_manifest_refused(self):
        self.doctor['offline']=True;self.doctor['state_manifest']['sha256']='0'*64
        with self.assertRaisesRegex(RuntimeError,'pre-record manifest'):self.check_doctor()

    def test_wrong_doctor_selected_generation_refused(self):
        self.doctor['offline']=True
        self.doctor['versions']['builtin']['runtime']['generation']='/other'
        with self.assertRaisesRegex(RuntimeError,'another build/generation'):self.check_doctor()

    def test_optional_unsupported_is_preserved(self):
        self.doctor['offline']=True
        result=self.check_doctor()
        self.assertTrue(any(c['status']=='UNSUPPORTED' for c in result['optional']))

    def test_actual_worker_policy_accepted(self):
        result=v.strict_command(self.result,ROOT,Path(self.ready['generation']))
        self.assertEqual(result['strict_environment']['KICAD_RIP_PREEXISTING'],'0')

    def test_disabled_worker_safety_refused(self):
        command=next(c for c in self.result['process']['commands'] if '--no-stub-layer-swap' in c.get('argv',[]))
        command['argv'].remove('--no-stub-layer-swap')
        with self.assertRaisesRegex(RuntimeError,'worker flag missing'):
            v.strict_command(self.result,ROOT,Path(self.ready['generation']))

    def test_worker_escalation_cannot_hide_behind_extra_off_argument(self):
        command=next(c for c in self.result['process']['commands'] if '--no-stub-layer-swap' in c.get('argv',[]))
        command['argv'][command['argv'].index('--escalation')+1]='full'
        command['argv'].append('off')
        with self.assertRaisesRegex(RuntimeError,'worker policy differs'):
            v.strict_command(self.result,ROOT,Path(self.ready['generation']))

    def test_backend_expected_identity_is_content_bound(self):
        expected=v.backend_identity(self.before)
        self.assertEqual(expected,self.result['backend']['execution_identity'])
        self.assertEqual(expected['extension_module_sha256'],self.ready['module_sha256'])

    def native_fixture(self):
        old=HERE/'archon-tests'
        run=next((old/'repeat').rglob('result.json')).parent
        raw=json.loads((run/'result.json').read_text())
        original=v.locator
        def retained_locator(value,cwd):
            path=original(value,cwd)
            return old/path.relative_to('/test-evidence') if path.is_relative_to('/test-evidence') else path
        tree=ast.parse((ROOT/'src/kicad_route/evidence.py').read_text())
        functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('copper_signature','_canonical_item')]
        namespace={'json':json}
        exec(compile(ast.Module(body=functions,type_ignores=[]),'<actual-evidence-functions>','exec'),namespace)
        return raw,run,retained_locator,SimpleNamespace(copper_signature=namespace['copper_signature'])

    def test_actual_retained_native_records_and_geometry_reconstruct(self):
        raw,run,resolve,evidence=self.native_fixture()
        with patch.object(v,'locator',resolve):
            report=v.native_records(raw,run,Path('/testwork/candidate'),ROOT,evidence)
        self.assertEqual(report['native_grading_records_verified'],6)
        self.assertEqual(report['copper_geometry_reconstructed'],raw['evidence']['candidate_copper_signature'])

    def test_grading_record_hash_mismatch_refused(self):
        raw,run,resolve,evidence=self.native_fixture();digest=v.sha
        def changed(path):
            return '0'*64 if Path(path)==run/'validate/candidate-facts.json' else digest(path)
        with patch.object(v,'locator',resolve),patch.object(v,'sha',changed):
            with self.assertRaisesRegex(RuntimeError,'grading record hash differs'):
                v.native_records(raw,run,Path('/testwork/candidate'),ROOT,evidence)

    def test_reported_preservation_cannot_hide_raw_failure(self):
        raw,run,resolve,evidence=self.native_fixture();load=v.read
        def changed(path):
            rows=load(path)
            if Path(path)==run/'validate/preservation.json':rows[0]['status']='FAIL'
            return rows
        with patch.object(v,'locator',resolve),patch.object(v,'read',changed):
            with self.assertRaisesRegex(RuntimeError,'raw preservation differs'):
                v.native_records(raw,run,Path('/testwork/candidate'),ROOT,evidence)

    def test_run_relative_path_cannot_escape_or_be_absolute(self):
        for name in ('../other','/absolute','.'):
            with self.subTest(name=name),self.assertRaisesRegex(RuntimeError,'unsafe run-relative'):
                v.relative_path(name,HERE)

    def test_symlink_escape_refused(self):
        with tempfile.TemporaryDirectory(dir=HERE) as directory:
            root=Path(directory);(root/'escape').symlink_to('/usr')
            with self.assertRaisesRegex(RuntimeError,'escapes via symlink'):
                v.relative_path('escape/bin/python3',root)

    def test_absolute_and_relative_public_board_locators_resolve_equally(self):
        base=Path('/project');board=base/'build/proof/run/candidate/board.kicad_pcb'
        self.assertEqual(v.locator('build/proof/run/candidate/board.kicad_pcb',base).resolve(),v.locator(str(board),base).resolve())


if __name__=='__main__':unittest.main()
