#!/usr/bin/env python3
"""Post-terminal, profile-scoped, content-addressed export of every test artifact."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import tarfile
import uuid


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def safe(value):
    path = PurePosixPath(value)
    require(not path.is_absolute() and path.parts and '..' not in path.parts,
            'unsafe relative archive/index path: ' + value)
    return str(path)


class Store:
    def __init__(self, output):
        self.root = Path(output)
        require(not self.root.exists(), 'refusing to replace export')
        self.root.mkdir()
        (self.root / 'blobs').mkdir()
        self.blobs = {}

    def payload(self, stream, expected_size):
        require(0 <= expected_size < 90 * 1024 * 1024, 'regular payload exceeds90MiB; explicit chunking required')
        temporary = self.root / 'blobs' / ('.pending-' + uuid.uuid4().hex)
        digest, length = hashlib.sha256(), 0
        try:
            with temporary.open('xb') as target:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    length += len(chunk)
                    require(length <= expected_size, 'payload exceeds declared size')
                    digest.update(chunk)
                    target.write(chunk)
            require(length == expected_size, 'payload shorter than declared size')
            key = digest.hexdigest()
            target = self.root / 'blobs' / key
            if target.exists():
                require(target.stat().st_size == length and sha(target) == key, 'existing blob corrupt')
                temporary.unlink()
            else:
                temporary.rename(target)
            self.blobs[key] = length
            return {'sha256': key, 'bytes': length, 'retained': 'blobs/' + key}
        finally:
            temporary.unlink(missing_ok=True)


def file_entry(path, source, store):
    info = path.lstat()
    metadata = {'source': source, 'mode': stat.S_IMODE(info.st_mode), 'mtime_ns': info.st_mtime_ns}
    if stat.S_ISLNK(info.st_mode):
        return dict(metadata, kind='symlink', target=os.readlink(path))
    if stat.S_ISDIR(info.st_mode):
        return dict(metadata, kind='directory')
    if stat.S_ISREG(info.st_mode):
        with path.open('rb') as stream:
            return dict(metadata, kind='file', **store.payload(stream, info.st_size))
    return dict(metadata, kind='special_metadata_only', stat_type=stat.S_IFMT(info.st_mode),
                device=info.st_rdev, bytes=info.st_size)


def archive_entries(path, source, store):
    """Preserve every tar member as data; never extract or follow a symlink."""
    entries, known, hardlinks = [], {}, []
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive:
            name = safe(member.name)
            original = '/tmp/' + name
            require(original not in known, 'duplicate tar member: ' + original)
            item = {'source': original, 'mode': member.mode, 'mtime': member.mtime,
                    'uid': member.uid, 'gid': member.gid, 'archive_member': name}
            if member.isfile():
                stream = archive.extractfile(member)
                require(stream is not None, 'missing tar member payload')
                with stream:
                    item.update(kind='file', **store.payload(stream, member.size))
            elif member.isdir():
                item['kind'] = 'directory'
            elif member.issym():
                item.update(kind='symlink', target=member.linkname)
            elif member.islnk():
                item.update(kind='hardlink', target='/tmp/' + safe(member.linkname))
                hardlinks.append(item)
            else:
                item.update(kind='special_metadata_only', tar_type=member.type.decode('ascii', errors='replace'),
                            device_major=member.devmajor, device_minor=member.devminor, bytes=member.size)
            known[original] = item
            entries.append(item)
    for item in hardlinks:
        visited = {item['source']}
        target = item['target']
        while True:
            require(target in known and target not in visited, 'missing/cyclic tar hardlink')
            visited.add(target)
            resolved = known[target]
            if resolved['kind'] == 'hardlink':
                target = resolved['target']
                continue
            require(resolved['kind'] == 'file', 'hardlink target is not a regular file')
            item.update({key: resolved[key] for key in ('sha256', 'bytes', 'retained')})
            break
    return entries, {'source': source, 'kind': 'expanded_tar', 'original_sha256': sha(path),
                     'original_bytes': path.stat().st_size, 'member_count': len(entries),
                     'representation': 'Every member payload and mode/link metadata retained. Compression-container bytes remain in original ignored evidence; no native/test/source member omitted.'}


def profile(root, work, name, store):
    entries, expansions, sources = [], [], set()
    def add(path, source):
        require(source not in sources, 'duplicate source locator within profile: ' + source)
        sources.add(source)
        entries.append(file_entry(path, source, store))
    for path in [root, *sorted(root.rglob('*'))]:
        relative = path.relative_to(root)
        source = '/test-evidence' + ('/' + str(relative) if relative.parts else '')
        if path.is_file() and not path.is_symlink() and path.name.startswith('pytest-temp-') and path.name.endswith('.tar.gz'):
            archive, representation = archive_entries(path, source, store)
            for item in archive:
                require(item['source'] not in sources, 'duplicate original tmp locator')
                sources.add(item['source'])
                entries.append(item)
            expansions.append(representation)
        else:
            add(path, source)
    ready = json.loads((root / 'test-readiness.json').read_text())
    generation = Path(ready['generation'])
    require(generation.is_relative_to('/testwork'), 'runtime generation outside testwork')
    physical = work / generation.relative_to('/testwork')
    require(physical.is_dir() and not physical.is_symlink(), 'missing immutable runtime generation')
    for path in [physical, physical / 'router', *sorted((physical / 'router').rglob('*'))]:
        add(path, '/testwork/' + str(path.relative_to(work)))
    for path in sorted(physical.iterdir()):
        if path.is_file() or path.is_symlink():
            add(path, '/testwork/' + str(path.relative_to(work)))
    before = json.loads((root / 'test-installed-manifest-before.json').read_text())
    module = work / 'state-candidate' / before['krt']['extension_module']['path']
    require(sha(module) == ready['module_sha256'], 'selected runtime extension changed')
    add(module, '/testwork/' + str(module.relative_to(work)))
    for relative in ['src/kicad_route/cli.py', 'src/kicad_route/router/tests/test_parser_legacy_tokens.py']:
        path = work / 'candidate' / relative
        add(path, '/testwork/candidate/' + relative)
    return {'name': name, 'scope': 'Entire evidence tree, every archived pytest tmp member, immutable router source/metadata/native extension and explicit source-derived verifier inputs. System software and scientific environment remain version/hash-attested, not an OS image export.',
            'original_evidence_root': str(root), 'original_work_root': str(work),
            'source_commit': ready['source_commit'], 'source_sha256': ready['source_sha256'],
            'entries': entries, 'archive_expansions': expansions, 'omissions': []}


def export(taskroot, output, policy_path):
    taskroot = Path(taskroot).resolve()
    output = Path(output)
    require(output.parent.resolve() == taskroot and not output.is_symlink(), 'export must be a new direct taskroot child')
    policy_path = Path(policy_path)
    policy = json.loads(policy_path.read_text())
    require(policy['schema'] == 'kicad-route/archon-test-export-policy/1' and policy['omissions'] == []
            and policy['profile_names'] == ['original-failed', 'sandbox-correction', 'one-skip-nonaccepting', 'final-passed']
            and policy['max_regular_blob_bytes'] == 90 * 1024 * 1024 - 1, 'export policy differs')
    final = taskroot / 'test-evidence-noskip'
    proof = json.loads((final / 'independent-verification.json').read_text())
    require(proof['status'] == 'PASS', 'final independent verification not PASS')
    require(json.loads((final / 'qualification-receipt.json').read_text())['status'] == 'PASS', 'ordinary final qualification not PASS')
    store = Store(output)
    (store.root / 'provenance').mkdir()
    shutil.copy2(__file__, store.root / 'provenance/export-archon-tests.py')
    shutil.copy2(policy_path, store.root / 'provenance/archon-test-export-policy.json')
    populations = [('original-failed', 'test-evidence', 'testwork'),
                   ('sandbox-correction', 'test-evidence-corrected', 'testwork'),
                   ('one-skip-nonaccepting', 'test-evidence-final', 'testwork-final'),
                   ('final-passed', 'test-evidence-noskip', 'testwork-final')]
    profiles = [profile(taskroot / evidence, taskroot / work, name, store) for name, evidence, work in populations]
    index = {'schema': 'kicad-route/profile-scoped-test-cas/1', 'status': 'PASS',
             'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'helper_sha256': sha(__file__), 'policy': 'No raw test/native/source member omissions; gzip tmp containers expand into all member payloads/metadata. Global SHA256 blobs deduplicate identical bytes. Resolve original locators only with explicit profile context; never flatten conflicting study aliases. Symlink targets are metadata and never traversed.',
             'transport_artifacts': [{'retained': 'provenance/export-archon-tests.py', 'sha256': sha(__file__)},
                                     {'retained': 'provenance/archon-test-export-policy.json', 'sha256': sha(policy_path)}],
             'max_blob_bytes': 90 * 1024 * 1024 - 1, 'omissions': [], 'profiles': profiles,
             'blob_count': len(store.blobs), 'unique_payload_bytes': sum(store.blobs.values()),
             'represented_regular_file_bytes': sum(item['bytes'] for p in profiles for item in p['entries'] if item['kind'] in ('file', 'hardlink')),
             'blobs': [{'sha256': key, 'bytes': value, 'retained': 'blobs/' + key} for key, value in sorted(store.blobs.items())]}
    for blob in index['blobs']:
        path = store.root / blob['retained']
        require(path.stat().st_size == blob['bytes'] and sha(path) == blob['sha256'], 'final blob verification failed')
    path = store.root / 'test-evidence-index.json'
    path.write_text(json.dumps(index, indent=2) + '\n')
    print(json.dumps({'status': 'PASS', 'index': str(path), 'index_sha256': sha(path),
                      'blob_count': index['blob_count'], 'unique_payload_bytes': index['unique_payload_bytes'],
                      'represented_regular_file_bytes': index['represented_regular_file_bytes']}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--taskroot', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--policy', type=Path, required=True)
    args = parser.parse_args()
    export(args.taskroot, args.output, args.policy)
