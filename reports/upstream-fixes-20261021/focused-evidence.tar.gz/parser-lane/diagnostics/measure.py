"""Bounded parser diagnostics; not full-CLI performance acceptance."""
import argparse
import contextlib
import gc
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import tracemalloc

HERE = Path(__file__).resolve().parent
PYTHON = Path('/home/halbritt/git/kicad-route/.router-generations/f23025e1b26d406d83e2167aa0c0da9f/venv/bin/python')
BASE = PYTHON.parents[2] / 'router'
CANDIDATE = HERE / 'candidate-aaac6ba/src/kicad_route/router'
BOARDS = [Path('/home/halbritt/git/kicad-route/fixtures/route_demo/route_demo.kicad_pcb'),
          Path('/home/halbritt/git/KiCadRoutingTools/kicad_files/orangecrab_ext_pll.kicad_pcb')]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pressure():
    return {name: Path('/proc/' + name).read_text() for name in
            ('loadavg', 'pressure/cpu', 'pressure/io', 'pressure/memory')}


def child(root, board, mode):
    sys.path.insert(0, str(root / 'py_router'))
    import kicad_parser as parser
    import kicad_writer as writer
    assert Path(parser.__file__).resolve() == root / 'py_router/kicad_parser.py'
    with contextlib.redirect_stdout(sys.stderr):
        warm = parser.parse_kicad_pcb(board)
        text = board.read_text()
        def operation():
            if mode == 'parse':
                return parser.parse_kicad_pcb(board)
            if mode == 'extractors':
                return (parser.extract_segments(text, {v.name: k for k, v in warm.nets.items()}),
                        parser.extract_paste_graphics(text))
            return writer.move_copper_text_to_silkscreen(text)
        if mode == 'retention':
            large = HERE / 'retention.kicad_pcb'
            large.write_text(text.replace('(general', '(property "unused" "' + 'x' * (512 * 1024) + '")\n(general', 1))
            gc.collect()
            tracemalloc.start()
            result = parser.parse_kicad_pcb(large)
            gc.collect()
            current, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            return {'retained_bytes': current, 'traced_peak_bytes': peak, 'footprints': len(result.footprints)}
        operation()  # Separate warm operation, outside measured boundary.
        gc.collect()
        cpu, wall = time.process_time(), time.perf_counter()
        result = operation()
        elapsed, used = time.perf_counter() - wall, time.process_time() - cpu
        if mode == 'writer':
            assert result == text
        return {'wall_s': elapsed, 'cpu_s': used, 'mode': mode}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--child', nargs=3)
    args = p.parse_args()
    if args.child:
        root, board, mode = args.child
        print(json.dumps(child(Path(root), Path(board), mode)))
        return
    report = {'scope': 'Parser-only diagnostic; no full-runtime acceptance claim',
              'candidate_commit': 'aaac6ba', 'baseline_generation': BASE.parent.name,
              'python': str(PYTHON), 'python_version': sys.version,
              'ambient_before': pressure(), 'affinity': sorted(os.sched_getaffinity(0)),
              'packages': {n: importlib.metadata.version(n) for n in ('numpy', 'scipy', 'shapely', 'pillow')},
              'source': {side: {str(p.relative_to(root)): sha(p) for p in
                                (root / 'py_router/kicad_parser.py', root / 'py_router/kicad_writer.py')}
                         for side, root in [('baseline', BASE), ('candidate', CANDIDATE)]},
              'boards': {str(b): sha(b) for b in BOARDS}, 'samples': []}
    for board in BOARDS:
        for mode in ('parse', 'extractors', 'writer'):
            for repetition in range(5):
                sides = [('baseline', BASE), ('candidate', CANDIDATE)]
                if repetition % 2:
                    sides.reverse()
                for side, root in sides:
                    name = f'{board.stem}-{mode}-{repetition}-{side}'
                    timing = HERE / (name + '.time.json')
                    command = ['/usr/bin/time', '-q', '-f', '{"wall_s":%e,"user_s":%U,"system_s":%S,"max_rss_kib":%M}',
                               '-o', str(timing), str(PYTHON), str(Path(__file__).resolve()), '--child', str(root), str(board), mode]
                    process = subprocess.run(command, capture_output=True, text=True,
                                             env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), timeout=60)
                    (HERE / (name + '.stdout.log')).write_text(process.stdout)
                    (HERE / (name + '.stderr.log')).write_text(process.stderr)
                    sample = {'side': side, 'board': str(board), 'mode': mode, 'repetition': repetition,
                              'command': command, 'exit_code': process.returncode, 'gnu_time': json.loads(timing.read_text())}
                    if process.returncode:
                        report['samples'].append(sample)
                        (HERE / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
                        raise RuntimeError(name + ' failed')
                    sample['measurement'] = json.loads(process.stdout)
                    report['samples'].append(sample)
                    (HERE / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
    report['retention'] = {}
    for side, root in [('baseline', BASE), ('candidate', CANDIDATE)]:
        process = subprocess.run([str(PYTHON), str(Path(__file__).resolve()), '--child', str(root), str(BOARDS[0]), 'retention'],
                                 capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), timeout=60)
        (HERE / (side + '-retention.log')).write_text(process.stdout + process.stderr)
        process.check_returncode()
        report['retention'][side] = json.loads(process.stdout)
    report['summary'] = []
    for board in BOARDS:
        for mode in ('parse', 'extractors', 'writer'):
            row = {'board': str(board), 'mode': mode}
            for side in ('baseline', 'candidate'):
                values = [s for s in report['samples'] if s['side'] == side and s['board'] == str(board) and s['mode'] == mode]
                row[side] = {key: statistics.median(s['measurement'][key] for s in values) for key in ('wall_s', 'cpu_s')}
                row[side]['gnu_max_rss_kib'] = statistics.median(s['gnu_time']['max_rss_kib'] for s in values)
            report['summary'].append(row)
    report['ambient_after'] = pressure()
    report['status'] = 'COMPLETE'
    (HERE / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'summary': report['summary'], 'retention': report['retention']}, indent=2))


if __name__ == '__main__':
    main()
