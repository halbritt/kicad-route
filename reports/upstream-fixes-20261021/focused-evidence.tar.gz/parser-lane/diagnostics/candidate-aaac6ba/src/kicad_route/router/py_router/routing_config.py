"""
Configuration classes and coordinate utilities for PCB routing.
"""
from __future__ import annotations

import math
from typing import List, Optional, Tuple, Dict
from dataclasses import dataclass, field

from routing_constants import FORBIDDEN_LAYER_COST

# Cost knobs (proximity costs, via_cost, attraction bonuses) are calibrated at
# this grid step: GridRouteConfig.cell_cost / via_cost_units scale them so the
# cost per mm of path is the same at any --grid-step, and identical to
# historical behavior at 0.1mm. This is a FIXED calibration baseline, NOT the
# grid-step default (routing_defaults.GRID_STEP) -- it must stay 0.1 even if the
# default grid changes, so the two are intentionally separate constants.
REFERENCE_GRID_STEP = 0.1  # mm

# Lattice geometry for the #505 margin correction. The A* margin is measured
# from the outermost BLOCKED CELL, so it can only ever "act" at a distance that
# actually occurs between two lattice cells -- sqrt(i^2+j^2). A margin landing
# between two such distances rejects exactly what the lower one rejects, so the
# margin must be SNAPPED UP to a real lattice distance to have any effect.
_SQRT2 = math.sqrt(2.0)
# Only the {n, sqrt(n^2+1)} family can ever be the NEAREST blocked cell: the
# blocked region is convex-ish around the obstacle, so if a cell two rows off
# the axis is blocked then one closer in this family is blocked too. Brute
# forcing the lattice (tests/test_505_diagonal_margin.py) bears this out --
# every minimal safe margin it finds is 1, sqrt(2), 2, sqrt(5), 3, sqrt(10),
# 4 ...; 2*sqrt(2) and sqrt(13) never appear. Including them would let the
# snap stop one family member short and under-reject.
# Range covers the widest realistic case: a 0.8mm plane strap over a 0.127mm
# reserve on a 0.05 grid is e~6.7, needing a reach ~9.5 -- running off the end
# of the table would return an UNSNAPPED value, i.e. an inert margin.
_LATTICE_REACH = sorted({float(n) for n in range(1, 65)}
                        | {math.hypot(n, 1) for n in range(1, 65)})


def _snap_to_lattice_reach(margin: float, e: float) -> float:
    """Round `margin` up to the smallest cell-to-cell lattice distance that can
    reject everything inside the true keep-out radius (#505).

    Two failures the raw orthogonal margin has:

    1. It is derived from AXIS-ALIGNED rows (1 cell apart), but the router also
       moves at 45 degrees, where rows sit 1/sqrt(2) cells apart and the step
       from the stamp shell to the next row is sqrt(2). Worst case over all
       obstacle orientations and sub-cell phases, the margin has to reach
       e*sqrt(2) (brute-forced over the lattice in tests/test_505_*).
    2. Any value strictly between two lattice distances behaves like the lower
       one, so a margin of 1.25 rejects exactly what 1.0 rejects.

    Snapping to the lattice is what makes the margin bite while staying below
    the blunt e+1 wherever a lattice distance falls in between (e=1.25 -> 2.0,
    not 2.25). Measured: polykit_x let a 45-degree power track sit at 0.565685mm
    against a 0.575 requirement (kicad-cli "actual 0.1907 vs 0.2") x39, and
    caravel_nucleo at 0.388909 vs 0.400 x7; both grade clean with this snap."""
    # The 45-degree reach must be STRICTLY above e*sqrt(2): when the two are
    # equal (e=1.0 -> e*sqrt(2) = sqrt(2) exactly) the sqrt(2) row is the one
    # that still has to be rejected, so landing ON it is one row short -- the
    # brute force puts need(1.0) at 2.0, not sqrt(2).
    diag = next((r for r in _LATTICE_REACH if r > e * _SQRT2 + 1e-12),
                e * _SQRT2)
    # `margin` (the axis-aligned term) is already an integer row, itself a
    # lattice distance, so max() cannot land between two of them.
    need = max(margin, diag)
    # Nudge past the lattice distance: the router blocks on d <= margin with d
    # computed from exact integer offsets, and a margin computed as a quotient
    # can land one ULP BELOW the very distance it must reject.
    return need * (1.0 + 1e-12)


@dataclass
class DiffPairNet:
    """Represents a differential pair with P and N nets (tracks net IDs)."""
    base_name: str  # Common name without _P/_N suffix
    p_net_id: Optional[int] = None
    n_net_id: Optional[int] = None
    p_net_name: Optional[str] = None
    n_net_name: Optional[str] = None
    # Whether a P/N polarity pad swap may be applied to THIS pair (#279).
    # Set by batch_route_diff_pairs from --polarity-swap-nets; a swap is only
    # harmless when an endpoint can compensate (FPGA generic I/O, polarity-
    # tolerant protocol), so the default is deny.
    polarity_swap_allowed: bool = False

    @property
    def is_complete(self) -> bool:
        return self.p_net_id is not None and self.n_net_id is not None


@dataclass
class GridRouteConfig:
    """Configuration for grid-based routing."""
    track_width: float = 0.1  # mm
    clearance: float = 0.1  # mm between tracks
    via_size: float = 0.3  # mm via outer diameter
    via_drill: float = 0.2  # mm via drill
    grid_step: float = 0.1  # mm grid resolution
    via_cost: int = 75  # grid steps equivalent penalty for via (#586: 50 -> 75)
    layers: List[str] = field(default_factory=lambda: ['F.Cu', 'B.Cu'])
    max_iterations: int = 200000
    max_probe_iterations: int = 5000  # Quick probe per direction to detect stuck routes
    heuristic_weight: float = 2.3  # (#586: 1.9 -> 2.3, corpus dose-response peak)
    # #589 rough-pass probe marker: the result is a HINT (predicted path),
    # never shipped copper, so ship-safety rejects (the #157 terminal-bridge
    # short gate) must not veto it -- on a fanned board the probe map
    # excludes every to-route net's stubs (relaxed legality), so probe
    # terminals legitimately overlap future nets' copper. Set only on the
    # global plan's replace() clone; never on a config that emits copper.
    plan_probe: bool = False
    turn_cost: int = 1000  # Penalty for direction changes (encourages straighter paths)
    # BGA exclusion zones (auto-detected from PCB) - vias blocked inside these areas
    bga_exclusion_zones: List[Tuple[float, float, float, float]] = field(default_factory=list)
    stub_proximity_radius: float = 2.0  # mm - radius around stubs to penalize
    stub_proximity_cost: float = 0.2  # mm equivalent cost at stub center
    # NOTE (soft-knobs C6): in the Rust via branch this also MULTIPLIES the
    # summed stub+layer proximity at the via site (track-proximity and
    # ripped-corridor soft costs included), not just stub/BGA-zone costs.
    via_proximity_cost: float = 10.0  # via cost multiplier in stub/BGA proximity zones (0 = no extra cost)
    bga_proximity_radius: float = 7.0  # mm - proximity-field CAP (largest packages reach it)
    bga_proximity_cost: float = 0.2  # mm equivalent cost at BGA edge
    # Per-package proximity-field rects (#585 item 4): (min_x, min_y, max_x,
    # max_y, radius_mm) for EVERY fine-pitch package (BGA/QFN/QFP), radius
    # scaled by sqrt(n_pads/1000) * bga_proximity_radius clamped to
    # [2.0, bga_proximity_radius]. Filled by the batch engines from the board
    # (routing_common.package_proximity_zones); None = legacy behavior
    # (bga_exclusion_zones at the flat radius).
    package_proximity_zones: Optional[List[Tuple[float, float, float, float, float]]] = None
    # Direction search order: "forward" or "backward"
    direction_order: str = "forward"
    # Differential pair routing parameters
    diff_pair_gap: float = 0.101  # mm - gap between P and N traces (center-to-center = track_width + gap)
    diff_pair_centerline_setback: float = None  # mm - distance in front of stubs to start centerline route (None = 2 * spacing)
    diff_pair_setback_no_ladder: bool = False  # when True, _setback_ladder yields ONLY
    # the configured setback (no 0.75/0.5/floor/1.5/2x expansion) -- used by the pinch
    # retry in _maybe_swap_to_hybrid so each attempt routes at the EXACT setback asked.
    diff_pair_setback_floor: float = None  # mm - the least setback from a terminal (None =
    # track_width/2 + clearance, clear of the pad edge it launched from). A caller whose
    # terminals are already coupled copper in open space -- a whole-route plan's end
    # connectors (awx) -- sets 0 to take over at the terminals themselves.
    # In a multi-point pair, a "terminal" whose P and N pads are farther apart
    # than diff_pair_uncouple_factor * (track_width + diff_pair_gap) is not a
    # coupled differential connection (e.g. spread-out test points). If the full
    # coupled chain can't be routed, such terminals are peeled off and their pads
    # routed single-ended (P->P, N->N) instead (issue #121).
    diff_pair_uncouple_factor: float = 6.0  # multiples of pair spacing (track+gap)
    min_turning_radius: float = 0.2  # mm - minimum turning radius for pose-based routing
    debug_lines: bool = False  # Output debug geometry on User.2/3/8/9 layers
    verbose: bool = False  # Print detailed diagnostic output
    max_rip_up_count: int = 3  # Maximum blockers to rip up at once during rip-up and retry (1 to N)
    # How the #85 arbitration decides keep-retry vs abandon after a Phase 3
    # tap rip-up cascade (docs/rip-up-reroute.md "Abandon metrics"). One of
    # phase3_routing.ABANDON_METRICS: stranded | total-pads | complete-nets |
    # congestion | history | weighted | probe | weighted-probe
    ripup_abandon_metric: str = 'stranded'
    # Blocker SELECTION algorithm for the rip-up ladders (#424 audit;
    # blocking_analysis.rank_blockers / mincut_probe_order):
    # count | near-target | bidir | mincut
    ripup_blocker_select: str = 'count'
    # Bus rip resistance: >1.0 divides bus-group members' blocker scores so
    # the rip ladder prefers bystanders over tearing up a settled bus river;
    # the mincut probe prices member cells higher by the same factor.
    # 1.0 = off (legacy). bus_member_net_ids is attached by the SE loop.
    bus_rip_resistance: float = 1.0
    max_setback_angle: float = 45.0  # Maximum angle (degrees) for setback position search
    track_proximity_distance: float = 2.0  # mm - radius around routed tracks to penalize (same layer)
    stub_layer_swap: bool = True  # Enable stub layer switching optimization
    track_proximity_cost: float = 0.0  # mm equivalent cost (0 = disabled)
    # #1146 pairwise keep-away (keep_away.py): canonical 'AGG:VICTIM:GAP'
    # rules. While a net of one side routes, cells within GAP (edge to edge,
    # same layer) of the other side's copper cost keep_away_cost per cell,
    # except within keep_away_free mm of the routed net's own pads.
    keep_away: Tuple[str, ...] = ()
    keep_away_free: float = 1.5  # mm (routing_defaults.KEEP_AWAY_FREE)
    keep_away_cost: float = 0.5  # mm equivalent per cell (0 = report only)
    target_swap_crossing_penalty: float = 1000.0  # Penalty for crossing assignments in target swap
    crossing_layer_check: bool = True  # Only count crossings when routes share a layer
    routing_clearance_margin: float = 1.0  # Diff pairs only: track-to-via distance multiplier for the P/N via offset (1.0 = minimum DRC)
    hole_to_hole_clearance: float = 0.20  # mm - edge-to-edge via drill spacing; JLC "Via
                                           # Hole-to-Hole Spacing" (keep in sync with
                                           # routing_defaults.HOLE_TO_HOLE_CLEARANCE)
    board_edge_clearance: float = 0.0  # mm - clearance from board edge (0 = use track clearance)
    # #581: edge-to-edge clearance between ANY placed via and SAME-NET pads.
    # > 0 forbids via-in-pad globally: routing/tap/rescue via placement blocks
    # same-net SMD pads at this clearance, and pad-centre swap vias are
    # declined. #962: > 0 also keeps vias out of the net's solder-paste
    # OPENINGS at the same clearance (graphic and paste-only openings, and pad
    # openings larger than their pad), since a declared pad rectangle can be
    # smaller than the paste printed around it (esp_prog U2's F.Paste tab).
    # -1 (default) AND 0 preserve the pre-#581 behavior exactly (0 keeps only
    # its legacy meaning where route_planes passes it explicitly into its
    # stitching via maps). Set from --same-net-pad-clearance (route.py,
    # route_diff.py, route_planes.py, repair_planes.py, the fanouts) or the
    # persisted .kicad_pro record (kicad_routing_tools.same_net_pad_clearance).
    same_net_pad_clearance: float = -1.0
    # mm - copper-to-HOLE floor (KiCad's `min_hole_clearance`). 0 = not set by
    # the caller, so the obstacle builder reads the board's own constraint and
    # falls back to routing_defaults.NPTH_TO_TRACK_CLEARANCE. It is NOT the same
    # rule as hole_to_hole_clearance (drill-to-drill): this one keeps TRACKS off
    # an NPTH wall. The router used to hardcode the 0.20 fab floor here while
    # check_drc already read min_hole_clearance, so on a board declaring 0.25 the
    # router would happily route into a band its own checker then flagged.
    hole_clearance: float = 0.0
    max_turn_angle: float = 180.0  # Max cumulative turn angle (degrees) before reset, to prevent U-turns
    # Power-tap neck-down (issue #72): when a wide power-net tap edge fails,
    # retry it at the layer's default track width. The narrow neck extends
    # neckdown_length mm from the target pad; beyond that the track returns
    # to the power width wherever the wide clearance fits.
    power_tap_neckdown: bool = True
    # #568 per-rung via legality: 0 = the configured via (baseline); 1 = the
    # small fab-rung via where the obstacle map's blocked_vias_small proves it
    # legal (populated only under KICAD_VIA_RUNG=2 dual stamping). Set on a
    # dataclasses.replace CLONE for one retry search -- never mutate a shared
    # config, the field must not leak into sibling routes.
    via_rung: int = 0
    # #1226: the RUN's (via_size, via_drill), recorded on the per-net clone
    # single_ended_routing._per_net_via_config makes for a net at its own
    # #530 via (None on the run config). The #568 small rung is stamped
    # against the run's via, so a rung-1 retry from that clone must ship the
    # pair the map was stamped at, not one derived from the net's own via.
    run_via: Optional[Tuple[float, float]] = None
    neckdown_length: float = 2.5  # mm of narrow track from the target pad
    neckdown_taper_length: float = 0.5  # mm narrow->wide taper (0 = abrupt width step)
    gnd_via_enabled: bool = True  # Enable GND via placement near diff pair signal vias
    # Vertical alignment attraction - encourages tracks on different layers to stack
    vertical_attraction_radius: float = 1.0  # mm - radius for attraction lookup (0 = disabled); matches routing_defaults.VERTICAL_ATTRACTION_RADIUS (N1)
    vertical_attraction_cost: float = 0.0  # mm equivalent bonus for aligned positions
    # Ripped route avoidance - soft penalty for routing through a ripped net's former corridor
    ripped_route_avoidance_radius: float = 1.0  # mm - radius around ripped route segments/vias
    ripped_route_avoidance_cost: float = 0.1  # mm equivalent cost (0 = disabled)
    # Length matching for DDR4 signals
    length_match_groups: List[List[str]] = field(default_factory=list)  # Groups of net patterns to match
    length_match_tolerance: float = 0.1  # mm - acceptable length variance within group
    meander_amplitude: float = 1.0  # mm - height of meander perpendicular to trace
    # Single-ended meander arm pitch (#501), in MULTIPLES of the net's routed
    # track width, centre-to-centre. The historical geometry hardcoded a 0.2mm
    # pitch regardless of track width (a 4:1 coupled comb at impedance widths,
    # so length matching under-delivered DELAY matching). 2.0 = 2W pitch = 1W
    # edge gap between arms; identical to the old geometry at the 0.1mm default
    # width. Same-net arms are excluded from every clearance check by design,
    # so this arithmetic is the only arm-spacing guarantee.
    meander_spacing: float = 2.0  # arm pitch as a multiple of net track width
    diff_chamfer_extra: float = 1.5  # Chamfer multiplier for diff pair meanders (>1 avoids P/N crossings)
    diff_pair_intra_match: bool = False  # Enable intra-pair P/N length matching (meander shorter track)
    ac_couple_match: bool = False  # End-to-end length-match AC-coupled pairs split by series caps (#196)
    # Hybrid escape: when a coupled pair's terminal connector can't clear foreign
    # copper (#165 graze), keep the coupled middle and defer each terminal leg to
    # a point-to-point single-ended join instead of failing the whole pair.
    diff_pair_hybrid_escape: bool = True
    # Time matching (alternative to length matching) - matches propagation delay instead of length
    time_matching: bool = False  # If True, match by propagation time instead of length
    time_match_tolerance: float = 1.0  # ps - acceptable time variance within group
    debug_memory: bool = False  # Print memory usage statistics at key points
    # Output options
    add_teardrops: bool = False  # Add teardrop settings to all pads in output file
    # Impedance-controlled routing
    impedance_target: Optional[float] = None  # Target impedance in ohms (None = use fixed track_width)
    layer_widths: Dict[str, float] = field(default_factory=dict)  # Per-layer widths for impedance control
    # Coplanar-waveguide-over-ground declaration (#486). A trace running through
    # a ground pour on its OWN layer is a CPW, not a microstrip: the side ground
    # pulls Z0 down, so hitting the target needs a NARROWER trace. The pour does
    # not exist yet at route time, so this is a DESIGN DECLARATION -- the plane
    # step must be run with a matching zone clearance, and check_impedance.py
    # verifies afterwards that the geometry actually came out that way.
    coplanar_gap: float = 0.0  # Design trace-edge-to-pour-edge gap in mm (0 = not coplanar)
    # Empty coplanar_net_ids with a non-zero gap means the WHOLE call is
    # coplanar, and layer_widths already carries the CPW widths. A non-empty set
    # means only these nets are, and coplanar_layer_widths holds their widths
    # while layer_widths keeps the microstrip answer for everyone else.
    coplanar_net_ids: set = field(default_factory=set)
    coplanar_layer_widths: Dict[str, float] = field(default_factory=dict)
    # #521: per-net per-layer widths REAPPLIED from stored impedance
    # declarations (.kicad_pro kicad_routing_tools.net_impedance) when a later
    # step touches an impedance-routed net without --impedance. Consulted in
    # get_net_track_width above the netclass scalar.
    net_layer_widths: Dict[int, Dict[str, float]] = field(default_factory=dict)
    # Obstacle-stamp reserve policy (#156). False (single-ended engine): stamps
    # reserve the NOMINAL track_width around obstacles and every net's extra
    # width (power override OR impedance layer width) rides its own fractional
    # per-layer track_margin -- exact, per-net, no over-block. True (diff-pair
    # engine): stamps bake the full per-layer impedance width into the map
    # (the pose router has no track_margin channel), margins then compute 0
    # for impedance-width nets -- today's mm-exact behaviour, unchanged.
    reserve_layer_widths: bool = False
    # Power net routing - per-net width overrides
    power_net_widths: Dict[int, float] = field(default_factory=dict)  # net_id -> width in mm
    # Per-net netclass track width (auto-read from the .kicad_pro when --track-width
    # is omitted). Unlike power_net_widths this is the net's OWN class width and may
    # be SMALLER than the global track_width (a narrower class), floored at the fab
    # minimum by the caller. Lower priority than a manual power_net_widths override.
    net_track_widths: Dict[int, float] = field(default_factory=dict)  # net_id -> width in mm
    # Netclass-declared widths as ESCALATION FLOORS only (2026-08-06): loaded
    # even when an explicit --track-width suppresses net_track_widths, so the
    # rescue/terminal ladders may march to min(nominal, fab_track, netclass
    # width) -- designer-sanctioned geometry -- without changing nominal
    # routing. Clamped at the advanced-tier floor at load.
    netclass_width_floors: Dict[int, float] = field(default_factory=dict)
    # Layer cost weights - prefer certain layers over others (1.0 = normal, 1.5 = 50% more expensive)
    layer_costs: List[float] = field(default_factory=list)  # Per-layer cost multipliers
    # Debug options
    collect_stats: bool = False  # Collect A* search statistics for debugging
    # Heuristic tuning
    proximity_heuristic_factor: float = 0.0  # proximity add-on to the A* heuristic. The CLIs and batch_route pass routing_defaults.PROXIMITY_HEURISTIC_FACTOR (0.02, restored in e9523f23 after 0 regressed 5 boards); this dataclass default is only what a direct GridRouteConfig() gets
    # Layer direction preference - alternates H/V starting with horizontal on top
    # Matches routing_defaults.DIRECTION_PREFERENCE_COST, which is back at 250
    # after the #663 revert. route.py/route_diff.py always pass the caller's
    # value, so this default is reached only by configs built field-by-field
    # that never pass the parameter -- the oracle-weld and plane sub-configs
    # (route.py, route_planes.py, repair_planes.py).
    #
    # Those legs stayed at 250 through #663's 5-era, which made a MIXED state
    # (signal 5, these legs 250). That was screened directly -- an arm making
    # these follow the constant -- and measured INERT (94/59 vs 95/58 on
    # sets1-5), so the divergence never mattered. There is none now. If this is
    # ever moved off routing_defaults' value again, re-measure rather than
    # assuming either that coherence is free or that it is harmless.
    direction_preference_cost: int = 250  # Cost penalty for non-preferred direction (0 = disabled)
    # Bus routing - auto-detection and parallel routing of grouped nets
    bus_enabled: bool = False  # Enable bus detection and routing
    bus_detection_radius: float = 5.0  # mm - max endpoint distance to form bus
    bus_min_nets: int = 2  # Minimum nets to form a bus
    bus_attraction_radius: float = 5.0  # mm - attraction radius from neighbor track
    bus_attraction_bonus: int = 5000  # Cost bonus for staying near neighbor
    # Guide corridor - route selected nets through a user-drawn polyline (issue #7)
    guide_corridor_enabled: bool = False  # Steer routed nets along a drawn guide path
    guide_corridor_layer: str = "User.1"  # User layer the guide polyline is drawn on
    guide_corridor_spacing: float = 0.0  # mm; 0 = endpoints only, else subdivide long segments
    corridor_waypoints: List[Tuple[int, int]] = field(default_factory=list)  # prebuilt grid waypoints
    # Keepout zone - keep routed tracks out of a user-drawn polygon (issue #27)
    keepout_enabled: bool = False  # Block routed tracks from a drawn keepout polygon
    keepout_layer: str = "User.2"  # User layer the keepout polygon is drawn on
    # Cross-class clearance (KiCad semantics, issue: PR392). Each entry maps a
    # net_id to that net's own net-class clearance (mm). KiCad's required spacing
    # between two nets of different classes is max(classA, classB); the obstacle
    # maps price every foreign/in-run obstacle at obstacle_clearance() below.
    # Auto-read from the .kicad_pro netclasses by route.py/route_diff.py (or
    # supplied via --net-clearances); the GUI derives it from the live board.
    # net_clearance_floor is the routing-side floor (max clearance among the nets
    # being routed in THIS call, >= config.clearance); set at run start. An empty
    # map + None floor reproduces plain config.clearance behaviour exactly.
    # This also subsumes #326 B5: a net's OWN copper is stamped at
    # obstacle_clearance() = max(floor, its class), so every same-run sibling keeps
    # at least the class spacing to it (get_net_clearance() is the #326-only view).
    net_clearances: Dict[int, float] = field(default_factory=dict)
    net_clearance_floor: Optional[float] = None
    # Per-layer clearance from the board's .kicad_dru custom rules (#498),
    # {layer_name: mm}. REPLACEMENT semantics, mirroring KiCad's precedence
    # (custom rules outrank netclasses and the CLI ceiling, tightening OR
    # relaxing): on a ruled layer the value replaces the resolved pair
    # clearance for EVERY pair there; unruled layers keep net/class
    # resolution. Auto-read by the engines from the sibling .kicad_dru
    # (kicad_dru.read_board_layer_clearances, fab-floor pinned); an empty map
    # is a strict no-op. There is deliberately NO CLI flag or GUI control --
    # the rules file is the one source of truth, and the graders (check_drc,
    # staged kicad-cli) read the same file.
    layer_clearances: Dict[str, float] = field(default_factory=dict)
    # The BOARD's copper layer list the layer map above was expanded over:
    # `pad_pair_clearance` resolves a `*.Cu` pad's shared layers over it, as
    # check_drc does. Set by kicad_dru.install_layer_clearances; `layers`
    # stands in when empty.
    board_copper_layers: List[str] = field(default_factory=list)
    # Track-to-track clearance from the board's .kicad_dru (#735),
    # {obstacle_net_id: mm} -- the EFFECTIVE per-obstacle map for this call's
    # routed set (kicad_dru.effective_track_clearances). RAISE-ONLY, applied
    # by track-vs-track stamp sites over the already-resolved value (so it
    # composes AFTER the #498 layer replacement); via/pad geometry never
    # consults it (KiCad's Type=='track' binds tracks only). An empty map is
    # a strict no-op. Like the layer map: no CLI flag, no GUI control.
    track_clearances: Dict[int, float] = field(default_factory=dict)
    # #530: the board's design rules resolved in KiCad's order
    # (design_rules.DesignRules), installed engine-side by
    # kicad_dru.install_layer_clearances for both fronts. None until then.
    # The legacy per-channel maps above are being migrated onto it; consumers
    # that resolve through it must treat None as "no rules declared".
    rules: Optional[object] = None
    # #530 decision 4: per-net VIA geometry {net_id: (diameter, drill)} for
    # nets whose resolved draw size differs from via_size/via_drill (their
    # net class or a .kicad_dru via_diameter/hole_size rule). Filled by
    # batch_route when --via-size was omitted (via_from_class); empty when
    # the operator gave an explicit via, which applies to every net. The
    # search prices each such net at its own via through the obstacle map's
    # via-legality RUNGS (obstacle_cache.via_rungs) and emits vias at it.
    net_via_sizes: Dict[int, Tuple[float, float]] = field(default_factory=dict)
    # #1260: the copper pours this run may not CUT -- fill islands of zone
    # nets outside the run's scope that no routed net has a terminal inside
    # (pour_guard.install_pour_barriers), each {'net', 'layer', 'polygons',
    # 'clearance'}. build_base_obstacle_map stamps them as hard track and via
    # keep-outs. Engine-computed and handed down to nested sub-runs; no CLI
    # flag and no GUI control (KICAD_POUR_GUARD=0 reverts). Empty = inert.
    pour_barriers: List[dict] = field(default_factory=list)

    def net_via(self, net_id: int) -> Tuple[float, float]:
        """(diameter, drill) this net's vias are drawn at."""
        v = self.net_via_sizes.get(net_id) if self.net_via_sizes else None
        return (float(v[0]), float(v[1])) if v else (self.via_size, self.via_drill)

    def rule_floors(self, net_id: int, layer: Optional[str] = None) -> Dict[str, float]:
        """The .kicad_dru / Board Setup size minimums that bind ``net_id`` (on
        ``layer`` when given), in fab_tiers FLOOR_KEYS vocabulary, for the
        descent sites: a rescue may narrow a track or shrink a via only down
        to these under ``--escalation board``. Empty when the board declares
        none, or under ``--escalation fab`` (which may go below them)."""
        out = {}
        # #530 (corpus A/B, core1106_cam): a net in a NON-Default class is graded
        # by KiCad at that class's clearance whatever this run narrowed to --
        # the writeback lowers only the Default class (decision 2) -- so no
        # automatic clearance descent for the net may go below its own class.
        # Applies under EVERY policy: this is a grading floor, not a fab one.
        cc = self.net_clearances.get(net_id) if self.net_clearances else None
        if cc:
            out['clearance'] = float(cc)
        rules = self.rules
        if rules is None or not (getattr(rules, 'rules', None) or getattr(rules, 'board_min', None)):
            return out
        try:
            from fab_tiers import get_escalation_policy
            if get_escalation_policy()[0] == 'fab':
                return out
        except Exception:                                      # noqa: BLE001
            return out
        try:
            tw = rules.floor('track_width', net_id, layer)
            if tw:
                out['track_width'] = tw
            vd = rules.floor('via_diameter', net_id, layer, type='via')
            if vd:
                out['via_diameter'] = vd
            hs = rules.floor('hole_size', net_id, layer, type='via')
            if hs:
                out['via_drill'] = hs
        except Exception:                                      # noqa: BLE001
            return out
        return out

    def track_floor(self, net_id: int, layer: Optional[str], fab_value: float) -> float:
        """The narrowest track a descent may deliver on ``net_id``: the fab
        floor raised to the net's own rule / board minimum (see rule_floors)."""
        rf = self.rule_floors(net_id, layer).get('track_width')
        return max(fab_value, rf) if rf else fab_value

    def pad_override_clearance(self, base: float, pad, other_pad=None) -> float:
        """The pair clearance against ``pad`` (and ``other_pad``) once a pad /
        footprint clearance OVERRIDE is applied: KiCad's max(overrides) floored
        at rules.min_clearance, REPLACING ``base`` (design_rules.override_clearance).
        ``base`` is returned unchanged when neither pad carries one, so a board
        without overrides is byte-identical to before."""
        from design_rules import override_clearance
        rules = self.rules
        bm = (rules.board_min.get('min_clearance', 0.0) if rules is not None
              and getattr(rules, 'board_min', None) else 0.0)
        return override_clearance(base, bm, pad, other_pad)

    def track_obstacle_clearance(self, net_id: int, resolved: float) -> float:
        """Track-rule seg-vs-seg clearance against obstacle net ``net_id``:
        max(resolved, the track-rule value) -- raise-only, one dict lookup per
        SEGMENT. ``resolved`` is the caller's fully-resolved value (class
        pairwise max, #498 layer replacement already applied)."""
        if not self.track_clearances:
            return resolved
        v = self.track_clearances.get(net_id)
        return resolved if v is None or v <= resolved else v

    def layer_clearance(self, layer: str, fallback: float) -> float:
        """#498 pair clearance on `layer`: the .kicad_dru rule value when the
        layer is ruled (replacement -- may be below `fallback`), else
        `fallback` (the caller's net/class-resolved value). Single-layer
        copper (segments, SMD pads) resolves through this; stack-spanning
        copper uses stack_clearance()."""
        if self.layer_clearances:
            v = self.layer_clearances.get(layer)
            if v is not None:
                return v
        return fallback

    def stack_clearance(self, fallback: float) -> float:
        """#498 clearance for STACK-SPANNING pairs (via barrels, TH drills):
        KiCad evaluates the pair on every layer both coppers exist on, so the
        requirement is the max over the stack. max(fallback, all rule values)
        -- conservatively keeps `fallback` even when every routed layer is
        ruled lower, since the board may have copper on layers outside
        config.layers."""
        if not self.layer_clearances:
            return fallback
        return max([fallback] + list(self.layer_clearances.values()))

    def obstacle_clearance(self, net_id: int) -> float:
        """KiCad cross-class clearance for an obstacle belonging to `net_id`.

        Returns max(routing-side floor, that obstacle net's own class clearance).
        The floor (net_clearance_floor) defaults to config.clearance, and an
        absent net falls back to config.clearance, so an empty net_clearances map
        yields exactly config.clearance -- byte-identical to pre-PR392 behaviour.
        Consumers (base map builder + every incremental obstacle stamper) MUST
        route their foreign-copper clearance through this one method so the ADD
        and REMOVE paths derive an identical per-obstacle value (ref-count
        symmetry, issue #208/#309)."""
        floor = self.net_clearance_floor if self.net_clearance_floor is not None else self.clearance
        return max(floor, self.net_clearances.get(net_id, self.clearance))

    def set_net_clearances(self, net_clearances, routed_net_ids) -> None:
        """Install the cross-class clearance map and compute the routing-side
        floor over the nets being routed in this call. Inert (floor == clearance)
        when the map is empty. Restricting the floor to the ROUTED nets keeps a
        foreign class from inflating it (which would over-block every routed
        net)."""
        self.net_clearances = dict(net_clearances) if net_clearances else {}
        if self.net_clearances and routed_net_ids:
            routed = [self.net_clearances[nid] for nid in routed_net_ids
                      if nid in self.net_clearances]
            self.net_clearance_floor = max([self.clearance] + routed)
        else:
            self.net_clearance_floor = self.clearance

    # ---- KiCad's pairwise clearance, for admit/refuse verdicts (#1136) -----
    #
    # `obstacle_clearance` is the value a foreign obstacle is STAMPED at. It is
    # floored at `net_clearance_floor`, the widest class routed in this call,
    # so the ADD and REMOVE stamps stay ref-count symmetric (#208/#309). A
    # verdict about two SPECIFIC nets (may this stub sit here, may this via go
    # there) is graded by check_drc at the pair's own value instead:
    # `max(clearance, classA, classB)`, then the .kicad_dru layer rule. Pricing
    # a verdict at the stamp value would refuse legal copper whenever a wider
    # class is routed anywhere in the call.

    def pair_clearance(self, net_a: int, net_b: int,
                       layer: Optional[str] = None, *, kind: str = 'layer',
                       base: Optional[float] = None) -> float:
        """check_drc's clearance between copper of `net_a` and `net_b`.

        `base` is the floor the pair starts from (`self.clearance` when None;
        a site that was handed a clearance passes it). Then the two nets'
        classes (`max`), then by `kind`:

        * 'layer' -- the two items meet on one layer (track vs track, track
          vs via): the #498 rule for `layer` REPLACES the value, as
          check_drc's `_pair_cl(a, b, layer)` does. A pad is
          `pad_pair_clearance`, which also applies the pad's override;
        * 'track' -- track vs track: 'layer', then the #735 track rule raises
          it (check_drc's `_track_pair_cl`). The router side reads the
          per-obstacle-net map, an over-approximation of check_drc's
          pair-exact rule. Net-0 copper is in no class and missing from that
          map, so it is priced at the widest track rule;
        * 'stack' -- via vs via, which meet on every layer: the max over the
          stack (check_drc's `_stack_cl`). `layer` is ignored.

        With no class map, no layer rule and no track rule it returns `base`
        unchanged, so a site that swaps its flat term for this call is
        byte-identical on such a board."""
        clr = self.clearance if base is None else base
        nc = self.net_clearances
        if nc:
            a = nc.get(net_a)
            if a is not None and a > clr:
                clr = a
            b = nc.get(net_b)
            if b is not None and b > clr:
                clr = b
        if kind == 'stack':
            return self.stack_clearance(clr)
        if kind != 'layer' and kind != 'track':
            raise ValueError(f"pair_clearance kind {kind!r}: expected "
                             f"'layer', 'track' or 'stack'")
        if layer is not None:
            clr = self.layer_clearance(layer, clr)
        if kind == 'track' and self.track_clearances:
            if not net_a or not net_b:
                widest = max(self.track_clearances.values())
                if widest > clr:
                    clr = widest
            clr = max(self.track_obstacle_clearance(net_a, clr),
                      self.track_obstacle_clearance(net_b, clr))
        return clr

    def pad_pair_clearance(self, pad, other_net: int,
                           layer: Optional[str] = None, *, other_pad=None,
                           base: Optional[float] = None) -> float:
        """check_drc's clearance between `pad` and copper of `other_net`
        (`_pad_pair_cl`): `pad_pair_clearance_before_override`, then a pad /
        footprint clearance OVERRIDE, which replaces the value."""
        return self.pad_override_clearance(
            self.pad_pair_clearance_before_override(
                pad, other_net, layer, other_pad=other_pad, base=base),
            pad, other_pad)

    def max_pair_clearance(self, base: Optional[float] = None) -> float:
        """An upper bound of `pair_clearance` over every pair and kind: the
        radius a prefilter must reach. Pad overrides are not included; a pad
        site resolves its pads one by one."""
        v = self.clearance if base is None else base
        for m in (self.net_clearances, self.layer_clearances,
                  self.track_clearances):
            if m:
                mv = max(m.values())
                if mv > v:
                    v = mv
        return v

    def pair_clearance_inert(self) -> bool:
        """True when no channel can move a pair off the floor it is given: no
        class map, no .kicad_dru layer rule, no track rule. A hot loop may
        then keep its flat term instead of pricing every item."""
        return not (self.net_clearances or self.layer_clearances
                    or self.track_clearances)

    def pad_pair_clearance_before_override(self, pad, other_net: int,
                                           layer: Optional[str] = None, *,
                                           other_pad=None,
                                           base: Optional[float] = None
                                           ) -> float:
        """`pad_pair_clearance` short of its last step, the pad / footprint
        override: the pair's classes, then the .kicad_dru rule on `layer` (a
        track) or over the copper the two share (a via, or `other_pad`).

        For a site that keeps its own override handling (#1136 converts the
        class and rule term only, so a board that declares neither is
        unchanged whatever its pads carry). `pad_pair_clearance` is
        `pad_override_clearance(<this>, pad, other_pad)`."""
        eff = self.pair_clearance(getattr(pad, 'net_id', 0) or 0, other_net,
                                  base=base)
        if layer is not None:
            return self.layer_clearance(layer, eff)
        if self.layer_clearances:
            from check_drc import pads_shared_layer_clearance, pad_copper_layers
            cu = list(self.board_copper_layers or self.layers)
            eff = pads_shared_layer_clearance(
                eff, self.layer_clearances, pad_copper_layers(pad, cu),
                pad_copper_layers(other_pad, cu) if other_pad is not None
                else None)
        return eff

    def net_clearances_by_name(self, nets) -> Dict[str, float]:
        """The class map keyed by NET NAME, for a consumer that re-parses a
        board whose net ids may differ from this run's (the KiCad oracle reads
        a staged copy; on the GUI path that is a pcbnew save, which numbers
        its nets afresh, #1133). `nets` is `pcb_data.nets`."""
        out: Dict[str, float] = {}
        for nid, c in (self.net_clearances or {}).items():
            name = getattr(nets.get(nid), 'name', None)
            if name and c:
                out[name] = float(c)
        return out

    def get_track_width(self, layer: str) -> float:
        """Get track width for a specific layer (impedance-aware).

        If impedance targeting is enabled and layer_widths is populated,
        returns the layer-specific width. Otherwise returns the default track_width.
        """
        if self.layer_widths and layer in self.layer_widths:
            return self.layer_widths[layer]
        return self.track_width

    def route_reserve_width(self, layer: str) -> float:
        """Routing-side track width (mm) the obstacle stamps reserve on `layer`
        for the FUTURE routed track (#156). This is the single source of truth
        for the stamp side of the margin mechanism: per-net track_margins are
        always computed AGAINST this value, so stamps and margins cannot drift.

        - reserve_layer_widths=False (single-ended engine): the NOMINAL
          track_width, floored to the layer width when the impedance width is
          narrower (never reserve more than the widest narrow case needs);
          any net routing wider -- power override or impedance layer width --
          covers its extra half-width via its own fractional track_margin.
        - reserve_layer_widths=True (diff-pair engine): the full per-layer
          impedance width, baked mm-exact into the map (pose router has no
          margin channel)."""
        lw = self.get_track_width(layer)
        if self.reserve_layer_widths:
            return lw
        return lw if lw < self.track_width else self.track_width

    def _phase_exact_margin(self, layer: str, net_width: float) -> float:
        """Fractional A* track margin (grid cells) on `layer` for a track of
        `net_width` (#156).

        Base value: the exact extra half-width over the stamps' reserve,
        e = (net_width - route_reserve_width)/2/grid -- no ceil, no +1.

        Phase correction: a margin measures to the outermost BLOCKED CELL
        (the stamp's shell), which sits up to one cell inside the true
        keep-out radius, so a bare `e` can sit fractionally below the
        integer row distance that must be rejected (berkeley In2: e=0.988
        vs a violating row at n=1 -> 77um grazes between same-run tracks).
        mm-exact baking never has this problem because its stamp radius IS
        the requirement. For each dominant obstacle class -- a foreign
        track at the reserve width (narrow stubs), the layer's routing
        width (same-run impedance peers), or this track's own width (power
        peers) -- compute the margin that rejects EXACTLY the grid rows
        baking at the true requirement would reject, and take the largest.
        Rows are counted on BOTH movement axes: the axis-aligned rows (1 cell
        apart) and the 45-degree rows (1/sqrt(2) cells apart, #505) -- an
        orthogonally-derived margin can sit below the sqrt(2) shell step and
        so reject nothing at all diagonally.
        The result is then snapped onto the lattice (_snap_to_lattice_reach),
        because a margin BETWEEN two cell-to-cell distances rejects exactly what
        the lower one rejects. It is always >= e, and usually still under the
        blunt e+1 (e=1.25 -> 2.0, not 2.25) -- but NOT always: where the reach
        e*sqrt(2) crosses a lattice distance the snap can exceed e+1 (e=1.70 ->
        3.0). Correctness wins there; an undershoot is a clearance violation,
        an overshoot only costs some routability."""
        reserve = self.route_reserve_width(layer)
        e = (net_width - reserve) / 2.0 / self.grid_step
        if e <= 1e-9:
            return 0.0
        # Predict the stamp shell with the same clearance most stamps price
        # obstacles at: the cross-class routing-side floor when one is active
        # (obstacle_clearance() maxes it per obstacle), else the base clearance.
        clr = self.net_clearance_floor if self.net_clearance_floor is not None else self.clearance
        margin = e
        for w_obs in (reserve, self.get_track_width(layer), net_width):
            # Stamped keep-out and true requirement around this obstacle
            # class, in grid cells (both measured from the track CENTER).
            r_stamp = (w_obs / 2.0 + clr + reserve / 2.0) / self.grid_step
            r_need = r_stamp + e
            shell = math.ceil(r_stamp - 1e-9) - 1     # outermost blocked row
            n_max = math.ceil(r_need - 1e-9) - 1 - shell  # last row to reject
            if n_max > margin:
                margin = float(n_max)
        return _snap_to_lattice_reach(margin, e)

    def track_margins_for_net(self, net_id: int) -> List[float]:
        """Per-layer FRACTIONAL A* track margins (grid cells) for `net_id`
        (#156): the net's extra half-width over what the obstacle stamps
        already reserve on each layer, phase-corrected per obstacle class
        (see _phase_exact_margin). Uniform for power nets, per-layer for
        impedance widths, all-zero for base-width nets."""
        return [self._phase_exact_margin(layer, self.get_net_track_width(net_id, layer))
                for layer in self.layers]

    def track_margins_for_width(self, width: float) -> List[float]:
        """Per-layer track margins (grid cells) for a track of uniform `width`
        (the power neck-down ladder's reduced widths, #156)."""
        return [self._phase_exact_margin(layer, width) for layer in self.layers]

    def base_track_margins(self) -> List[float]:
        """Per-layer track margins (grid cells) for a route at each layer's OWN
        base routing width (a necked-down power trunk, #156): zero on plain
        runs, the impedance extra on impedance runs."""
        return [self._phase_exact_margin(layer, self.get_track_width(layer))
                for layer in self.layers]

    def get_max_track_width(self) -> float:
        """Get the maximum track width across all layers.

        Used for via clearance calculations where we need to ensure clearance
        for the widest possible track (e.g., when a via connects two layers
        with different impedance-controlled widths).
        """
        if self.layer_widths or self.coplanar_layer_widths:
            # Both maps can be live at once when only SOME nets are coplanar
            # (#486); the widest track on any layer is what via clearance has
            # to cover, so take the max over both.
            return max(list(self.layer_widths.values())
                       + list(self.coplanar_layer_widths.values()),
                       default=self.track_width)
        return self.track_width

    def get_net_track_width(self, net_id: int, layer: str) -> float:
        """Get track width for a specific net on a specific layer.

        Priority order:
        1. Per-net power width override (power_net_widths) -- floored UP to track_width
        2. Per-net netclass width (net_track_widths) -- the net's OWN class width,
           EXACTLY (may be narrower than the global track_width); floored at the fab
           minimum by the caller. Only populated when --track-width was omitted.
        3. Per-net COPLANAR impedance width (coplanar_layer_widths, #486) -- the
           net was declared to run through a ground pour, so its width comes
           from the CPW-over-ground model rather than microstrip.
        4. Layer-specific width (layer_widths, for impedance control)
        5. Default track_width

        Args:
            net_id: The net ID to get width for
            layer: The layer name

        Returns:
            Track width in mm
        """
        if net_id in self.power_net_widths:
            # Ensure power net width is at least the base track width
            return max(self.power_net_widths[net_id], self.track_width)
        if self.net_layer_widths and net_id in self.net_layer_widths:
            # #521: per-net per-layer widths reapplied from a stored impedance
            # declaration (.kicad_pro net_impedance) -- a redo of an
            # impedance-routed net must come back at ITS width, not this
            # call's default. Outranks the netclass scalar for the same
            # reason --impedance outranks --track-width.
            w = self.net_layer_widths[net_id].get(layer)
            if w:
                return w
        if self.net_track_widths and net_id in self.net_track_widths:
            # #435 companion: route this net at its OWN class width (either direction).
            return self.net_track_widths[net_id]
        if self.coplanar_net_ids and net_id in self.coplanar_net_ids \
                and layer in self.coplanar_layer_widths:
            return self.coplanar_layer_widths[layer]
        return self.get_track_width(layer)

    def get_net_clearance(self, net_id: int) -> float:
        """Clearance for stamping THIS net's copper as an obstacle (#326 B5):
        its netclass clearance when above the global value, else the global
        clearance. Never smaller than `clearance` (netclasses only widen)."""
        nc = self.net_clearances.get(net_id, 0.0) if self.net_clearances else 0.0
        return nc if nc > self.clearance else self.clearance

    def get_layer_costs(self) -> List[int]:
        """Get layer cost multipliers for the Rust router.

        Returns costs scaled by 1000 (1000 = 1.0x, 1500 = 1.5x penalty).
        If layer_costs is empty or shorter than layers list, uses 1000 (1.0x) for missing layers.
        A cost of -1 (FORBIDDEN_LAYER_COST) is emitted VERBATIM (not scaled): the Rust
        router skips track placement on any layer whose cost is negative, while the layer
        stays an obstacle and through-vias may span it.
        """
        layer_costs = self.layer_costs or []  # may be None when set explicitly
        costs = []
        for i in range(len(self.layers)):
            if i < len(layer_costs):
                cost = layer_costs[i]
                if cost < 0:
                    # Forbidden: emit the canonical sentinel UNSCALED. The Rust
                    # router treats ANY negative entry as forbidden, so every
                    # negative input folds to one value here -- this also avoids
                    # int(cost * 1000) truncating a tiny negative in (-0.001, 0)
                    # up to 0 (a zero-cost layer, NOT forbidden).
                    costs.append(FORBIDDEN_LAYER_COST)
                else:
                    costs.append(int(cost * 1000))
            else:
                costs.append(1000)  # Default 1.0x
        return costs

    def layer_costs_for(self, layers) -> List[int]:
        """:meth:`get_layer_costs` aligned to `layers` BY NAME (#1185), for a
        router whose obstacle map indexes some other list than
        ``self.layers``. Each layer gets its own cost (a forbidden -1 stays
        forbidden); a layer ``self.layers`` does not list is 1.0x. Indexing
        the costs positionally against another list is how the plane repair's
        region joins read ``[1.0, 1.5, 3.0, 1.0]`` as ``[1000, 1500]`` on a
        4-layer board and laid +3V3 straps on a forbidden GND layer."""
        by_name = dict(zip(self.layers, self.get_layer_costs()))
        return [by_name.get(layer, 1000) for layer in layers]

    def get_layer_direction_preferences(self) -> List[int]:
        """Get layer direction preferences for the Rust router.

        Returns list of preferences: 0=horizontal, 1=vertical, 255=none.
        Pattern alternates H/V starting with horizontal on top layer.
        Returns empty list if direction_preference_cost is 0 (disabled).
        """
        if self.direction_preference_cost == 0:
            return []  # Disabled
        prefs = []
        for i in range(len(self.layers)):
            # Alternate: even layers (0, 2, 4) = horizontal (0), odd layers (1, 3, 5) = vertical (1)
            prefs.append(i % 2)
        return prefs

    def cell_cost(self, cost_mm: float) -> int:
        """Per-cell cost units for costs that accumulate per visited cell
        (proximity penalties, attraction bonuses).

        Cost knobs are calibrated at REFERENCE_GRID_STEP: the per-cell value
        scales with grid_step so the accumulated cost per mm of path is
        independent of --grid-step (a finer grid visits proportionally more
        cells). At 0.1mm this reproduces the historical values exactly.
        """
        # soft-knobs B5: per-cell units are CONSTANT per cell (no grid_step
        # factor). The old extra (grid_step/REFERENCE) factor made every
        # per-cell knob relatively 2x/4x weaker at fine grids (0.05/0.025 --
        # exactly the fine-pitch ladder and net_rescue grids) and 2x stronger
        # at 0.2, because the base move cost per mm is 1000/grid_step, not
        # constant. Identical to the old value at the 0.1 reference grid.
        return int(cost_mm * 1000 / REFERENCE_GRID_STEP)

    def scaled_cell_units(self, units: float) -> int:
        """Per-cell cost knobs in raw units calibrated at REFERENCE_GRID_STEP
        (e.g. bus_attraction_bonus). soft-knobs B5: constant per cell -- the
        old (grid_step/REFERENCE) factor broke relative strength vs the move
        cost at non-reference grids. Identical at 0.1."""
        return int(units)

    def via_cost_units(self) -> int:
        """Per-via penalty in cost units.

        The via_cost knob is in grid steps at REFERENCE_GRID_STEP (default 75
        = 7.5mm of path, #586); the value scales with 1/grid_step so a via
        costs the same mm-equivalent detour at any --grid-step.
        """
        return int(self.via_cost * 1000 * (REFERENCE_GRID_STEP / self.grid_step))

    def via_proximity_cost_int(self) -> int:
        """Rust-facing integer via-proximity multiplier.

        0 means NO EXTRA via cost from proximity -- the same "0 = off"
        convention as every other soft knob. (Historically 0 meant BLOCK
        vias in proximity zones; that inverted mode -- 0 as the STRONGEST
        setting -- is removed. The single-ended router multiplies the
        graded proximity cost by this value, so 0 is naturally inert
        there.) Any positive fraction rounds to at least 1 (soft-knobs
        review B3: a GUI value of 0.5 passed through bare int() became 0,
        silently weaker than both settings around it).
        """
        c = self.via_proximity_cost
        return 0 if c == 0 else max(1, int(round(c)))

    def get_proximity_heuristic_cost(self) -> int:
        """Get the maximum proximity heuristic cost for the Rust router.

        Auto-computes expected proximity cost per grid step based on stub/track/BGA
        proximity settings. This tightens the A* heuristic for boards with high
        proximity costs, dramatically reducing search space (up to 6x speedup).

        The formula weights each proximity cost by its radius (larger radius = more
        of the path affected), sums them, and applies a coverage factor.

        Returns cost scaled for grid units (cost per grid step).
        """
        # Weight each proximity cost by its radius (larger radius = more path affected)
        stub_weight = self.stub_proximity_cost * self.stub_proximity_radius
        track_weight = self.track_proximity_cost * self.track_proximity_distance
        bga_weight = self.bga_proximity_cost * self.bga_proximity_radius
        total_weight = stub_weight + track_weight + bga_weight

        if total_weight > 0:
            # Simple formula: total_weight * factor
            # Default factor 0.02 is conservative to avoid overestimating for paths
            # that don't go through proximity zones. Tuned for ~5mm typical radius.
            estimated_cost = total_weight * self.proximity_heuristic_factor
            return self.cell_cost(estimated_cost)
        return 0

    def get_proximity_heuristic_for_zones(self, src_in_stub: bool, src_in_bga: bool,
                                          tgt_in_stub: bool, tgt_in_bga: bool) -> int:
        """Get proximity heuristic cost based on which zones the endpoints are in.

        More precise than get_proximity_heuristic_cost() - only adds costs for
        zones that the source or target is actually inside.

        Args:
            src_in_stub: True if source is in a stub proximity zone
            src_in_bga: True if source is in a BGA proximity zone
            tgt_in_stub: True if target is in a stub proximity zone
            tgt_in_bga: True if target is in a BGA proximity zone

        Returns cost scaled for grid units (cost per grid step).
        """
        total_weight = 0.0

        # Source endpoint zones
        if src_in_stub:
            total_weight += self.stub_proximity_cost * self.stub_proximity_radius
        if src_in_bga:
            total_weight += self.bga_proximity_cost * self.bga_proximity_radius

        # Target endpoint zones
        if tgt_in_stub:
            total_weight += self.stub_proximity_cost * self.stub_proximity_radius
        if tgt_in_bga:
            total_weight += self.bga_proximity_cost * self.bga_proximity_radius

        if total_weight > 0:
            estimated_cost = total_weight * self.proximity_heuristic_factor
            return self.cell_cost(estimated_cost)
        return 0


class GridCoord:
    """Utilities for converting between float (mm) and integer grid coordinates."""
    def __init__(self, grid_step: float = 0.1):
        self.grid_step = grid_step
        self.inv_step = 1.0 / grid_step

    def to_grid(self, x: float, y: float) -> Tuple[int, int]:
        """Convert float mm coordinates to integer grid coordinates."""
        return (round(x * self.inv_step), round(y * self.inv_step))

    def to_float(self, gx: int, gy: int) -> Tuple[float, float]:
        """Convert integer grid coordinates to float mm coordinates."""
        return (gx * self.grid_step, gy * self.grid_step)

    def to_grid_dist(self, dist_mm: float) -> int:
        """Convert a distance in mm to grid units (rounds down)."""
        return int(dist_mm * self.inv_step)

    def to_grid_dist_safe(self, dist_mm: float) -> int:
        """Convert a distance in mm to grid units, rounding up for safety."""
        return math.ceil(dist_mm * self.inv_step)
