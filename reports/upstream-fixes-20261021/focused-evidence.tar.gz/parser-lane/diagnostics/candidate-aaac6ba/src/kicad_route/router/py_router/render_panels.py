#!/usr/bin/env python3
"""The stage3d layer column: the per-layer strip and the board's numbers
(#946 items 6/10/11, #1020, #1081).

One fixed box, beside the board (a row under it on a portrait frame), the
SAME content on every frame: the per-layer strip, with the board's summary
-- parts, nets, layers, copper -- under it when there is room. It sits beside
a 3D board that already shows the placement, so it no longer switches by
phase: the placement inventory, the seeding pile and the bookend summary it
used to swap between were the retired layouts' lower box. The frame height
never changes, because Pillow does not raise on a mismatch and the GIF comes
out valid and quietly distorted.

**THE STRIP BUILDS NO SECOND RENDERER.** `tests/test_431_placement_movie.py:92`
asserts exactly one `BoardRenderer` on the no-stage path, so a strip of ten
small boards cannot construct ten of them. It draws the copper directly into
each cell with its own scale, the way `awx/evolve_movie` draws its mini-boards.

**EVERY DRAWER REPORTS WHAT IT DREW.** `draw_layer_strip` returns a `Cell` per
cell carrying the count string it actually stamped and the number of copper
lines it actually issued -- not the tally it computed. The phase-1 verifier
measured why: a test that re-derives the counts from `pcb.segments` and never
reads the drawing passes unchanged when every cell draws `cnt + 7`, and passes
unchanged when every cell counts and draws EVERY segment on the board. Both
mutants survived while the test printed "PASS: every cell counts its own
layer". A region cannot be asked by pixel what number it wrote -- that would
need OCR -- so it reports, exactly as `render_chrome.draw_totals` does.

**AND A COUNT THAT DOES NOT FIT IS DROPPED, NOT OVERPRINTED.** `CELL_MIN_W`
bounds the cell WIDTH; nothing bounded the text, so at the widths this feature
actually produces the count was stamped on top of the layer name -- measured at
+25 px of overlap at `CELL_MIN_W` exactly, +23 px in the 180 px case the test
itself exercises, and visible in the phase's own acceptance image ("F75",
"In1390"). The name is the identity and the count is the extra, so the count
goes and the returned `Cell` says so.
"""
from __future__ import annotations

import os
import sys
from typing import List, NamedTuple

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

#: Below this cell width a layer cell cannot show a route, only that copper
#: exists. Measured when there were several layouts: at one pixel budget
#: the (retired) inset layout gave 28 490 px per cell against the split
#: layout's 128 800 -- a 4.5x penalty, which is what makes a floor on the
#: CELL rather than on the count the right guard.
CELL_MIN_W = 26

#: And below THIS a cell cannot be drawn at all -- `d.rectangle` raises when
#: `x1 < x0`, which the never-fail wrapper would turn into a blank panel with
#: nothing said. Measured: without it a 10 px box solved to a cell -2 px wide.
CELL_FLOOR_W = 8

#: The same fault on the OTHER axis, which the first fix missed and the
#: round-2 verifier measured: a cell's mini-board starts `caption_h` below the
#: cell top, so a short cell inverts that rectangle and `d.rectangle` raises
#: "y1 must be greater than or equal to y0". **1143 of 4010 (width, height)
#: combinations** did it, at panel heights 13/14/20 px -- rects
#: the retired layouts produced on their own (`legacy --size 100` gave a
#: 100x16 panel). Every one was swallowed into a blank box with nothing said.
CELL_FLOOR_H = 6

#: Gap between the layer name and its count. Below it they are touching, which
#: is the defect this constant exists to refuse.
LABEL_GAP_PX = 5


class Cell(NamedTuple):
    """What ONE cell of the strip actually drew.

    `count_text` is the string handed to `d.text`, not the tally behind it, and
    `''` means the count did not fit and was dropped. `lines` is how many
    copper segments were actually stroked. Both are the drawing's own report;
    `count` is what the caller's data said, so a test can compare the two.
    """
    layer: str
    count: int
    count_text: str
    name_text: str
    lines: int
    box: tuple


def _cell_boxes(box, n, gap=6, caption_h=14):
    """`(boxes, n)` -- `n` cells across `box`, left to right.

    ALWAYS a 2-tuple. It used to return a bare `[]` on the empty path while its
    only caller unpacked two values, so a zero-width box raised `ValueError`
    into a bare `except` and the panel went blank with nothing said. Reachable
    only at `box.w <= 0`, which `plan_frame._self_check` `continue`s past
    rather than refusing -- so it was unreachable by luck, not by design.

    **BOTH AXES ARE FLOORED**, which the first version of this guard got half
    right: a cell has to hold its caption AND a mini-board below it, so a short
    cell inverts the board rectangle and `d.rectangle` raises. Measured at 1143
    of 4010 (width, height) combinations, at panel heights `plan_frame`
    produces on its own.
    """
    if n <= 0 or box is None or box.w <= 0 or box.h <= 0:
        return [], 0
    cw = (box.w - gap * (n + 1)) / float(n)
    if cw < CELL_MIN_W:
        # Fewer, wider cells beat more, unreadable ones: a cell too small to
        # show a route costs pixels and answers nothing.
        n = max(1, int((box.w - gap) // (CELL_MIN_W + gap)))
        cw = (box.w - gap * (n + 1)) / float(n)
    ch = box.h - 2 * gap
    if cw < CELL_FLOOR_W or ch < caption_h + CELL_FLOOR_H:
        return [], 0
    return [(int(box.x + gap + i * (cw + gap)), int(box.y + gap),
             int(cw), int(ch)) for i in range(n)], n


#: A cell's mini-board is at most this much wider than the board is (#946
#: review). Cells shaped by the panel rather than the board came out 85x500
#: in a 1:1 sidebar, with the copper a thumbnail in the middle of each.
CELL_ASPECT_CAP = 1.0

#: How much smaller than the largest-cell grid a squarer grid may make its
#: cells and still win (`grid_boxes`).
GRID_BALANCE = 0.72


def grid_boxes(box, n, aspect, gap=6, caption_h=14):
    """`(boxes, n, grid_h)`: `n` cells shaped like the BOARD, in a grid.

    Every columns count from 1 to `n` is tried and the one giving the largest
    mini-board wins -- so a wide lower box gets one row, and a tall column (the
    1:1 sidebar) gets a 2x2 grid. Each cell's mini-board keeps the board's
    `aspect` (capped at `CELL_ASPECT_CAP` of it). The grid is centred
    horizontally in `box`, starts at its top, and `grid_h` is its height, so
    a caller can centre it vertically or use the space under it.
    """
    if n <= 0 or box is None or box.w <= 0 or box.h <= 0 or not aspect:
        return [], 0, 0
    cands = []
    for cols in range(1, n + 1):
        rows = -(-n // cols)
        cw = (box.w - gap * (cols + 1)) / float(cols)
        ch = (box.h - gap * (rows + 1)) / float(rows) - caption_h
        if cw < CELL_FLOOR_W or ch < CELL_FLOOR_H:
            continue
        mw = min(cw, ch * aspect * CELL_ASPECT_CAP)
        mh = mw / aspect
        cands.append((mw * mh, cols, rows, mw, mh))
    if not cands:
        return [], 0, 0
    # The largest cells, EXCEPT that a squarer grid wins when its cells are
    # within GRID_BALANCE of the largest: four boards stacked in a tall
    # column read as a list, four in a 2x2 as four views of one board -- the
    # 1:1 sidebar's single column beat 2x2 by 22% on area and looked worse.
    top = max(c[0] for c in cands)
    near = [c for c in cands if c[0] >= GRID_BALANCE * top]
    _a, cols, rows, mw, mh = min(near, key=lambda c: (abs(c[1] - c[2]),
                                                      -c[0]))
    cw, chh = int(mw), int(mh + caption_h)
    gw = cols * cw + (cols - 1) * gap
    x0 = box.x + (box.w - gw) // 2
    boxes = []
    for i in range(n):
        r_, c_ = divmod(i, cols)
        boxes.append((int(x0 + c_ * (cw + gap)),
                      int(box.y + gap + r_ * (chh + gap)), cw, chh))
    return boxes, n, rows * chh + (rows + 1) * gap


def draw_layer_strip(d, box, *, bounds, segments, layers, palette, theme,
                     caption_h=14, active=None, grid=False) -> List[Cell]:
    """Small multiples: one mini board per copper layer.

    Colour stops carrying layer identity here and POSITION carries it instead
    -- and position never collides, which is the answer to the 19 crossings
    that could impersonate a third layer. Each cell draws at full strength on
    its own ground, so there is no alpha dimming either.

    Returns one `Cell` per cell DRAWN; `len()` is the cell count the caller
    used to read off the old integer return. See the module docstring for why
    the return carries the drawn strings rather than the computed tallies.
    """
    if box is None or box.h <= 0 or not layers:
        return []
    out: List[Cell] = []
    try:
        import render_theme
        from route_render import load_font
        th = theme or render_theme.default_theme()
        if grid:
            _x0, _y0, _x1, _y1 = bounds
            _asp = max(_x1 - _x0, 1e-6) / max(_y1 - _y0, 1e-6)
            boxes, n, _gh = grid_boxes(box, len(layers), _asp,
                                       caption_h=caption_h)
        else:
            boxes, n = _cell_boxes(box, len(layers), caption_h=caption_h)
        if not n:
            return []
        shown = layers[:n]
        font = load_font(max(8, min(13, int(box.h * 0.16))))
        min_x, min_y, max_x, max_y = bounds
        bw = max(max_x - min_x, 1e-6)
        bh = max(max_y - min_y, 1e-6)
        by_layer = {}
        for s in segments:
            by_layer.setdefault(s.layer, []).append(s)
        for i, ln in enumerate(shown):
            cx, cy, cw, ch = boxes[i]
            iy = cy + caption_h
            ih = max(2, ch - caption_h)
            d.rectangle([cx, cy, cx + cw - 1, cy + ch - 1],
                        fill=th.rgb('chrome_panel'),
                        outline=(th.rgb('pad') if ln == active
                                 else th.rgb('chrome_rule')))
            d.rectangle([cx + 1, iy, cx + cw - 2, cy + ch - 2],
                        fill=th.rgb('board_body'))
            sc = min((cw - 4) / bw, (ih - 4) / bh)
            ox = cx + 2 + ((cw - 4) - bw * sc) / 2
            oy = iy + 2 + ((ih - 4) - bh * sc) / 2
            col = palette.get(ln, th.rgb('chrome_text_dim'))
            cnt = drew = 0
            for s in by_layer.get(ln, ()):
                cnt += 1
                d.line([ox + (s.start_x - min_x) * sc,
                        oy + (s.start_y - min_y) * sc,
                        ox + (s.end_x - min_x) * sc,
                        oy + (s.end_y - min_y) * sc],
                       fill=col, width=1)
                # AFTER the call, and a separate counter from `cnt`: a `lines`
                # field that is just the tally under another name reports
                # "drew 390" for a cell that drew nothing, which is the exact
                # shape of the defect this return value exists to catch.
                drew += 1
            name = ln.replace('.Cu', '')
            # The count is DROPPED rather than overprinted when the two strings
            # would touch: the name is the identity, the count is the extra.
            num = str(cnt)
            room = (cw - 8) - d.textlength(name, font=font) - LABEL_GAP_PX
            if d.textlength(num, font=font) > room:
                num = ''
            d.text((cx + 4, cy + 1), name, font=font,
                   fill=(th.rgb('pad') if ln == active
                         else th.rgb('chrome_text_dim')))
            if num:
                d.text((cx + cw - 4, cy + 1), num, font=font,
                       fill=th.rgb('chrome_text_faint'), anchor='ra')
            out.append(Cell(ln, cnt, num, name, drew, (cx, cy, cw, ch)))
        if len(layers) > n:
            # In the CELL CAPTION band, beside the last cell's own name, not
            # over its mini-board: drawn at the box's bottom it grazed the last
            # cell's copper by 4 px in every case the verifier measured.
            last = boxes[n - 1]
            d.text((box.x + box.w - 2, last[1] + last[3] + 2),
                   '+%d more' % (len(layers) - n), font=font,
                   fill=th.rgb('chrome_text_faint'), anchor='ra')
        return out
    except Exception:                                          # noqa: BLE001
        return out       # a panel is never worth failing a render over


def draw_summary(d, box, *, lines, theme):
    """What this board IS, in numbers -- parts, nets, layers, copper -- under
    the layer strip, so the closing frame can be read against the opening
    one.
    """
    drawn = []
    if box is None or box.h <= 0 or not lines:
        return drawn
    try:
        import render_theme
        from route_render import load_font
        th = theme or render_theme.default_theme()
        # EVERY row it was given must land. Two failures measured, in order:
        # at a fixed 15 pt in a 132 px box the fifth row (`vias`) was clipped
        # away; sizing the font from the row COUNT fixed that at `--size 1000`
        # and still dropped one row on `stacked` at `--size 400` and three on
        # `inset`. So when one column cannot hold them, it WRAPS to two --
        # a summary that silently drops its last row is a summary you cannot
        # read a closing frame against an opening one with.
        pad = 8
        d.rectangle([box.x, box.y, box.x + box.w - 1, box.y + box.h - 1],
                    fill=th.rgb('chrome_panel'))
        n = max(1, len(lines))
        cols = 1
        while cols <= 3:
            per = (n + cols - 1) // cols
            size = int((box.h - 2 * pad) / (1.45 * max(1, per)))
            if size >= 8 or cols == 3:
                break
            cols += 1
        per = (n + cols - 1) // cols
        font = load_font(max(7, min(15, int((box.h - 2 * pad)
                                            / (1.45 * max(1, per))))))
        lh = int(font.size * 1.45)
        cw = box.w // cols
        for i, (label, value) in enumerate(lines):
            col, row = i // per, i % per
            x = box.x + pad + col * cw
            y = box.y + pad + row * lh
            if y + lh > box.y + box.h or x + cw - pad > box.x + box.w:
                break
            d.text((x, y), str(label), font=font,
                   fill=th.rgb('chrome_text_dim'))
            d.text((x + int(cw * 0.56), y), str(value), font=font,
                   fill=th.rgb('chrome_text'))
            drawn.append((str(label), str(value)))
        return drawn
    except Exception:                                          # noqa: BLE001
        return drawn


def board_summary(pcb, segments=(), vias=()):
    """`[(label, value), ...]` for `draw_summary`, off the board in hand."""
    fps = getattr(pcb, 'footprints', {}) or {}
    nets = getattr(pcb, 'nets', {}) or {}
    info = getattr(pcb, 'board_info', None)
    layers = list(getattr(info, 'copper_layers', ()) or ()) if info else []
    return [('parts', len(fps)),
            ('nets', max(0, len(nets) - 1)),   # net 0 is "no net"
            ('copper layers', len(layers)),
            ('segments', len(segments)),
            ('vias', len(vias))]
