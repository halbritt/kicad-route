"""One body model for every placement instrument (#896).

WHAT THIS IS FOR
----------------
A footprint's "body" is not one thing a board file states; it is whatever the
library happened to draw. Before this module the answer was decided in five
places with three different ladders, and the ladder that most consumers used --
`legality.part_local_bounds` -- went straight from courtyard to the PAD BOUNDING
BOX. On a library that draws no courtyard, every placement instrument therefore
graded pad boxes and could not see a body at all.

Measured on `esp_prog` (OLIMEX), the board that produced #896: **0 of 21**
footprints draw a courtyard, and six of them -- CON1, CON2, U1, U2, Q1, Q2 --
draw no `.Fab` outline either. Those six are the connector housings, the SSOP
and the SOT89 whose collisions cost run 25 two laps; each was found only by an
adversarial reviewer writing its own geometry, because no checker in the chain
could see a housing at all.

TWO LADDERS, ONE READER
-----------------------
They answer different questions, so they are two values and not one value with
a flag:

    occupancy   courtyard -> fab -> silk U pad_bbox -> pad_bbox -> synthetic
    drawn body  fab -> silk U pad_bbox -> (nothing)

`occupancy_local` is *what does this part occupy* -- what a consumer deciding
whether something may be seated somewhere must read. It never shrinks.

`drawn_local` is *what did the library draw as this part's body*, and the
courtyard is deliberately NOT on it: a courtyard is a body plus an assembly
margin plus any shell overhang, which is exactly why run-6 calibrated the
courtyard channel and the fab channel apart. A part with both a courtyard and a
fab outline has `source == 'courtyard'` and `drawn_source == 'fab'` at once.

`source` and `drawn_source` name the rung that answered, always, so a consumer
reports "body from silk" rather than "no body", and a pad-bbox answer is
disclosed rather than passing as geometry somebody drew.

Two rules the ladders encode, both measured rather than assumed:

1. **Courtyard and fab are taken AS DRAWN; only the silk rung unions with the
   pads.** Silk is not an outline -- on a stock KiCad footprint it is a pair of
   clipped side ticks. Over the 10 esp_prog footprints that draw both fab and
   silk, the silk bbox is narrower than the fab body along the pad axis on 10 of
   10 (Y1: 0.508mm against a 3.200mm body, an 84% loss) and wider across it on
   10 of 10, so no offset reconciles them -- the sign of the error differs per
   axis. Taken bare, silk would SHRINK parts, which is the unsafe direction
   (`legality.LocalBounds`' own comment: shrinking can flip `zone_is_anchor`
   True->False, whose non-anchor branch has a strictly smaller admissible origin
   box). esp_prog Q1/Q2 (SOT23) would go from a 3.610 x 2.902 pad box to a
   0.838 x 2.845 silk box. Unioning the silk rung with the pad bbox removes that
   hazard entirely and -- verified -- changes none of the three numbers #896
   asks for.

   Unioning the courtyard and fab rungs too would be a DIFFERENT measurement:
   it moves lap-3 U1<->Y1 from -0.1330 to -0.2830, because Y1's pads overhang
   its fab body by 0.15mm on the facing side. That is the occupancy question,
   not the body question; see `occupancy_local` below.

2. **A pad-less footprint gets no silk body.** A logo, an OSHW mark or a
   decorative silk drawing is not a part to collide with. Measured: allowing
   them produced 5 corpus pairs above the run-23 blocking floors and ALL FIVE
   were logos (`logo`, `oshw:oshw`, `Glasgow:nono_hana_lines`). Refusing them
   leaves 4 new pairs corpus-wide and 0 above the floors.

NO OFFSET CONSTANT, DELIBERATELY. #896 proposes expanding silk by "the
silk-to-body offset the library uses, ~0.2 mm on OLIMEX". That is refuted by the
issue's own acceptance numbers: a 0.2mm expansion on both parts turns
-0.12 / -0.09 / -0.133 into -0.52 / -0.49 / -0.53. Silk at its stroke
centreline, unioned with the pads, reproduces all three exactly.

WHAT THIS MODULE DOES NOT DECIDE
--------------------------------
It reports geometry and its provenance. It does not waive, gate or price
anything, and a body never relaxes a pad-pair clearance -- pads remain the DRC
truth (`legality.grade_pad_legality`, `check_drc.check_pad_pad_overlap`).
"""
from __future__ import annotations

from typing import Dict, NamedTuple, Optional, Tuple

Bbox = Tuple[float, float, float, float]

# The rungs, in order, as they appear in `BodyGeometry.source`. `pad_bbox` and
# `none` keep the spellings `board_brief.parts_section` already ships so a
# reader meets one vocabulary; `courtyard`, `fab` and `silk` name the drawn
# geometry that answered.
SOURCE_COURTYARD = 'courtyard'
SOURCE_FAB = 'fab'
SOURCE_SILK = 'silk'
SOURCE_PADS = 'pad_bbox'
#: #1201: the occupancy of a part whose .Fab rung is a MARKING (a pin-1 dot,
#: a zero-width line) rejected as its body: the marking united with the pads,
#: exactly what that part occupied before the guard -- named for what it is.
SOURCE_FAB_MARKING = 'fab_marking'
SOURCE_NONE = 'none'

#: Ladder order, for reporting a source mix in a stable sequence.
SOURCES = (SOURCE_COURTYARD, SOURCE_FAB, SOURCE_FAB_MARKING, SOURCE_SILK,
           SOURCE_PADS, SOURCE_NONE)

#: #1201. A .Fab rung whose bbox covers less than this fraction of the pad
#: bbox's AREA is a marking, not a body. Measured
#: (`tests/measure_1201_fab_and_silk.py` and the phase-3 verifier's sweep of
#: KiCad 10's stock library): the markings reach 0.00466 -- all 204 on the
#: fa10 designer boards, 203 EasyEDA 0.06 mm pin-1 dots (CM5_MINIMA_3's USB-C
#: J101/USB701, One-Air-Max's BAT1) and CM5's Module301, whose only fab item
#: is a zero-width 0 x 48 mm line -- and the smallest real bodies are 0.0537
#: (stock TO-50-4_LongPad, PowerMacro_M234) and 0.3114 on the tracked corpus
#: (orangecrab J4). 0.02 sits near the log-midpoint of 0.00466 and 0.0537,
#: with a factor of about 2.7-4.3 either side; no stock footprint with a 2-D
#: fab body is rejected at any of six non-orthogonal angles. The ten stock
#: footprints it does reject are wire-bridge test points whose fab is a line.
FAB_MIN_PAD_AREA_FRAC = 0.02


def _area(b: Bbox) -> float:
    return max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])


def fab_cannot_be_body(fab: Optional[Bbox], pads: Optional[Bbox]) -> bool:
    """True when a .Fab bbox is too small to be the body of a part with these
    pads (#1201): under `FAB_MIN_PAD_AREA_FRAC` of the pad bbox's area.

    The fab rung used to be accepted unconditionally, while silk had a
    tick-mark guard: a 0.06 mm pin-1 `fp_circle` -- the only F.Fab item an
    EasyEDA-converted USB-C receptacle draws -- became that part's body, so
    its edge seat was graded on a point at the inboard corner ("seated 8.90mm
    from the nearest edge" for a part whose pads are 3.8 mm from it). A part
    with NO pads keeps its fab body: watchy's e-paper display draws one and
    has nothing to compare it with."""
    if fab is None or pads is None:
        return False
    pa = _area(pads)
    if pa <= 0.0:
        return False
    return _area(fab) < FAB_MIN_PAD_AREA_FRAC * pa


class BodyGeometry(NamedTuple):
    """One footprint's body, in the footprint's own UNROTATED local frame.

    `body_local` answers *what is this part's body* -- the assembly question, and
    the one #896's numbers are measured against. `occupancy_local` answers *what
    does this part occupy*, which is body united with the pad bbox: a part
    occupies its copper as well as its plastic, and a consumer that decides
    whether something may be SEATED somewhere must never be handed the smaller
    of the two. They are stored as two values rather than one value and a flag
    because they are two questions with two right answers.

    Both are `None` only when the footprint has neither drawn geometry nor pads,
    which is `SOURCE_NONE`; `legality.LocalBounds.synthetic` is the population
    that then falls back to the +-0.5mm fiction.

    `silk_rejected` records that silk was drawn but did not survive -- either
    the footprint has no pads (a logo) or its silk bbox lies inside the pad bbox
    (a pin-1 tick, a polarity bar), so the union is the pad bbox and the source
    reads `pad_bbox`. It is a disclosure, not an error: a fragment must not be
    LABELLED a body.
    """
    ref: str
    body_local: Optional[Bbox]
    occupancy_local: Optional[Bbox]
    source: str
    silk_rejected: bool = False
    # #896. The DRAWN BODY, on its own ladder: fab, else silk U pads, else
    # None. Deliberately NOT the winner of the ladder above, because a
    # courtyard is not a body -- it is a body plus an assembly margin plus any
    # shell overhang, which is why run-6 calibrated the courtyard channel and
    # the fab channel apart in the first place. A part can therefore have a
    # courtyard `source` and a fab `drawn_source` at once, and the body-overlap
    # channel reads THIS pair, not the occupancy one.
    drawn_local: Optional[Bbox] = None
    drawn_source: str = SOURCE_NONE
    # #1094. The drawn OUTLINES behind `body_local` (when the courtyard rung
    # answered) and `drawn_local` (when the fab rung answered), as shapely
    # geometry in the same local frame; None on every other rung. A bbox is
    # exact only while the part stays axis-aligned: at 45 degrees its corners
    # swing out past the drawing, which is how KiCad's StickHub demo graded 74
    # phantom courtyard pairs. `legality` uses these for the exact test and the
    # bboxes above as its broad phase.
    court_shape_local: object = None
    drawn_shape_local: object = None
    # #1206 (phase-2 verifier). A courtyard the footprint draws on its FAR
    # face, when it draws its own face too (`legality.far_courtyard_of`):
    # part of a through-hole part's far side, which KiCad grades there.
    far_court_local: Optional[Bbox] = None
    # #1212 (second phase-3 verifier). How each courtyard outline was read
    # (`parser.OUTLINE_POLYGON`: it closes; `OUTLINE_HULL`: it does not, and
    # its vertices' hull stands in), and the far one's OUTLINE. KiCad tests a
    # pin against a courtyard only when the outline closes -- an open one is
    # `malformed_courtyard` and no courtyard at all -- and against the far
    # one as drawn, not its bbox.
    court_shape_how: str = ''
    far_court_shape_local: object = None
    far_court_shape_how: str = ''
    # #1155. The pad bbox the ladders above united with (None for a pad-less
    # part), in the same local frame. `mating.mating_face_local` reads a
    # connector's mating face as the drawn body's offset off THIS box, so it
    # is carried rather than recomputed by a second reader.
    pads_local: Optional[Bbox] = None
    # #1201. A .Fab drawing was present but rejected as a body
    # (`fab_cannot_be_body`: a pin-1 dot), so the drawn ladder fell through
    # to silk, then the occupancy ladder to courtyard / pads. A disclosure,
    # like `silk_rejected`: the part is not body-less, its fab is a marking.
    fab_rejected: bool = False
    # #1245. The "PCB Edge" marker the footprint draws (`parser.EdgeMarker`:
    # its texts and straight lines, local frame), or None when it draws
    # none. Raw, like the bboxes above: `mating.marker_face_local` reads it,
    # so every consumer of a mating face gets it through this record.
    edge_marker: object = None


def _union(a: Bbox, b: Bbox) -> Bbox:
    return (min(a[0], b[0]), min(a[1], b[1]),
            max(a[2], b[2]), max(a[3], b[3]))


def _contained(inner: Bbox, outer: Bbox, eps: float = 1e-9) -> bool:
    return (inner[0] >= outer[0] - eps and inner[1] >= outer[1] - eps
            and inner[2] <= outer[2] + eps and inner[3] <= outer[3] + eps)


def _for_side(sides: Optional[Dict[str, Bbox]],
              side: str) -> Optional[Bbox]:
    """The bbox a part on `side` should use: its own side's if drawn, else the
    other side's, else None.

    Deliberately the same rule as `parser.courtyard_for_side`, and it calls it,
    so the three rungs cannot drift apart on the "library drew only the F side"
    case -- which is common enough that the courtyard reader documents it.
    """
    from placement.parser import courtyard_for_side
    return courtyard_for_side(sides, side)


def _shape_for_side(shapes: Optional[Dict[str, tuple]], side: str):
    """The outline geometry `_for_side` would pick the bbox of, or None."""
    return _shape_how_for_side(shapes, side)[0]


def _shape_how_for_side(shapes: Optional[Dict[str, tuple]], side: str):
    """`(geometry, how)` `_shape_for_side` picks, or `(None, '')`."""
    if not shapes:
        return None, ''
    got = shapes.get(side) or next(iter(shapes.values()))
    return (got[0], got[1]) if got else (None, '')


def body_geometry(fp, side: str,
                  courtyard_sides: Optional[Dict[str, Bbox]] = None,
                  fab_sides: Optional[Dict[str, Bbox]] = None,
                  silk_sides: Optional[Dict[str, Bbox]] = None,
                  ref: str = '',
                  courtyard_shapes: Optional[Dict[str, tuple]] = None,
                  fab_shapes: Optional[Dict[str, tuple]] = None,
                  edge_marker=None
                  ) -> BodyGeometry:
    """THE ladder, for one footprint. Per-side bboxes come from the caller.

    Split from `board_bodies` so a consumer that already holds the three
    per-side maps (the quench holds one, `grade_body_overlap` holds two) pays
    the file read once, and so the rung logic has exactly one home.
    """
    from placement.utility import compute_footprint_bbox_local
    from placement.legality import far_courtyard_of
    from kicad_parser import non_aperture_pads

    ref = ref or getattr(fp, 'reference', '') or ''
    far_court = far_courtyard_of(courtyard_sides, side)
    far_shape, far_how = None, ''
    if far_court is not None and courtyard_shapes:
        _far = courtyard_shapes.get('B' if side == 'F' else 'F')
        if _far:
            far_shape, far_how = _far[0], _far[1]
    pads: Optional[Bbox] = None
    # An aperture-only pad is not a pad here (#1143): a part whose only pads
    # are paste windows has no pads rung, like a pad-less one.
    if non_aperture_pads(fp):
        try:
            pads = compute_footprint_bbox_local(fp)
        except Exception:                                    # noqa: BLE001
            pads = None

    fab = _for_side(fab_sides, side)
    silk = _for_side(silk_sides, side)
    fab_rejected = False
    marking: Optional[Bbox] = None
    if fab is not None and fab_cannot_be_body(fab, pads):
        # #1201: a marking, not a body -- the rung falls through to silk.
        marking, fab, fab_rejected = fab, None, True

    # -- the DRAWN-BODY ladder: fab, else silk U pads. Courtyard is not on it.
    drawn_local: Optional[Bbox] = None
    drawn_source = SOURCE_NONE
    silk_rejected = False
    if fab is not None:
        drawn_local, drawn_source = fab, SOURCE_FAB
    elif silk is not None:
        if pads is None:
            # Rule 2: a pad-less footprint gets no SILK body. A logo, an OSHW
            # mark or a decorative drawing is not a part to collide with, and
            # allowing them put 5 corpus pairs above the run-23 floors, all
            # five of them logos.
            silk_rejected = True
        else:
            # Rule 1: the silk rung unions with the pads, because silk alone
            # is a pair of clipped ticks and would SHRINK the part.
            body = _union(silk, pads)
            if _contained(silk, pads):
                # A tick mark: the union IS the pad bbox, so it says nothing
                # about the body and must not be labelled one.
                silk_rejected = True
            else:
                drawn_local, drawn_source = body, SOURCE_SILK

    # -- the OCCUPANCY ladder: courtyard, else the drawn body, else the pads.
    court = _for_side(courtyard_sides, side)
    if court is not None:
        body_local, source = court, SOURCE_COURTYARD
    elif drawn_local is not None and not fab_rejected:
        body_local, source = drawn_local, drawn_source
    elif fab_rejected:
        # #1201: a part whose .Fab rung is a marking. Its BODY is its silk
        # united with its pads (else its pads), never the dot; what it
        # OCCUPIES is unchanged by the guard -- the marking united with the
        # pads, as before, set below and labelled `fab_marking`. Not the
        # silk: a silk occupancy never gates (#896).
        body_local, source = (drawn_local or pads), SOURCE_FAB_MARKING
    elif pads is not None:
        body_local, source = pads, SOURCE_PADS
    else:
        return BodyGeometry(ref, None, None, SOURCE_NONE,
                            silk_rejected=silk_rejected,
                            drawn_local=None, drawn_source=SOURCE_NONE,
                            far_court_local=far_court,
                            far_court_shape_local=far_shape,
                            far_court_shape_how=far_how,
                            pads_local=pads, fab_rejected=fab_rejected,
                            edge_marker=edge_marker)

    occupancy = (body_local if pads is None else _union(body_local, pads))
    if source == SOURCE_FAB_MARKING:
        # The one rung whose occupancy is not body U pads (see above).
        occupancy = _union(marking, pads)
    court_shape, court_how = (_shape_how_for_side(courtyard_shapes, side)
                              if source == SOURCE_COURTYARD else (None, ''))
    drawn_shape = (_shape_for_side(fab_shapes, side)
                   if drawn_source == SOURCE_FAB else None)
    return BodyGeometry(ref, body_local, occupancy, source,
                        silk_rejected=silk_rejected,
                        drawn_local=drawn_local, drawn_source=drawn_source,
                        court_shape_local=court_shape,
                        drawn_shape_local=drawn_shape,
                        far_court_local=far_court,
                        court_shape_how=court_how,
                        far_court_shape_local=far_shape,
                        far_court_shape_how=far_how,
                        pads_local=pads, fab_rejected=fab_rejected,
                        edge_marker=edge_marker)


def board_bodies(pcb_data, pcb_file: Optional[str] = None
                 ) -> Dict[str, BodyGeometry]:
    """`{ref: BodyGeometry}` for a whole board, one file read.

    Needs the board FILE, because footprint graphics reach neither parse path:
    `kicad_parser.Footprint` carries no courtyard, fab or silk field on the text
    side or the pcbnew side. Falls back to `pcb_data.source_path` -- which
    `build_pcb_data_from_board` fills from `board.GetFileName()`, so the GUI
    reaches the same geometry -- and to pad bboxes everywhere when there is no
    readable path at all.

    A ref is ABSENT only when even the pad fallback raised, matching
    `legality.part_local_bounds` so both see one universe.
    """
    from placement.legality import footprint_side
    from placement.parser import (extract_courtyard_shapes,
                                  extract_courtyard_sides, extract_edge_markers,
                                  extract_fab_shapes, extract_fab_sides,
                                  extract_silk_sides)

    path = pcb_file or getattr(pcb_data, 'source_path', None)
    crt: Dict[str, Dict[str, Bbox]] = {}
    fab: Dict[str, Dict[str, Bbox]] = {}
    silk: Dict[str, Dict[str, Bbox]] = {}
    crt_shapes: Dict[str, Dict[str, tuple]] = {}
    fab_shapes: Dict[str, Dict[str, tuple]] = {}
    markers: Dict[str, object] = {}
    if path:
        try:
            markers = extract_edge_markers(path)
        except Exception:                                    # noqa: BLE001
            markers = {}
        for reader, target in ((extract_courtyard_shapes, crt_shapes),
                               (extract_fab_shapes, fab_shapes)):
            try:
                target.update(reader(path))
            except Exception:                                # noqa: BLE001
                pass
        for reader, target in ((extract_courtyard_sides, 'crt'),
                               (extract_fab_sides, 'fab'),
                               (extract_silk_sides, 'silk')):
            try:
                got = reader(path)
            except Exception:                                # noqa: BLE001
                got = {}
            if target == 'crt':
                crt = got
            elif target == 'fab':
                fab = got
            else:
                silk = got

    out: Dict[str, BodyGeometry] = {}
    for ref, fp in sorted((pcb_data.footprints or {}).items()):
        geom = body_geometry(fp, footprint_side(fp),
                             courtyard_sides=crt.get(ref),
                             fab_sides=fab.get(ref),
                             silk_sides=silk.get(ref), ref=ref,
                             courtyard_shapes=crt_shapes.get(ref),
                             fab_shapes=fab_shapes.get(ref),
                             edge_marker=markers.get(ref))
        if geom.body_local is None and geom.source != SOURCE_NONE:
            continue
        out[ref] = geom
    return out


class BodySeam(NamedTuple):
    """The tightest gap between two parts' DRAWN bodies, signed.

    Negative is an overlap, the same convention as `legality.rect_gap`, so a
    seam and an overlap are one number and a reader never has to reconcile two.
    `source_a` / `source_b` name the geometry the number rests on, because a
    seam measured between two silk markings is a much weaker claim than one
    between two drawn .Fab bodies.
    """
    mm: float
    ref_a: str
    ref_b: str
    source_a: str
    source_b: str


def tightest_body_seam(parts) -> Optional[BodySeam]:
    """The tightest drawn-body seam on a board, or None if fewer than two
    parts draw a body.

    #896 asks for this on every review sheet, because run 25's final layout had
    a 0.183mm seam -- header plastic to an 0402 body -- that no instrument in
    the chain produced: `body_overlap_pairs` reports `depth_mm` only for pairs
    that already OVERLAP, so a board one micron from a collision reported
    nothing at all. "How close is the closest thing on this board" is the
    question a human asks first and the toolchain could not answer.

    `parts` is an iterable of `(ref, sides, side, rect, tht_rect, source)`,
    already in board coordinates -- the caller owns the pose, this owns the
    comparison. It calls `legality.pair_min_gap`, so the shared-side rule is
    the one the graders already use rather than a second copy of it.
    """
    from placement.legality import pair_min_gap
    parts = list(parts)
    best: Optional[BodySeam] = None
    for i, (ra, sa, sda, rca, ta, srca) in enumerate(parts):
        for rb, sb, sdb, rcb, tb, srcb in parts[i + 1:]:
            g = pair_min_gap(sa, sda, rca, ta, sb, sdb, rcb, tb)
            if g is None:
                continue
            if best is None or g < best.mm:
                best = BodySeam(round(g, 4), ra, rb, srca, srcb)
    return best


def source_mix(bodies) -> Dict[str, int]:
    """`{source: count}` over `BodyGeometry` records, in ladder order.

    The number `check_assembly`'s BODY COVERAGE line reports, so the coverage
    claim and the geometry cannot drift apart.
    """
    counts = {s: 0 for s in SOURCES}
    for g in (bodies.values() if isinstance(bodies, dict) else bodies):
        counts[g.source] = counts.get(g.source, 0) + 1
    return counts


def format_source_mix(bodies) -> str:
    """One line naming every rung that answered, zeros included.

    Zeros are kept deliberately: "0 courtyard" on a board is the finding, and a
    mix that only lists what it found cannot say that.
    """
    counts = source_mix(bodies)
    return ', '.join(f'{counts[s]} {s}' for s in SOURCES)
