"""
Routing constants used throughout the codebase.

Centralizes magic numbers and default values for consistency.
"""

# Default layer stack for 4-layer boards
DEFAULT_4_LAYER_STACK = ['F.Cu', 'In1.Cu', 'In2.Cu', 'B.Cu']

# Same-net coincidence tolerance (issue #319/#320): two track endpoints closer
# than this count as a COINCIDENT (clean) joint; a larger gap that is still within
# cap overlap is a fragile SOFT JOINT, not a real connection. This is the same
# threshold check_drc's soft-joint check uses. Kept in this leaf module so any
# consumer (check_drc, the copper-removal guard, ...) can import it without a
# cycle, and the definition never drifts.
SOFT_JOINT_MIN_GAP = 0.010

# --layer-costs sentinel: the layer is included in --layers (full obstacle
# awareness; foreign copper on it blocks via barrels, and through-vias may span
# it) but the router places NO track copper on it. Emitted verbatim into the
# i32 layer_costs vector; the Rust router treats any negative layer cost as
# "forbidden" (canonical value -1). NOT scaled by 1000.
FORBIDDEN_LAYER_COST = -1

# Power net detection patterns (used for auto-exclusion from component routing)
POWER_NET_EXCLUSION_PATTERNS = [
    '*GND*', '*VCC*', '*VDD*', '+*V', '-*V', 'unconnected-*', ''
]

# Via placement multipliers
VIA_EXCLUSION_MARGIN_MULTIPLIER = 1.5  # Multiplied by via_size for pad exclusion zones
VIA_CLOSE_RADIUS_MULTIPLIER = 2.5     # Default multiplier for close via search radius
VIA_SKIP_RADIUS_MULTIPLIER = 2.0      # Multiplier for skipping existing vias

# Spatial indexing
DEFAULT_SPATIAL_INDEX_CELL_SIZE = 2.0  # mm - for DRC checking
ORPHAN_STUB_CELL_SIZE = 0.5           # mm - for orphan stub detection

# Tolerances (mm)
ORPHAN_STUB_VIA_TOLERANCE = 0.15      # Distance to consider endpoint near a via
ORPHAN_STUB_PAD_TOLERANCE = 0.5       # Distance to consider endpoint near a pad

# Plane region routing
MIN_OPEN_SPACE_CLEARANCE_CELLS = 2    # Minimum clearance in grid cells for open space routing
PROXIMITY_COST_MULTIPLIER = 1000      # Multiplier for proximity cost calculation

# Resistance analysis (plane_resistance.py)
RAY_CAST_LENGTH = 1000.0              # mm - ray length for polygon width sampling

# Max-current chart fit: I = k * dT^0.44 * A^0.725, A in mils^2.
#
# This is the IPC-2221 fit, NOT IPC-2152 (#489 §6) -- these constants carried
# 2152 names for a long time, and their two exponent comments were swapped on
# top of that (0.44 was labeled the area exponent; it is the TEMPERATURE-RISE
# exponent). IPC-2152 specifically overturned 2221's 2x internal derating:
# internal traces in FR4 run COOLER than external ones in still air, so the
# k_internal below under-credits inner layers by roughly 2x. See
# plane_resistance.calculate_max_current_ipc2221 /
# calculate_max_current_ipc2152.
IPC_2221_EXPONENT_DT = 0.44           # Temperature-rise exponent
IPC_2221_EXPONENT_AREA = 0.725        # Cross-sectional-area exponent
IPC_2221_K_INTERNAL = 0.024           # k-value for internal layers
IPC_2221_K_EXTERNAL = 0.048           # k-value for external layers

# Validity bound of that chart fit. IPC-2221's curves are drawn for
# cross-sections up to ~700 mils^2; the fit is a power law, so applying it to a
# 52mm-wide POUR (~2900 mils^2 at 1 oz) extrapolates far outside the data and
# prints a number that reads like a rating but is not one. Results past this are
# flagged out-of-range rather than silently reported.
IPC_2221_MAX_AREA_MILS2 = 700.0

# BGA/component detection (mm)
BGA_EDGE_DETECTION_TOLERANCE = 0.01   # Tolerance for detecting pad alignment
BGA_DEFAULT_EDGE_TOLERANCE = 1.6      # Default edge tolerance for BGA pitch detection
