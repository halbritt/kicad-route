"""
Reroute loop for ripped-up nets.

This module contains the unified reroute loop that handles all nets ripped
during diff pair or single-ended routing, extracted from route.py.
"""
from __future__ import annotations

import time
from typing import List, Tuple

from routing_state import (RoutingState, record_net_event, record_rip_ancestry,
                           record_pair_rip_ancestry, rip_exclude_set,
                           diff_pair_rip_exclude)
from obstacle_costs import compute_track_proximity_for_net
from connectivity import get_net_endpoints, calculate_stub_length, get_multipoint_net_pads
from net_queries import calculate_route_length
from pcb_modification import add_route_to_pcb_data
from single_ended_routing import (route_net_with_obstacles,
                                  route_multipoint_main, route_multipoint_taps,
                                  route_oracle_links)
from diff_pair_routing import (route_diff_pair_with_obstacles, get_diff_pair_endpoints,
                               _route_direct_coupled_middle)
from blocking_analysis import analyze_frontier_blocking, print_blocking_analysis, filter_rippable_blockers, invalidate_obstacle_cache, record_frontier_blocking
from protected_nets import rip_refusal
from rip_up_reroute import rip_up_net, restore_net
from leg_rip import LEG_RIP_ENABLED, select_blocking_branch  # #510
from rip_defer import queue_reroute, release_deferred  # #510 churn
from polarity_swap import apply_polarity_swap, get_canonical_net_id, rip_combo_already_tried
from layer_swap_fallback import try_fallback_layer_swap, add_own_stubs_as_obstacles_for_diff_pair
from routing_context import (
    build_single_ended_obstacles, build_diff_pair_obstacles,
    build_diff_pair_leg_obstacles,
    record_single_ended_success, record_diff_pair_success,
    prepare_obstacles_inplace, restore_obstacles_inplace
)
from obstacle_cache import update_net_obstacles_after_routing, refresh_net_obstacles
from diff_pair_custody import (classify_diff_pair_failure, record_casualty,
                               record_pair_diag, blocker_names)
from terminal_colors import RED, GREEN, RESET


def run_reroute_loop(
    state: RoutingState,
    route_index_start: int = 0,
    cancel_check=None,
    progress_callback=None,
    failed_so_far: int = 0,
) -> Tuple[int, int, float, int, int]:
    """
    Run the unified reroute loop for all nets ripped during routing.

    Args:
        state: The routing state object containing all shared state
        route_index_start: Starting route index (continues from previous routing phases)
        cancel_check: Optional callable returning True if routing should be cancelled
        progress_callback: Optional callable(current, total, net_name) for progress updates
        failed_so_far: Number of failed routes from previous routing phases

    Returns:
        Tuple of (successful, failed, total_time, total_iterations, route_index)
    """
    # Extract frequently-used state fields as local references
    pcb_data = state.pcb_data
    config = state.config
    routed_net_ids = state.routed_net_ids
    routed_net_paths = state.routed_net_paths
    routed_results = state.routed_results
    diff_pair_by_net_id = state.diff_pair_by_net_id
    track_proximity_cache = state.track_proximity_cache
    layer_map = state.layer_map
    reroute_queue = state.reroute_queue
    rip_and_retry_history = state.rip_and_retry_history
    rerouted_pairs = state.rerouted_pairs
    polarity_swapped_pairs = state.polarity_swapped_pairs
    remaining_net_ids = state.remaining_net_ids
    results = state.results
    pad_swaps = state.pad_swaps
    base_obstacles = state.base_obstacles
    diff_pair_base_obstacles = state.diff_pair_base_obstacles
    diff_pair_extra_clearance = state.diff_pair_extra_clearance
    gnd_net_id = state.gnd_net_id
    all_unrouted_net_ids = state.all_unrouted_net_ids
    total_routes = state.total_routes
    enable_layer_switch = state.enable_layer_switch
    target_swaps = state.target_swaps
    all_swap_vias = state.all_swap_vias
    all_segment_modifications = state.all_segment_modifications

    # Counters (kept as locals)
    successful = 0
    failed = 0
    total_time = 0.0
    total_iterations = 0
    route_index = route_index_start
    reroute_index = 0

    # Cache for obstacle cells - persists across retry iterations for performance
    obstacle_cache = {}

    # Get the queued_net_ids tracking set from state
    queued_net_ids = state.queued_net_ids

    # Unified reroute loop - handles all nets ripped during diff pair or single-ended routing
    #
    # #510 churn: when the queue drains, release the nets that were held back for
    # repeated ripping and keep going. They are re-routed LAST, into a board whose
    # other nets have stopped moving -- which is the whole point of deferring them
    # (measured: +3V3 was rebuilt 54 times, median 4 events before the next rip).
    # release_deferred is idempotent, so the released nets cannot be deferred a
    # second time and stranded.
    #
    # Victim-priority restore (#622), ENDGAME ONLY. A rip exchange must not
    # end with the victim shipped broken while the ripper keeps the stolen
    # channel (measured: SDQ6/SA9 + yw1's SA1/SA2/SA6 all shipped
    # stub/partial exactly this way -- a net-zero exchange plus debris).
    # This sweep runs ONCE, when the reroute queue has fully drained
    # (deferred releases included): for every 'stub'-restored victim whose
    # FULL restore is blocked only by copper this run routed since the rip
    # (rippable, unprotected, single-ended squatters), rip the squatters and
    # requeue them, strip the victim's stub copper, and land the full
    # restore. The restored victim joins restore_protected_net_ids
    # (rip_exclude_set folds it in), so the requeued squatter must route
    # around it or fail honestly -- no ping-pong. Firing MID-loop instead
    # was measured harmful (yz2: the control's natural later queue rounds
    # used to recover such victims by themselves; pre-empting them traded a
    # clean board for 1 failed); after the drain, a stub really is about to
    # ship broken, so the rescue can only help.
    # KICAD_VICTIM_RESTORE=0 reverts.
    _vr_swept622 = [False]

    def _victim_priority_sweep622() -> bool:
        nonlocal successful
        import env_knobs as _ek622
        from rip_restore import try_terminal_restore, conflict_owner_ids
        from obstacle_cache import (add_net_obstacles_from_cache,
                                    precompute_net_obstacles,
                                    remove_net_obstacles_from_cache)
        # RECONCILE SUB-RUNS ONLY (config.final_reconcile stamped False
        # there): in the outermost run, later tiers (queue rounds, the
        # nested reconciliation) recover most stub victims on their own,
        # and firing earlier was measured to regress a clean control both
        # times it was tried (yz2 mid-loop, za2 at the drain). Inside the
        # reconcile sub-run there is no deeper tier -- a stub at ITS drain
        # ships broken (yw1's SA1/SA2/SA6, the motivating class).
        if (_vr_swept622[0] or not _ek622.VICTIM_RESTORE
                or getattr(config, 'final_reconcile', True)):
            return False
        _vr_swept622[0] = True
        _reg = getattr(pcb_data, '_rip_saved', None) or {}
        _queued_any = False
        for _vid in sorted(state.terminal_restores):
            if state.terminal_restores.get(_vid) != 'stub':
                continue
            if _vid in state.victim_authority_used or _vid in routed_results:
                continue
            _pay = _reg.get(_vid)
            if _pay is None:
                continue
            _sv0, _rids0, _wir0 = _pay
            _segs0 = _sv0.get('new_segments') or []
            _vias0 = _sv0.get('new_vias') or []
            _own0 = set(_rids0) | {_vid}
            _owners0 = conflict_owner_ids(pcb_data, config, _own0,
                                          _segs0, _vias0)
            # NOT rip_exclude_set: the squatter is almost always the
            # victim's own RIPPER, i.e. its rip ancestry -- the exact net
            # the ancestry guard forbids ripping back (the mid-loop build
            # fired on 0 arms for that reason). Protection replaces the
            # ancestry guard here.
            _prot0 = set(state.restore_protected_net_ids) | {_vid}
            if not _owners0 or len(_owners0) > 3 or not all(
                    _o in routed_results and _o not in _prot0
                    and _o not in diff_pair_by_net_id
                    and not rip_refusal(pcb_data, _o, "victim-priority restore")
                    for _o in _owners0):
                continue
            state.victim_authority_used.add(_vid)
            _vname = (pcb_data.nets[_vid].name
                      if _vid in pcb_data.nets else str(_vid))
            _onames0 = [pcb_data.nets[_o].name
                        if _o in pcb_data.nets else str(_o)
                        for _o in sorted(_owners0)]
            print(f"  VICTIM-PRIORITY RESTORE (#622, endgame): {_vname} "
                  f"would ship broken; its channel is held by "
                  f"{', '.join(_onames0)} -- ripping the squatter(s) and "
                  f"requeueing them so the victim restores whole")
            for _o in sorted(_owners0):
                _osv, _orids, _owir = rip_up_net(
                    _o, pcb_data, routed_net_ids, routed_net_paths,
                    routed_results, diff_pair_by_net_id, remaining_net_ids,
                    results, config, track_proximity_cache,
                    state.working_obstacles, state.net_obstacles_cache,
                    state.ripped_route_layer_costs,
                    state.ripped_route_via_positions, layer_map)
                if _osv is None:
                    continue
                if _owir:
                    successful -= 1
                for _orid in _orids:
                    invalidate_obstacle_cache(obstacle_cache, _orid)
                    record_rip_ancestry(state, _vid, _orid)
                    record_net_event(state, _orid, "ripped_by", {
                        "ripping_net_id": _vid,
                        "ripping_net_name": _vname,
                        "reason": "victim-priority restore (#622 endgame)"})
                    _on0 = (pcb_data.nets[_orid].name
                            if _orid in pcb_data.nets else str(_orid))
                    # Unconditional: a squatter queued (and processed) in an
                    # earlier round must still get a reroute for THIS rip --
                    # the body skips nets already back in routed_results, so
                    # a duplicate entry is harmless, but a skipped one ships
                    # the squatter stripped.
                    reroute_queue.append(('single', _on0, _orid))
                    queued_net_ids.add(_orid)
                    _queued_any = True
            # Strip the stub copper the earlier stub-restore inserted (same
            # OBJECTS as the payload's) -- restore_net re-adds the payload
            # wholesale, and a duplicate is never harmless (dup_trap lore).
            # Cache discipline mirrors the stub insert: remove entry ->
            # mutate pcb_data -> recompute -> add entry.
            _ids0 = {id(_x) for _x in _segs0}
            _vds0 = {id(_x) for _x in _vias0}
            _had_cache = (state.working_obstacles is not None
                          and state.net_obstacles_cache is not None
                          and _vid in state.net_obstacles_cache)
            if _had_cache:
                remove_net_obstacles_from_cache(
                    state.working_obstacles,
                    state.net_obstacles_cache[_vid])
            pcb_data.segments[:] = [_s for _s in pcb_data.segments
                                    if id(_s) not in _ids0]
            pcb_data.vias[:] = [_v for _v in pcb_data.vias
                                if id(_v) not in _vds0]
            if _had_cache:
                state.net_obstacles_cache[_vid] = precompute_net_obstacles(
                    pcb_data, _vid, config)
                add_net_obstacles_from_cache(
                    state.working_obstacles,
                    state.net_obstacles_cache[_vid])
            _tr2 = try_terminal_restore(
                pcb_data, config, _vid,
                working_obstacles=state.working_obstacles,
                net_obstacles_cache=state.net_obstacles_cache)
            if _tr2 in ('full', 'full_open'):
                restore_net(_vid, _sv0, _rids0, _wir0,
                            pcb_data, routed_net_ids, routed_net_paths,
                            routed_results, diff_pair_by_net_id,
                            remaining_net_ids, results, config,
                            track_proximity_cache, layer_map,
                            state.working_obstacles,
                            state.net_obstacles_cache,
                            state.ripped_route_layer_costs,
                            state.ripped_route_via_positions,
                            refused_sink=state.collision_refused_net_ids)
                state.terminal_restores[_vid] = _tr2
                state.restore_protected_net_ids.add(_vid)
                if _tr2 == 'full':
                    if _wir0:
                        successful += 1
                    print(f"  VICTIM-PRIORITY RESTORE (#622): {_vname} "
                          f"restored WHOLE and protected for the rest of "
                          f"the run")
                else:
                    print(f"  VICTIM-PRIORITY RESTORE (#622): {_vname} "
                          f"restored its copper but remains OPEN (payload "
                          f"was partial) -- counted failed")
            else:
                # Still blocked (e.g. a squatter's own pre-existing stubs)
                # -- try_terminal_restore's stub path just re-inserted the
                # landing stubs, so the board is back where it started.
                print(f"  VICTIM-PRIORITY RESTORE (#622): {_vname} still "
                      f"blocked after the squatter rip (verdict {_tr2!r}) "
                      f"-- stub state kept")
        return _queued_any

    while (reroute_index < len(reroute_queue) or release_deferred(state)
           or _victim_priority_sweep622()):
        # Check for cancellation at start of each reroute iteration
        if cancel_check and cancel_check():
            print("\nReroute cancelled by user")
            break

        reroute_item = reroute_queue[reroute_index]
        reroute_index += 1
        state.reroute_index = reroute_index   # #510 churn: push-back origin

        if reroute_item[0] == 'single':
            _, ripped_net_name, ripped_net_id = reroute_item

            # Skip if already routed
            if ripped_net_id in routed_results:
                continue

            route_index += 1
            current_total = total_routes + len(reroute_queue)
            total_failed = failed_so_far + failed
            failed_str = f" ({total_failed} failed)" if total_failed > 0 else ""
            print(f"\n[REROUTE {route_index}/{current_total}{failed_str}] Re-routing ripped net {ripped_net_name}")

            # Update progress for reroute
            if progress_callback:
                msg = f"Reroute: {ripped_net_name}"
                if total_failed > 0:
                    msg += f" ({total_failed} failed)"
                progress_callback(route_index, current_total, msg)

            # Calculate stub length before routing
            stub_length = calculate_stub_length(pcb_data, ripped_net_id)

            start_time = time.time()
            # Use in-place approach if working obstacles available (saves memory)
            reroute_via_cells = None
            if state.working_obstacles is not None and state.net_obstacles_cache:
                unrouted_stubs, reroute_via_cells = prepare_obstacles_inplace(
                    state.working_obstacles, pcb_data, config, ripped_net_id,
                    all_unrouted_net_ids, routed_net_ids, track_proximity_cache, layer_map,
                    state.net_obstacles_cache,
                    state.ripped_route_layer_costs, state.ripped_route_via_positions
                )
                obstacles = state.working_obstacles
            else:
                obstacles, unrouted_stubs = build_single_ended_obstacles(
                    base_obstacles, pcb_data, config, routed_net_ids, remaining_net_ids,
                    all_unrouted_net_ids, ripped_net_id, gnd_net_id, track_proximity_cache, layer_map,
                    ripped_route_layer_costs=state.ripped_route_layer_costs,
                    ripped_route_via_positions=state.ripped_route_via_positions
                )

            # A ripped bus member reroutes WITH its corridor (or a routed
            # neighbor); previously it rerouted blind, so every rip degraded
            # the river. Hoisted above the multipoint split so multipoint
            # members get corridor-spanning main-edge selection + attraction.
            from bus_detection import bus_attraction_context
            _attr, _rev = bus_attraction_context(
                ripped_net_id, getattr(state, 'bus_net_to_group', None),
                getattr(state, 'bus_corridors', None), routed_net_paths)
            # #572: a ripped forced-link net re-routes its EXACT oracle links
            # -- derived endpoints are model-blind to the exact-fill gap, so
            # a plain reroute here would reconnect arbitrary fragments and
            # silently drop the strap the net exists in this run to lay.
            _olinks_rr = (getattr(state, 'oracle_links_by_net', None)
                          or {}).get(ripped_net_id)
            # Check for multi-point net (3+ pads, no existing segments since they were ripped)
            multipoint_pads = get_multipoint_net_pads(pcb_data, ripped_net_id, config)
            if _olinks_rr:
                print(f"  Re-routing {len(_olinks_rr)} exact-fill oracle "
                      f"link(s) (#572 forced edges)")
                result = route_oracle_links(pcb_data, ripped_net_id, config,
                                            obstacles, _olinks_rr,
                                            attraction_path=_attr)
            elif multipoint_pads:
                print(f"  Multi-point net with {len(multipoint_pads)} pads - routing main + taps")
                result = route_multipoint_main(pcb_data, ripped_net_id, config, obstacles, multipoint_pads,
                                               attraction_path=_attr, state=state)
                # If Phase 1 succeeded, immediately do Phase 3 (tap routing)
                if result and not result.get('failed') and result.get('is_multipoint'):
                    main_segments_count = len(result['new_segments'])
                    main_vias_count = len(result.get('new_vias', []))
                    tap_result = route_multipoint_taps(pcb_data, ripped_net_id, config, obstacles, result)
                    if tap_result:
                        result = tap_result  # Use combined result
                        tap_segments = len(result['new_segments']) - main_segments_count
                        tap_vias = len(result.get('new_vias', [])) - main_vias_count
                        print(f"    Tap routing: {tap_segments} segments, {tap_vias} vias")
                        # Print red final failure message if there are unconnected pads
                        final_failed_pads = tap_result.get('failed_pads_info', [])
                        if final_failed_pads:
                            net_name = pcb_data.nets[ripped_net_id].name if ripped_net_id in pcb_data.nets else f"Net {ripped_net_id}"
                            for pad in final_failed_pads:
                                print(f"    {RED}NOT CONNECTED (so far): {net_name} - {pad['component_ref']} pad {pad['pad_number']} at ({pad['x']:.2f}, {pad['y']:.2f}) - may still be recovered; final verdict in the end-of-run summary{RESET}")

                        # Remove from pending_multipoint_nets since Phase 3 is now complete
                        if ripped_net_id in state.pending_multipoint_nets:
                            del state.pending_multipoint_nets[ripped_net_id]
            else:
                result = route_net_with_obstacles(pcb_data, ripped_net_id, config, obstacles,
                                                  attraction_path=_attr,
                                                  reverse_direction=_rev)
            elapsed = time.time() - start_time
            total_time += elapsed

            if result and not result.get('failed'):
                routed_length = calculate_route_length(result['new_segments'], result.get('new_vias', []), pcb_data)
                route_length = routed_length + stub_length
                result['route_length'] = route_length
                result['stub_length'] = stub_length
                print(f"  REROUTE SUCCESS: {len(result['new_segments'])} segments, {len(result.get('new_vias', []))} vias, length={route_length:.2f}mm (stubs={stub_length:.2f}mm) ({elapsed:.2f}s)")
                results.append(result)
                successful += 1
                total_iterations += result['iterations']
                record_single_ended_success(
                    pcb_data, result, ripped_net_id, config,
                    remaining_net_ids, routed_net_ids, routed_net_paths,
                    routed_results, track_proximity_cache, layer_map
                )
                record_net_event(state, ripped_net_id, "reroute_succeeded", {
                    "context": "reroute_loop",
                    "segments": len(result['new_segments']),
                    "vias": len(result.get('new_vias', []))
                })
                # Allow re-queuing if this net gets ripped again later
                queued_net_ids.discard(ripped_net_id)
                # Update net obstacles cache with new route, then restore working obstacles
                if reroute_via_cells is not None and state.working_obstacles is not None:
                    update_net_obstacles_after_routing(pcb_data, ripped_net_id, result, config, state.net_obstacles_cache)
                    restore_obstacles_inplace(state.working_obstacles, ripped_net_id,
                                             state.net_obstacles_cache, reroute_via_cells)
                    reroute_via_cells = None
            else:
                # Reroute failed - try rip-up and retry
                iterations = result['iterations'] if result else 0
                total_iterations += iterations
                print(f"  REROUTE FAILED: ({elapsed:.2f}s) - attempting rip-up and retry...")

                # Restore working obstacles before rip-up/retry (in-place approach)
                if reroute_via_cells is not None and state.working_obstacles is not None:
                    restore_obstacles_inplace(state.working_obstacles, ripped_net_id,
                                             state.net_obstacles_cache, reroute_via_cells)
                    reroute_via_cells = None

                reroute_succeeded = False
                ripped_items = []
                if routed_net_paths and result:
                    fwd_cells = result.pop('blocked_cells_forward', [])
                    bwd_cells = result.pop('blocked_cells_backward', [])
                    # Fastest-failing direction only (audit #3b): pooling let
                    # the broad flood's thousands of cells swamp the drained
                    # pocket's dozens before attribution ran. Mirrors the SE
                    # loop; falls back to the union when iterations are absent.
                    fwd_it = result.get('iterations_forward', 0)
                    bwd_it = result.get('iterations_backward', 0)
                    if fwd_cells and bwd_cells and (fwd_it > 0 or bwd_it > 0):
                        blocked_cells = list(set(
                            fwd_cells if (fwd_it > 0 and (bwd_it == 0 or fwd_it <= bwd_it))
                            else bwd_cells))
                    else:
                        blocked_cells = list(set(fwd_cells + bwd_cells))
                    del fwd_cells, bwd_cells  # Free memory immediately

                    if blocked_cells:
                        # Get source/target coordinates for blocking analysis
                        reroute_sources, reroute_targets, _ = get_net_endpoints(pcb_data, ripped_net_id, config)
                        reroute_source_xy = None
                        reroute_target_xy = None
                        if reroute_sources:
                            reroute_source_xy = (reroute_sources[0][3], reroute_sources[0][4])
                        if reroute_targets:
                            reroute_target_xy = (reroute_targets[0][3], reroute_targets[0][4])

                        blockers = analyze_frontier_blocking(
                            blocked_cells, pcb_data, config, routed_net_paths,
                            exclude_net_ids=rip_exclude_set(state, ripped_net_id),
                            target_xy=reroute_target_xy,
                            source_xy=reroute_source_xy,
                            obstacle_cache=obstacle_cache
                        )
                        record_frontier_blocking(state, ripped_net_id,
                                                 blockers, "reroute")
                        print_blocking_analysis(blockers)

                        # Filter to only rippable blockers
                        rippable_blockers, seen_canonical_ids = filter_rippable_blockers(
                            blockers, routed_results, diff_pair_by_net_id, get_canonical_net_id,
                            pcb_data=pcb_data, context="reroute rip ladder"
                        )
                        ripped_canonical_ids = set()
                        last_retry_blocked_cells = blocked_cells

                        for N in range(1, config.max_rip_up_count + 1):
                            if N > 1 and last_retry_blocked_cells:
                                print(f"  Re-analyzing {len(last_retry_blocked_cells)} blocked cells from N={N-1} retry:")
                                fresh_blockers = analyze_frontier_blocking(
                                    last_retry_blocked_cells, pcb_data, config, routed_net_paths,
                                    exclude_net_ids=rip_exclude_set(state, ripped_net_id),
                                    target_xy=reroute_target_xy,
                                    source_xy=reroute_source_xy,
                                    obstacle_cache=obstacle_cache
                                )
                                record_frontier_blocking(state, ripped_net_id,
                                                         fresh_blockers,
                                                         "reroute")
                                print_blocking_analysis(fresh_blockers, prefix="    ")
                                next_blocker = None
                                for b in fresh_blockers:
                                    if b.net_id in routed_results and not rip_refusal(
                                            pcb_data, b.net_id, "reroute rip ladder", diff_pair_by_net_id):
                                        canonical = get_canonical_net_id(b.net_id, diff_pair_by_net_id)
                                        if canonical not in ripped_canonical_ids:
                                            next_blocker = b
                                            break
                                if next_blocker is None:
                                    print(f"  No additional rippable blockers from retry analysis")
                                    break
                                next_canonical = get_canonical_net_id(next_blocker.net_id, diff_pair_by_net_id)
                                if next_canonical not in seen_canonical_ids:
                                    seen_canonical_ids.add(next_canonical)
                                    rippable_blockers.append(next_blocker)
                                for idx, b in enumerate(rippable_blockers):
                                    if get_canonical_net_id(b.net_id, diff_pair_by_net_id) == next_canonical:
                                        if idx != N - 1 and N - 1 < len(rippable_blockers):
                                            rippable_blockers[idx], rippable_blockers[N-1] = rippable_blockers[N-1], rippable_blockers[idx]
                                        break

                            if N > len(rippable_blockers):
                                break

                            # Shared rip-history gate (#376): same log+skip as
                            # single_ended_loop (was a silent bare continue here).
                            already_tried, blocker_canonicals = rip_combo_already_tried(
                                rip_and_retry_history, ripped_net_id, ripped_net_name,
                                rippable_blockers, N, diff_pair_by_net_id)
                            if already_tried:
                                continue

                            # Env-gated experiment, measured neutral/negative
                            # (see #480/#517 study); kept for A/B.
                            # Churn gate v2 -- allow each
                            # net ONE committed rip; refuse rip sets containing
                            # a net already ripped >= K times (measured: 55/82
                            # ripped nets churn repeatedly and #134 refusals ~=
                            # the final failure count). KICAD_SE_RIP_CHURN_GATE=K.
                            import os as _os
                            _ck = int(_os.environ.get('KICAD_SE_RIP_CHURN_GATE', '0') or 0)
                            if _ck > 0:
                                _cc = getattr(state, '_churn_counts', {})
                                _hot = [rippable_blockers[i].net_name for i in range(N)
                                        if _cc.get(rippable_blockers[i].net_id, 0) >= _ck]
                                if _hot:
                                    print(f"  CHURN GATE: refusing rip set N={N} "
                                          f"(churned: {', '.join(_hot)})")
                                    break

                            rip_successful = True
                            new_ripped_this_level = []

                            if N == 1:
                                blocker = rippable_blockers[0]
                                if blocker.net_id in diff_pair_by_net_id:
                                    ripped_pair_name_tmp, _ = diff_pair_by_net_id[blocker.net_id]
                                    print(f"  Ripping up diff pair {ripped_pair_name_tmp} to retry reroute...")
                                else:
                                    print(f"  Ripping up {blocker.net_name} to retry reroute...")
                            else:
                                blocker = rippable_blockers[N-1]
                                if blocker.net_id in diff_pair_by_net_id:
                                    ripped_pair_name_tmp, _ = diff_pair_by_net_id[blocker.net_id]
                                    print(f"  Extending to N={N}: ripping diff pair {ripped_pair_name_tmp}...")
                                else:
                                    print(f"  Extending to N={N}: ripping {blocker.net_name}...")

                            for i in range(len(ripped_items), N):
                                blocker = rippable_blockers[i]
                                if blocker.net_id not in routed_results:
                                    continue
                                # #510: rip only the blocking branch (reroute N-extend blocker).
                                _only = None
                                if LEG_RIP_ENABLED and blocker.net_id not in diff_pair_by_net_id:
                                    _only = select_blocking_branch(
                                        pcb_data, blocker.net_id, blocked_cells, config, verbose=True)
                                saved_result_tmp, ripped_ids, was_in_results = rip_up_net(
                                    blocker.net_id, pcb_data, routed_net_ids, routed_net_paths,
                                    routed_results, diff_pair_by_net_id, remaining_net_ids,
                                    results, config, track_proximity_cache,
                                    state.working_obstacles, state.net_obstacles_cache,
                                    state.ripped_route_layer_costs, state.ripped_route_via_positions,
                                    layer_map, only_segments=_only
                                )
                                if saved_result_tmp is None:
                                    rip_successful = False
                                    break
                                ripped_items.append((blocker.net_id, saved_result_tmp, ripped_ids, was_in_results))
                                new_ripped_this_level.append((blocker.net_id, saved_result_tmp, ripped_ids, was_in_results))
                                ripped_canonical_ids.add(get_canonical_net_id(blocker.net_id, diff_pair_by_net_id))
                                # Invalidate obstacle cache for ripped nets and record rip events
                                for rid in ripped_ids:
                                    invalidate_obstacle_cache(obstacle_cache, rid)
                                    record_rip_ancestry(state, ripped_net_id, rid)
                                    record_net_event(state, rid, "ripped_by", {
                                        "ripping_net_id": ripped_net_id,
                                        "ripping_net_name": ripped_net_name,
                                        "reason": f"reroute_loop rip-up retry N={N}",
                                        "N": N
                                    })
                                if was_in_results:
                                    successful -= 1

                            if not rip_successful:
                                for net_id_tmp, saved_result_tmp, ripped_ids, was_in_results in reversed(new_ripped_this_level):
                                    restore_net(net_id_tmp, saved_result_tmp, ripped_ids, was_in_results,
                                               pcb_data, routed_net_ids, routed_net_paths,
                                               routed_results, diff_pair_by_net_id, remaining_net_ids,
                                               results, config, track_proximity_cache, layer_map,
                                               state.working_obstacles, state.net_obstacles_cache,
                                               state.ripped_route_layer_costs, state.ripped_route_via_positions, refused_sink=state.collision_refused_net_ids)
                                    if was_in_results:
                                        successful += 1
                                    ripped_items.pop()
                                continue

                            # Prepare obstacles in-place for retry (saves memory)
                            retry_via_cells = None
                            if state.working_obstacles is not None and state.net_obstacles_cache:
                                _, retry_via_cells = prepare_obstacles_inplace(
                                    state.working_obstacles, pcb_data, config, ripped_net_id,
                                    all_unrouted_net_ids, routed_net_ids, track_proximity_cache, layer_map,
                                    state.net_obstacles_cache,
                                    state.ripped_route_layer_costs, state.ripped_route_via_positions
                                )
                                retry_obstacles = state.working_obstacles
                            else:
                                retry_obstacles, _ = build_single_ended_obstacles(
                                    base_obstacles, pcb_data, config, routed_net_ids, remaining_net_ids,
                                    all_unrouted_net_ids, ripped_net_id, gnd_net_id, track_proximity_cache, layer_map,
                                    ripped_route_layer_costs=state.ripped_route_layer_costs,
                                    ripped_route_via_positions=state.ripped_route_via_positions
                                )

                            # Bus attraction for the retry (multipoint too)
                            from bus_detection import bus_attraction_context
                            _attr, _rev = bus_attraction_context(
                                ripped_net_id, getattr(state, 'bus_net_to_group', None),
                                getattr(state, 'bus_corridors', None), routed_net_paths)
                            # #572: forced-link nets retry their EXACT links
                            # (see the initial reroute above).
                            _olinks_rt = (getattr(state, 'oracle_links_by_net',
                                                  None) or {}).get(ripped_net_id)
                            # Check for multi-point net in retry as well
                            retry_multipoint_pads = get_multipoint_net_pads(pcb_data, ripped_net_id, config)
                            if _olinks_rt:
                                retry_result = route_oracle_links(
                                    pcb_data, ripped_net_id, config,
                                    retry_obstacles, _olinks_rt,
                                    attraction_path=_attr)
                            elif retry_multipoint_pads:
                                retry_result = route_multipoint_main(pcb_data, ripped_net_id, config, retry_obstacles, retry_multipoint_pads,
                                                                     attraction_path=_attr, state=state)
                                if retry_result and not retry_result.get('failed') and retry_result.get('is_multipoint'):
                                    tap_result = route_multipoint_taps(pcb_data, ripped_net_id, config, retry_obstacles, retry_result)
                                    if tap_result:
                                        retry_result = tap_result
                                        # Print red final failure message if there are unconnected pads
                                        final_failed_pads = tap_result.get('failed_pads_info', [])
                                        if final_failed_pads:
                                            net_name = pcb_data.nets[ripped_net_id].name if ripped_net_id in pcb_data.nets else f"Net {ripped_net_id}"
                                            for pad in final_failed_pads:
                                                print(f"    {RED}NOT CONNECTED (so far): {net_name} - {pad['component_ref']} pad {pad['pad_number']} at ({pad['x']:.2f}, {pad['y']:.2f}) - may still be recovered; final verdict in the end-of-run summary{RESET}")

                                        # Remove from pending_multipoint_nets since Phase 3 is now complete
                                        if ripped_net_id in state.pending_multipoint_nets:
                                            del state.pending_multipoint_nets[ripped_net_id]
                            else:
                                retry_result = route_net_with_obstacles(pcb_data, ripped_net_id, config, retry_obstacles,
                                                                        attraction_path=_attr,
                                                                        reverse_direction=_rev)

                            if retry_result and not retry_result.get('failed'):
                                routed_length = calculate_route_length(retry_result['new_segments'], retry_result.get('new_vias', []), pcb_data)
                                route_length = routed_length + stub_length
                                retry_result['route_length'] = route_length
                                retry_result['stub_length'] = stub_length
                                print(f"  REROUTE RETRY SUCCESS (N={N}): {len(retry_result['new_segments'])} segments, {len(retry_result.get('new_vias', []))} vias, length={route_length:.2f}mm (stubs={stub_length:.2f}mm)")
                                results.append(retry_result)
                                successful += 1
                                total_iterations += retry_result['iterations']
                                add_route_to_pcb_data(pcb_data, retry_result, debug_lines=config.debug_lines)
                                from plane_fragility import fragility_on_copper_change  # #466
                                fragility_on_copper_change(config, pcb_data,
                                                           retry_result.get('new_segments'),
                                                           retry_result.get('new_vias'))
                                if ripped_net_id in remaining_net_ids:
                                    remaining_net_ids.remove(ripped_net_id)
                                routed_net_ids.append(ripped_net_id)
                                routed_results[ripped_net_id] = retry_result
                                record_net_event(state, ripped_net_id, "reroute_succeeded", {
                                    "context": "reroute_loop",
                                    "N": N,
                                    "segments": len(retry_result['new_segments']),
                                    "vias": len(retry_result.get('new_vias', []))
                                })
                                if retry_result.get('path'):
                                    routed_net_paths[ripped_net_id] = retry_result['path']
                                track_proximity_cache[ripped_net_id] = compute_track_proximity_for_net(pcb_data, ripped_net_id, config, layer_map)
                                # Allow re-queuing if this net gets ripped again later
                                queued_net_ids.discard(ripped_net_id)

                                # Update net obstacles cache with new route, then restore working obstacles
                                if retry_via_cells is not None and state.working_obstacles is not None:
                                    update_net_obstacles_after_routing(pcb_data, ripped_net_id, retry_result, config, state.net_obstacles_cache)
                                    restore_obstacles_inplace(state.working_obstacles, ripped_net_id,
                                                             state.net_obstacles_cache, retry_via_cells)
                                    retry_via_cells = None
                                # Invalidate blocking analysis cache since we added segments
                                invalidate_obstacle_cache(obstacle_cache, ripped_net_id)

                                # Queue ripped nets and add to history
                                rip_and_retry_history.add((ripped_net_id, blocker_canonicals))
                                if not hasattr(state, '_churn_counts'):
                                    state._churn_counts = {}
                                for net_id_tmp, saved_result_tmp, ripped_ids, was_in_results in ripped_items:
                                    state._churn_counts[net_id_tmp] = state._churn_counts.get(net_id_tmp, 0) + 1
                                    # Committed rip: custody of the pre-rip copper
                                    # for the casualties-only final reconcile.
                                    record_casualty(state, net_id_tmp, saved_result_tmp,
                                                    ripped_ids, was_in_results)
                                    if was_in_results:
                                        successful -= 1
                                    if net_id_tmp in diff_pair_by_net_id:
                                        ripped_pair_name_tmp, ripped_pair_tmp = diff_pair_by_net_id[net_id_tmp]
                                        canonical_id = ripped_pair_tmp.p_net_id
                                        if canonical_id not in queued_net_ids:
                                            reroute_queue.append(('diff_pair', ripped_pair_name_tmp, ripped_pair_tmp))
                                            queued_net_ids.add(canonical_id)
                                    else:
                                        if net_id_tmp not in queued_net_ids:
                                            net = pcb_data.nets.get(net_id_tmp)
                                            net_name_tmp = net.name if net else f"Net {net_id_tmp}"
                                            queue_reroute(state, ('single', net_name_tmp, net_id_tmp), net_id_tmp)
                                            queued_net_ids.add(net_id_tmp)

                                reroute_succeeded = True
                                break
                            else:
                                print(f"  REROUTE RETRY FAILED (N={N})")

                                # Restore working obstacles after retry failure (in-place)
                                if retry_via_cells is not None and state.working_obstacles is not None:
                                    restore_obstacles_inplace(state.working_obstacles, ripped_net_id,
                                                             state.net_obstacles_cache, retry_via_cells)
                                    retry_via_cells = None

                                if retry_result:
                                    retry_fwd = retry_result.pop('blocked_cells_forward', [])
                                    retry_bwd = retry_result.pop('blocked_cells_backward', [])
                                    last_retry_blocked_cells = list(set(retry_fwd + retry_bwd))
                                    del retry_fwd, retry_bwd  # Free memory immediately
                                    if last_retry_blocked_cells:
                                        print(f"    Retry had {len(last_retry_blocked_cells)} blocked cells")
                                    else:
                                        print(f"    No blocked cells from retry to analyze")

                        # If all N levels failed, restore all ripped nets
                        if not reroute_succeeded and ripped_items:
                            print(f"  {RED}All rip-up attempts failed: Restoring {len(ripped_items)} net(s){RESET}")
                            for net_id_tmp, saved_result_tmp, ripped_ids, was_in_results in reversed(ripped_items):
                                restore_net(net_id_tmp, saved_result_tmp, ripped_ids, was_in_results,
                                           pcb_data, routed_net_ids, routed_net_paths,
                                           routed_results, diff_pair_by_net_id, remaining_net_ids,
                                           results, config, track_proximity_cache, layer_map,
                                           state.working_obstacles, state.net_obstacles_cache,
                                           state.ripped_route_layer_costs, state.ripped_route_via_positions, refused_sink=state.collision_refused_net_ids)
                                if was_in_results:
                                    successful += 1

                if not reroute_succeeded:
                    if not ripped_items:
                        print(f"  {RED}ROUTE FAILED - no rippable blockers found{RESET}")
                        from routing_diagnostics import static_boxin_hint, condense_hint
                        hint, _boxin = static_boxin_hint(
                            result, config, pcb_data, return_verdict=True)
                        hint = condense_hint(hint)
                        if hint:
                            print(f"  {hint}")
                        if _boxin:
                            record_net_event(state, ripped_net_id,
                                             "boxed_in_static", _boxin)
                        try:   # #652
                            from routing_diagnostics import (
                                fanout_dropped_ball_hint)
                            _h652, _v652 = fanout_dropped_ball_hint(
                                pcb_data, config, ripped_net_id,
                                ripped_net_name, return_verdict=True)
                            if _h652:
                                _c652 = condense_hint(_h652)
                                if _c652:
                                    print(f"  {_c652}")
                                record_net_event(state, ripped_net_id,
                                                 "fanout_dropped", _v652)
                        except Exception:
                            pass
                    # Remove from pending_multipoint_nets to prevent Phase 3 from
                    # trying to route taps for a net with no main route.
                    if ripped_net_id in state.pending_multipoint_nets:
                        del state.pending_multipoint_nets[ripped_net_id]
                    # #468: a terminally-failed rip victim must not ship with
                    # LESS copper than it started with. Conflict-free saved
                    # copper -> FULL restore (the net returns to its pre-rip
                    # routed state); else at least the escape stub survives.
                    from rip_restore import try_terminal_restore
                    _tr = try_terminal_restore(
                        pcb_data, config, ripped_net_id,
                        working_obstacles=state.working_obstacles,
                        net_obstacles_cache=state.net_obstacles_cache)
                    if _tr in ('full', 'full_open'):
                        _sv, _rids, _wir = pcb_data._rip_saved[ripped_net_id]
                        restore_net(ripped_net_id, _sv, _rids, _wir,
                                    pcb_data, routed_net_ids, routed_net_paths,
                                    routed_results, diff_pair_by_net_id,
                                    remaining_net_ids, results, config,
                                    track_proximity_cache, layer_map,
                                    state.working_obstacles, state.net_obstacles_cache,
                                    state.ripped_route_layer_costs,
                                    state.ripped_route_via_positions,
                                    refused_sink=state.collision_refused_net_ids)
                        state.terminal_restores[ripped_net_id] = _tr
                        if _tr == 'full':
                            print(f"  RIP-RESTORE (#468): {ripped_net_name} restored "
                                  f"to its pre-rip route (reroute failed, corridor "
                                  f"still clear)")
                            if _wir:
                                successful += 1
                        else:
                            # Conflict-free but NOT connected: the saved payload
                            # never covered every pad. Keep the copper, refuse
                            # the success claim (run-7 E2).
                            print(f"  {RED}RIP-RESTORE (#468): {ripped_net_name} "
                                  f"restored its pre-rip copper but the net "
                                  f"remains OPEN -- counted failed{RESET}")
                            failed += 1
                    else:
                        if _tr == 'stub':
                            state.terminal_restores[ripped_net_id] = 'stub'
                        failed += 1

        elif reroute_item[0] == 'diff_pair':
            # Handle diff pairs that were ripped during single-ended routing
            _, ripped_pair_name, ripped_pair = reroute_item

            # Skip if already routed
            if ripped_pair.p_net_id in routed_results and ripped_pair.n_net_id in routed_results:
                continue

            route_index += 1
            current_total = total_routes + len(reroute_queue)
            total_failed = failed_so_far + failed
            failed_str = f" ({total_failed} failed)" if total_failed > 0 else ""
            print(f"\n[REROUTE {route_index}/{current_total}{failed_str}] Re-routing ripped diff pair {ripped_pair_name}")

            # Update progress for diff pair reroute
            if progress_callback:
                msg = f"Reroute: {ripped_pair_name}"
                if total_failed > 0:
                    msg += f" ({total_failed} failed)"
                progress_callback(route_index, current_total, msg)

            start_time = time.time()
            obstacles, unrouted_stubs = build_diff_pair_obstacles(
                diff_pair_base_obstacles, pcb_data, config, routed_net_ids, remaining_net_ids,
                all_unrouted_net_ids, ripped_pair.p_net_id, ripped_pair.n_net_id, gnd_net_id,
                track_proximity_cache, layer_map, diff_pair_extra_clearance,
                add_own_stubs_func=add_own_stubs_as_obstacles_for_diff_pair,
                ripped_route_layer_costs=state.ripped_route_layer_costs,
                ripped_route_via_positions=state.ripped_route_via_positions
            )

            # Get source/target coordinates for blocking analysis
            reroute_sources, reroute_targets, _ = get_diff_pair_endpoints(pcb_data, ripped_pair.p_net_id, ripped_pair.n_net_id, config)
            reroute_source_xy = None
            reroute_target_xy = None
            if reroute_sources:
                src = reroute_sources[0]
                reroute_source_xy = ((src[5] + src[7]) / 2, (src[6] + src[8]) / 2)
            if reroute_targets:
                tgt = reroute_targets[0]
                reroute_target_xy = ((tgt[5] + tgt[7]) / 2, (tgt[6] + tgt[8]) / 2)

            result = route_diff_pair_with_obstacles(pcb_data, ripped_pair, config, obstacles, base_obstacles, unrouted_stubs)
            elapsed = time.time() - start_time
            total_time += elapsed

            if result and not result.get('failed') and not result.get('probe_blocked'):
                print(f"  REROUTE SUCCESS: {len(result['new_segments'])} segments, {len(result['new_vias'])} vias ({elapsed:.2f}s)")
                results.append(result)
                successful += 1
                total_iterations += result['iterations']
                rerouted_pairs.add(ripped_pair_name)
                if result.get('polarity_swap_denied'):
                    state.polarity_swap_denied_pairs.add(ripped_pair_name)
                apply_polarity_swap(pcb_data, result, pad_swaps, ripped_pair_name, polarity_swapped_pairs)
                record_diff_pair_success(
                    pcb_data, result, ripped_pair, ripped_pair_name, config,
                    remaining_net_ids, routed_net_ids, routed_net_paths, routed_results,
                    diff_pair_by_net_id, track_proximity_cache, layer_map,
                    working_obstacles=state.working_obstacles,            # #806
                    net_obstacles_cache=state.net_obstacles_cache,
                )
                # Allow re-queuing if this pair gets ripped again later
                queued_net_ids.discard(ripped_pair.p_net_id)
                queued_net_ids.discard(ripped_pair.n_net_id)
            else:
                # Reroute failed - try rip-up and retry
                iterations = result['iterations'] if result else 0
                total_iterations += iterations
                print(f"  REROUTE FAILED: ({elapsed:.2f}s) - attempting rip-up and retry...")
                # Classify BEFORE the pops below strip the evidence (per-pair
                # JSON diagnostics; refined to 'congestion' if blockers found).
                rr_fail_reason = classify_diff_pair_failure(result)
                rr_fail_blockers = []

                reroute_succeeded = False
                ripped_items = []
                if routed_net_paths and result:
                    # Find blocked cells from the failed route
                    # Pop to free memory from result dict (cells kept in local vars for fallback)
                    fwd_cells = result.pop('blocked_cells_forward', [])
                    bwd_cells = result.pop('blocked_cells_backward', [])
                    if result.get('probe_blocked'):
                        blocked_cells = result.pop('blocked_cells', [])
                    else:
                        fwd_iters = result.get('iterations_forward', 0)
                        bwd_iters = result.get('iterations_backward', 0)
                        if fwd_iters > 0 and (bwd_iters == 0 or fwd_iters <= bwd_iters):
                            blocked_cells = fwd_cells
                        else:
                            blocked_cells = bwd_cells

                    if not blocked_cells:
                        print(f"  No blocked cells from router - cannot analyze blockers")

                    if blocked_cells:
                        blockers = analyze_frontier_blocking(
                            blocked_cells, pcb_data, config, routed_net_paths,
                            exclude_net_ids=diff_pair_rip_exclude(
                                state, ripped_pair.p_net_id, ripped_pair.n_net_id),
                            extra_clearance=diff_pair_extra_clearance,
                            target_xy=reroute_target_xy,
                            source_xy=reroute_source_xy,
                            obstacle_cache=obstacle_cache
                        )
                        print_blocking_analysis(blockers)

                        # Filter to only rippable blockers and deduplicate by diff pair
                        rippable_blockers, seen_canonical_ids = filter_rippable_blockers(
                            blockers, routed_results, diff_pair_by_net_id, get_canonical_net_id,
                            pcb_data=pcb_data, context="reroute rip ladder"
                        )
                        if rippable_blockers:
                            rr_fail_reason = 'congestion'
                            rr_fail_blockers = blocker_names(rippable_blockers,
                                                             diff_pair_by_net_id)
                        current_canonical = ripped_pair.p_net_id

                        if blockers and not rippable_blockers:
                            unrippable_names = []
                            for b in blockers[:3]:
                                if b.net_id in diff_pair_by_net_id:
                                    unrippable_names.append(diff_pair_by_net_id[b.net_id][0])
                                else:
                                    unrippable_names.append(b.net_name)
                            print(f"  No rippable blockers (not yet routed): {', '.join(unrippable_names)}")
                        ripped_canonical_ids = set()
                        last_retry_blocked_cells = blocked_cells

                        for N in range(1, config.max_rip_up_count + 1):
                            if N > 1 and last_retry_blocked_cells:
                                print(f"  Re-analyzing {len(last_retry_blocked_cells)} blocked cells from N={N-1} retry:")
                                fresh_blockers = analyze_frontier_blocking(
                                    last_retry_blocked_cells, pcb_data, config, routed_net_paths,
                                    exclude_net_ids=diff_pair_rip_exclude(
                                        state, ripped_pair.p_net_id, ripped_pair.n_net_id),
                                    extra_clearance=diff_pair_extra_clearance,
                                    target_xy=reroute_target_xy,
                                    source_xy=reroute_source_xy,
                                    obstacle_cache=obstacle_cache
                                )
                                print_blocking_analysis(fresh_blockers, prefix="    ")
                                next_blocker = None
                                for b in fresh_blockers:
                                    if b.net_id in routed_results and not rip_refusal(
                                            pcb_data, b.net_id, "reroute rip ladder", diff_pair_by_net_id):
                                        canonical = get_canonical_net_id(b.net_id, diff_pair_by_net_id)
                                        if canonical not in ripped_canonical_ids:
                                            next_blocker = b
                                            break
                                if next_blocker is None:
                                    print(f"  No additional rippable blockers from retry analysis")
                                    break
                                next_canonical = get_canonical_net_id(next_blocker.net_id, diff_pair_by_net_id)
                                if next_canonical not in seen_canonical_ids:
                                    seen_canonical_ids.add(next_canonical)
                                    rippable_blockers.append(next_blocker)
                                for idx, b in enumerate(rippable_blockers):
                                    if get_canonical_net_id(b.net_id, diff_pair_by_net_id) == next_canonical:
                                        if idx != N - 1 and N - 1 < len(rippable_blockers):
                                            rippable_blockers[idx], rippable_blockers[N-1] = rippable_blockers[N-1], rippable_blockers[idx]
                                        break

                            if N > len(rippable_blockers):
                                break

                            # Shared rip-history gate (#376): unify the log+skip
                            # with single_ended_loop (this site had a divergent
                            # "Skipping rip-up (already tried)" message -- drift).
                            already_tried, blocker_canonicals = rip_combo_already_tried(
                                rip_and_retry_history, current_canonical, ripped_pair_name,
                                rippable_blockers, N, diff_pair_by_net_id)
                            if already_tried:
                                continue

                            # Env-gated experiment, measured neutral/negative
                            # (see #480/#517 study); kept for A/B.
                            # Churn gate v2 -- allow each
                            # net ONE committed rip; refuse rip sets containing
                            # a net already ripped >= K times (measured: 55/82
                            # ripped nets churn repeatedly and #134 refusals ~=
                            # the final failure count). KICAD_SE_RIP_CHURN_GATE=K.
                            import os as _os
                            _ck = int(_os.environ.get('KICAD_SE_RIP_CHURN_GATE', '0') or 0)
                            if _ck > 0:
                                _cc = getattr(state, '_churn_counts', {})
                                _hot = [rippable_blockers[i].net_name for i in range(N)
                                        if _cc.get(rippable_blockers[i].net_id, 0) >= _ck]
                                if _hot:
                                    print(f"  CHURN GATE: refusing rip set N={N} "
                                          f"(churned: {', '.join(_hot)})")
                                    break

                            # Rip up blockers
                            rip_successful = True
                            new_ripped_this_level = []

                            if N == 1:
                                blocker = rippable_blockers[0]
                                if blocker.net_id in diff_pair_by_net_id:
                                    ripped_pair_name_tmp, _ = diff_pair_by_net_id[blocker.net_id]
                                    print(f"  Ripping up diff pair {ripped_pair_name_tmp} to retry reroute...")
                                else:
                                    print(f"  Ripping up {blocker.net_name} to retry reroute...")
                            else:
                                blocker = rippable_blockers[N-1]
                                if blocker.net_id in diff_pair_by_net_id:
                                    ripped_pair_name_tmp, _ = diff_pair_by_net_id[blocker.net_id]
                                    print(f"  Extending to N={N}: ripping diff pair {ripped_pair_name_tmp}...")
                                else:
                                    print(f"  Extending to N={N}: ripping {blocker.net_name}...")

                            for i in range(len(ripped_items), N):
                                blocker = rippable_blockers[i]
                                if blocker.net_id not in routed_results:
                                    continue
                                # #510: rip only the blocking branch (reroute N-extend blocker).
                                _only = None
                                if LEG_RIP_ENABLED and blocker.net_id not in diff_pair_by_net_id:
                                    _only = select_blocking_branch(
                                        pcb_data, blocker.net_id, blocked_cells, config, verbose=True)
                                saved_result_tmp, ripped_ids, was_in_results = rip_up_net(
                                    blocker.net_id, pcb_data, routed_net_ids, routed_net_paths,
                                    routed_results, diff_pair_by_net_id, remaining_net_ids,
                                    results, config, track_proximity_cache,
                                    state.working_obstacles, state.net_obstacles_cache,
                                    state.ripped_route_layer_costs, state.ripped_route_via_positions,
                                    layer_map, only_segments=_only
                                )
                                if saved_result_tmp is None:
                                    rip_successful = False
                                    break
                                ripped_items.append((blocker.net_id, saved_result_tmp, ripped_ids, was_in_results))
                                new_ripped_this_level.append((blocker.net_id, saved_result_tmp, ripped_ids, was_in_results))
                                ripped_canonical_ids.add(get_canonical_net_id(blocker.net_id, diff_pair_by_net_id))
                                # Invalidate obstacle cache for ripped nets and record rip events
                                for rid in ripped_ids:
                                    invalidate_obstacle_cache(obstacle_cache, rid)
                                    # Cycle guard (issue #219): the rerouting pair
                                    # ripped rid, so rid must not rip either half back.
                                    record_pair_rip_ancestry(state, ripped_pair.p_net_id,
                                                             ripped_pair.n_net_id, rid)
                                    record_net_event(state, rid, "ripped_by", {
                                        "ripping_net_id": ripped_pair.p_net_id,
                                        "ripping_net_name": ripped_pair_name,
                                        "reason": f"reroute_loop diff-pair rip-up retry N={N}",
                                        "N": N
                                    })
                                if was_in_results:
                                    successful -= 1

                            if not rip_successful:
                                for net_id_tmp, saved_result_tmp, ripped_ids, was_in_results in reversed(new_ripped_this_level):
                                    restore_net(net_id_tmp, saved_result_tmp, ripped_ids, was_in_results,
                                               pcb_data, routed_net_ids, routed_net_paths,
                                               routed_results, diff_pair_by_net_id, remaining_net_ids,
                                               results, config, track_proximity_cache, layer_map,
                                               state.working_obstacles, state.net_obstacles_cache,
                                               state.ripped_route_layer_costs, state.ripped_route_via_positions, refused_sink=state.collision_refused_net_ids)
                                    if was_in_results:
                                        successful += 1
                                    ripped_items.pop()
                                continue

                            # Rebuild obstacles and retry
                            retry_obstacles, unrouted_stubs = build_diff_pair_obstacles(
                                diff_pair_base_obstacles, pcb_data, config, routed_net_ids, remaining_net_ids,
                                all_unrouted_net_ids, ripped_pair.p_net_id, ripped_pair.n_net_id, gnd_net_id,
                                track_proximity_cache, layer_map, diff_pair_extra_clearance,
                                add_own_stubs_func=add_own_stubs_as_obstacles_for_diff_pair,
                                ripped_route_layer_costs=state.ripped_route_layer_costs,
                                ripped_route_via_positions=state.ripped_route_via_positions
                            )

                            retry_result = route_diff_pair_with_obstacles(pcb_data, ripped_pair, config, retry_obstacles, base_obstacles, unrouted_stubs)

                            if retry_result and not retry_result.get('failed') and not retry_result.get('probe_blocked'):
                                print(f"  REROUTE RETRY SUCCESS (N={N}): {len(retry_result['new_segments'])} segments, {len(retry_result['new_vias'])} vias")
                                results.append(retry_result)
                                successful += 1
                                total_iterations += retry_result['iterations']
                                rerouted_pairs.add(ripped_pair_name)
                                apply_polarity_swap(pcb_data, retry_result, pad_swaps, ripped_pair_name, polarity_swapped_pairs)
                                add_route_to_pcb_data(pcb_data, retry_result, debug_lines=config.debug_lines)
                                refresh_net_obstacles(state.working_obstacles, state.net_obstacles_cache,  # #806
                                                      pcb_data, config,
                                                      (ripped_pair.p_net_id, ripped_pair.n_net_id))
                                from plane_fragility import fragility_on_copper_change  # #466
                                fragility_on_copper_change(config, pcb_data,
                                                           retry_result.get('new_segments'),
                                                           retry_result.get('new_vias'))
                                if ripped_pair.p_net_id in remaining_net_ids:
                                    remaining_net_ids.remove(ripped_pair.p_net_id)
                                if ripped_pair.n_net_id in remaining_net_ids:
                                    remaining_net_ids.remove(ripped_pair.n_net_id)
                                routed_net_ids.append(ripped_pair.p_net_id)
                                routed_net_ids.append(ripped_pair.n_net_id)
                                if retry_result.get('p_path'):
                                    routed_net_paths[ripped_pair.p_net_id] = retry_result['p_path']
                                if retry_result.get('n_path'):
                                    routed_net_paths[ripped_pair.n_net_id] = retry_result['n_path']
                                routed_results[ripped_pair.p_net_id] = retry_result
                                routed_results[ripped_pair.n_net_id] = retry_result
                                diff_pair_by_net_id[ripped_pair.p_net_id] = (ripped_pair_name, ripped_pair)
                                diff_pair_by_net_id[ripped_pair.n_net_id] = (ripped_pair_name, ripped_pair)
                                track_proximity_cache[ripped_pair.p_net_id] = compute_track_proximity_for_net(pcb_data, ripped_pair.p_net_id, config, layer_map)
                                track_proximity_cache[ripped_pair.n_net_id] = compute_track_proximity_for_net(pcb_data, ripped_pair.n_net_id, config, layer_map)
                                # Allow re-queuing if this pair gets ripped again later
                                queued_net_ids.discard(ripped_pair.p_net_id)
                                queued_net_ids.discard(ripped_pair.n_net_id)
                                # Invalidate blocking analysis cache since we added segments
                                invalidate_obstacle_cache(obstacle_cache, ripped_pair.p_net_id)
                                invalidate_obstacle_cache(obstacle_cache, ripped_pair.n_net_id)

                                # Queue ripped nets and add to history
                                rip_and_retry_history.add((current_canonical, blocker_canonicals))
                                if not hasattr(state, '_churn_counts'):
                                    state._churn_counts = {}
                                for net_id_tmp, saved_result_tmp, ripped_ids, was_in_results in ripped_items:
                                    state._churn_counts[net_id_tmp] = state._churn_counts.get(net_id_tmp, 0) + 1
                                    # Committed rip: custody of the pre-rip copper
                                    # for the casualties-only final reconcile.
                                    record_casualty(state, net_id_tmp, saved_result_tmp,
                                                    ripped_ids, was_in_results)
                                    if was_in_results:
                                        successful -= 1
                                    if net_id_tmp in diff_pair_by_net_id:
                                        ripped_pair_name_tmp, ripped_pair_tmp = diff_pair_by_net_id[net_id_tmp]
                                        canonical_id = ripped_pair_tmp.p_net_id
                                        if canonical_id not in queued_net_ids:
                                            reroute_queue.append(('diff_pair', ripped_pair_name_tmp, ripped_pair_tmp))
                                            queued_net_ids.add(canonical_id)
                                    else:
                                        if net_id_tmp not in queued_net_ids:
                                            net = pcb_data.nets.get(net_id_tmp)
                                            net_name_tmp = net.name if net else f"Net {net_id_tmp}"
                                            queue_reroute(state, ('single', net_name_tmp, net_id_tmp), net_id_tmp)
                                            queued_net_ids.add(net_id_tmp)

                                reroute_succeeded = True
                                break
                            else:
                                print(f"  REROUTE RETRY FAILED (N={N})")
                                if retry_result:
                                    if retry_result.get('probe_blocked'):
                                        last_retry_blocked_cells = retry_result.pop('blocked_cells', [])
                                    else:
                                        retry_fwd = retry_result.pop('blocked_cells_forward', [])
                                        retry_bwd = retry_result.pop('blocked_cells_backward', [])
                                        last_retry_blocked_cells = list(set(retry_fwd + retry_bwd))
                                        del retry_fwd, retry_bwd  # Free memory immediately
                                    if last_retry_blocked_cells:
                                        print(f"    Retry had {len(last_retry_blocked_cells)} blocked cells")
                                    else:
                                        print(f"    No blocked cells from retry to analyze")
                                else:
                                    print(f"    Retry returned no result (endpoint error?)")
                                    last_retry_blocked_cells = []

                        # If all N levels failed, restore all ripped nets
                        if not reroute_succeeded and ripped_items:
                            print(f"  {RED}All rip-up attempts failed: Restoring {len(ripped_items)} net(s){RESET}")
                            for net_id_tmp, saved_result_tmp, ripped_ids, was_in_results in reversed(ripped_items):
                                restore_net(net_id_tmp, saved_result_tmp, ripped_ids, was_in_results,
                                           pcb_data, routed_net_ids, routed_net_paths,
                                           routed_results, diff_pair_by_net_id, remaining_net_ids,
                                           results, config, track_proximity_cache, layer_map,
                                           state.working_obstacles, state.net_obstacles_cache,
                                           state.ripped_route_layer_costs, state.ripped_route_via_positions, refused_sink=state.collision_refused_net_ids)
                                if was_in_results:
                                    successful += 1

                # Fallback layer swap for setback failures in reroute (after rip-up fails)
                # Note: fwd_cells and bwd_cells already extracted above
                if not reroute_succeeded and enable_layer_switch and result:
                    fwd_iters = result.get('iterations_forward', 0)
                    bwd_iters = result.get('iterations_backward', 0)
                    is_setback_failure = (fwd_iters == 0 and bwd_iters == 0 and (fwd_cells or bwd_cells))

                    if is_setback_failure:
                        print(f"  Trying fallback layer swap for setback failure...")
                        swap_success, swap_result, _, _ = try_fallback_layer_swap(
                            pcb_data, ripped_pair, ripped_pair_name, config,
                            fwd_cells, bwd_cells,
                            diff_pair_base_obstacles, base_obstacles,
                            routed_net_ids, remaining_net_ids,
                            all_unrouted_net_ids, gnd_net_id,
                            track_proximity_cache, diff_pair_extra_clearance,
                            all_swap_vias, all_segment_modifications,
                            None, None,  # all_stubs_by_layer, stub_endpoints_by_layer
                            routed_net_paths, routed_results, diff_pair_by_net_id, layer_map,
                            target_swaps, results=results, obstacle_cache=obstacle_cache,
                            working_obstacles=state.working_obstacles,        # #806
                            net_obstacles_cache=state.net_obstacles_cache,
                        ripped_route_layer_costs=state.ripped_route_layer_costs,
                        ripped_route_via_positions=state.ripped_route_via_positions)

                        if swap_success and swap_result:
                            print(f"  {GREEN}FALLBACK LAYER SWAP SUCCESS{RESET}")
                            results.append(swap_result)
                            successful += 1
                            total_iterations += swap_result['iterations']
                            rerouted_pairs.add(ripped_pair_name)

                            apply_polarity_swap(pcb_data, swap_result, pad_swaps, ripped_pair_name, polarity_swapped_pairs)
                            add_route_to_pcb_data(pcb_data, swap_result, debug_lines=config.debug_lines)
                            refresh_net_obstacles(state.working_obstacles, state.net_obstacles_cache,  # #806
                                                  pcb_data, config,
                                                  (ripped_pair.p_net_id, ripped_pair.n_net_id))
                            from plane_fragility import fragility_on_copper_change  # #466
                            fragility_on_copper_change(config, pcb_data,
                                                       swap_result.get('new_segments'),
                                                       swap_result.get('new_vias'))
                            if ripped_pair.p_net_id in remaining_net_ids:
                                remaining_net_ids.remove(ripped_pair.p_net_id)
                            if ripped_pair.n_net_id in remaining_net_ids:
                                remaining_net_ids.remove(ripped_pair.n_net_id)
                            routed_net_ids.append(ripped_pair.p_net_id)
                            routed_net_ids.append(ripped_pair.n_net_id)
                            track_proximity_cache[ripped_pair.p_net_id] = compute_track_proximity_for_net(pcb_data, ripped_pair.p_net_id, config, layer_map)
                            track_proximity_cache[ripped_pair.n_net_id] = compute_track_proximity_for_net(pcb_data, ripped_pair.n_net_id, config, layer_map)
                            if swap_result.get('p_path'):
                                routed_net_paths[ripped_pair.p_net_id] = swap_result['p_path']
                            if swap_result.get('n_path'):
                                routed_net_paths[ripped_pair.n_net_id] = swap_result['n_path']
                            routed_results[ripped_pair.p_net_id] = swap_result
                            routed_results[ripped_pair.n_net_id] = swap_result
                            diff_pair_by_net_id[ripped_pair.p_net_id] = (ripped_pair_name, ripped_pair)
                            diff_pair_by_net_id[ripped_pair.n_net_id] = (ripped_pair_name, ripped_pair)
                            # Invalidate blocking analysis cache since we added segments
                            invalidate_obstacle_cache(obstacle_cache, ripped_pair.p_net_id)
                            invalidate_obstacle_cache(obstacle_cache, ripped_pair.n_net_id)
                            reroute_succeeded = True

                # Last-resort hybrid (issue #244): a rip-reroute casualty whose lane
                # is gone and whose standard probe + rip-up both dead-ended can still
                # have a coupled-middle + single-ended-leg escape (often to an inner
                # layer). The MAIN routing loop already tries this on a first-pass
                # failure (diff_pair_loop.py); the reroute path did not, so a pair
                # that only fails AFTER being ripped (butterstick /GIGABIT-0/ETH_B,
                # the /SYZYGY1.D1 class) failed honestly instead of taking the same
                # fallback. Rebuild the obstacle maps fresh -- rip-up/restore mutated
                # pcb_data since the reroute's were built. Returns None when it can't
                # lay a clean route, so this can't make things worse.
                if not reroute_succeeded and config.diff_pair_hybrid_escape:
                    hyb_obstacles, _ = build_diff_pair_obstacles(
                        diff_pair_base_obstacles, pcb_data, config, routed_net_ids, remaining_net_ids,
                        all_unrouted_net_ids, ripped_pair.p_net_id, ripped_pair.n_net_id, gnd_net_id,
                        track_proximity_cache, layer_map, diff_pair_extra_clearance,
                        add_own_stubs_func=add_own_stubs_as_obstacles_for_diff_pair,
                        ripped_route_layer_costs=state.ripped_route_layer_costs,
                        ripped_route_via_positions=state.ripped_route_via_positions)
                    # Single-ended leg clearance map. See build_diff_pair_leg_obstacles
                    # for why this uses base_obstacles + 0 clearance (not the coupled
                    # diff_pair_base_obstacles / extra clearance the middle map above
                    # uses) -- previously this site built it inconsistently (#246 review).
                    leg_obstacles = build_diff_pair_leg_obstacles(
                        base_obstacles, pcb_data, config, routed_net_ids, remaining_net_ids,
                        all_unrouted_net_ids, ripped_pair.p_net_id, ripped_pair.n_net_id,
                        gnd_net_id, track_proximity_cache, layer_map)
                    hyb = _route_direct_coupled_middle(
                        pcb_data, ripped_pair, config, hyb_obstacles, config.layers,
                        leg_obstacles=leg_obstacles)
                    if hyb and not hyb.get('failed'):
                        print(f"  {GREEN}HYBRID ESCAPE (reroute): direct coupled middle "
                              f"+ point-to-point terminal legs{RESET}")
                        results.append(hyb)
                        successful += 1
                        total_iterations += hyb.get('iterations', 0)
                        rerouted_pairs.add(ripped_pair_name)
                        record_diff_pair_success(
                            pcb_data, hyb, ripped_pair, ripped_pair_name, config,
                            remaining_net_ids, routed_net_ids, routed_net_paths, routed_results,
                            diff_pair_by_net_id, track_proximity_cache, layer_map,
                            working_obstacles=state.working_obstacles,    # #806
                            net_obstacles_cache=state.net_obstacles_cache)
                        queued_net_ids.discard(ripped_pair.p_net_id)
                        queued_net_ids.discard(ripped_pair.n_net_id)
                        invalidate_obstacle_cache(obstacle_cache, ripped_pair.p_net_id)
                        invalidate_obstacle_cache(obstacle_cache, ripped_pair.n_net_id)
                        reroute_succeeded = True

                if not reroute_succeeded:
                    if not ripped_items:
                        print(f"  {RED}REROUTE FAILED - could not find route{RESET}")
                    record_pair_diag(state, ripped_pair_name, outcome='failed',
                                     reason=rr_fail_reason, stage='reroute',
                                     blocking_nets=rr_fail_blockers or None)
                    # Remove from pending_multipoint_nets to prevent Phase 3 from
                    # trying to route taps for a net with no main route.
                    if ripped_pair.p_net_id in state.pending_multipoint_nets:
                        del state.pending_multipoint_nets[ripped_pair.p_net_id]
                    if ripped_pair.n_net_id in state.pending_multipoint_nets:
                        del state.pending_multipoint_nets[ripped_pair.n_net_id]
                    # #468: same terminal-restore leg for pair victims (the
                    # payload is registered under both member ids; restore_net
                    # restores the whole pair from either).
                    from rip_restore import try_terminal_restore
                    _tr = try_terminal_restore(
                        pcb_data, config, ripped_pair.p_net_id,
                        working_obstacles=state.working_obstacles,
                        net_obstacles_cache=state.net_obstacles_cache)
                    if _tr in ('full', 'full_open'):
                        _sv, _rids, _wir = pcb_data._rip_saved[ripped_pair.p_net_id]
                        restore_net(ripped_pair.p_net_id, _sv, _rids, _wir,
                                    pcb_data, routed_net_ids, routed_net_paths,
                                    routed_results, diff_pair_by_net_id,
                                    remaining_net_ids, results, config,
                                    track_proximity_cache, layer_map,
                                    state.working_obstacles, state.net_obstacles_cache,
                                    state.ripped_route_layer_costs,
                                    state.ripped_route_via_positions,
                                    refused_sink=state.collision_refused_net_ids)
                        state.terminal_restores[ripped_pair.p_net_id] = _tr
                        state.terminal_restores[ripped_pair.n_net_id] = _tr
                        if _tr == 'full':
                            print(f"  RIP-RESTORE (#468): pair {ripped_pair_name} "
                                  f"restored to its pre-rip route")
                            if _wir:
                                successful += 1
                        else:
                            print(f"  {RED}RIP-RESTORE (#468): pair "
                                  f"{ripped_pair_name} restored its pre-rip "
                                  f"copper but remains OPEN -- counted failed{RESET}")
                            failed += 1
                    else:
                        if _tr == 'stub':
                            state.terminal_restores[ripped_pair.p_net_id] = 'stub'
                            state.terminal_restores[ripped_pair.n_net_id] = 'stub'
                        failed += 1

    return successful, failed, total_time, total_iterations, route_index
