"""
Default routing parameter values.

This module defines the default values for routing parameters, used by both
the CLI (route.py) and the GUI (swig_gui.py) to ensure consistency.
"""

# Track/Via parameters
TRACK_WIDTH = 0.3  # mm
CLEARANCE = 0.25  # mm
VIA_SIZE = 0.5  # mm
VIA_DRILL = 0.3  # mm

# Fab tier and escalation policy (#857/#530): THE one place these defaults
# live -- fab_tiers.add_fab_tier_args (every routing CLI) and the GUI's
# controls read them from here. Completion first (Andy, 2026-09-03): 'auto'
# is the standard floor escalating to advanced when a fan-out, plane tap or
# last-resort via cannot fit, 'fab' lets a descent go below the board's own
# declared minimums to the tier floor -- the pre-#857 ladder, now disclosed
# (the ledger, JSON_SUMMARY design_rules, the end-of-run line, --strict-sizes).
# The hard tiers ('standard' / 'advanced') and the bounded policies
# ('board' / 'off') are the opt-in for a run that must not narrow.
FAB_TIER = 'auto'        # 'standard' | 'advanced' | 'auto'
ESCALATION = 'fab'       # 'off' | 'board' | 'fab'

# Grid parameters
GRID_STEP = 0.1  # mm

# Via-obstacle diagonal expansion margin: how far a via's keep-out reaches
# diagonally on the routing grid. MUST be identical between the per-net obstacle
# cache (_collect_via_obstacles) and the full obstacle map, or incremental
# rip/rebuild desyncs (see obstacle_map.py). Coincidentally equals CLEARANCE but
# is a distinct concept; centralized so the call sites can't drift.
DIAGONAL_MARGIN = 0.25  # mm

# Allowance subtracted from mm-exact PLACEMENT validation thresholds so that
# grid-quantized copper (endpoints rounded to the routing grid) is not
# rejected for sub-resolution noise. This is a placement tolerance, NOT the
# DRC grading margin (check_drc --clearance-margin): placement must demand
# (nearly) full clearance or it ships real grazes (#339).

# Clearance slack the #189/#339 via-in-pad UNBLOCK refit tolerates before it
# shrinks/rejects a rescue via. A tight quantization margin (a removed
# constant) stranded
# pads (ulx3s -11, butterstick -7) because a via grazing by a few tens of um was
# shrunk/rejected until the unblock failed. Tolerate up to this much sub-clearance
# at PLACEMENT and let the post-route via-nudge (nudge_grazing_vias) move the
# residual graze to full clearance instead -- a nudged via stays connected; a
# stranded pad does not. Matches check_drc's default grading margin.
UNBLOCK_REFIT_MARGIN_MM = 0.05  # mm (absolute; NOT a fraction like check_drc's clearance_margin)

# Cost parameters
VIA_COST = 75  # 50 -> 75: #586 corpus (via75: -8 verdict, DRC -13, and composes with hw 2.3)
VIA_PROXIMITY_COST = 10
TURN_COST = 1000
STUB_PROXIMITY_COST = 0.2
TRACK_PROXIMITY_COST = 0.0

# Distance parameters
STUB_PROXIMITY_RADIUS = 2.0  # mm
NECKDOWN_LENGTH = 2.5  # mm of narrow track from the pad on neck-down routes (issue #72)
NECKDOWN_TAPER_LENGTH = 0.5  # mm narrow->wide width taper (0 = abrupt)
TRACK_PROXIMITY_DISTANCE = 2.0  # mm
# #1146 pairwise keep-away: band cost per cell (mm equivalent; 0 = measure
# and report only) and the radius around the routed net's own pads where the
# band is not priced.
KEEP_AWAY_COST = 0.5
KEEP_AWAY_FREE = 1.5  # mm
BGA_PROXIMITY_RADIUS = 7.0  # mm
BGA_PROXIMITY_COST = 0.2

# Vertical alignment attraction
VERTICAL_ATTRACTION_RADIUS = 1.0  # mm
VERTICAL_ATTRACTION_COST = 0.0

# Ripped route avoidance
RIPPED_ROUTE_AVOIDANCE_RADIUS = 1.0  # mm
RIPPED_ROUTE_AVOIDANCE_COST = 0.1

# Impedance routing
IMPEDANCE_DEFAULT = 50  # ohms
# #486: design side gap from a controlled-impedance trace's edge to the
# same-layer ground pour. 0 = the trace is a plain microstrip (historical
# behaviour); > 0 declares it a coplanar waveguide over ground, which needs a
# NARROWER trace for the same target ohms. Must be matched by the plane step's
# zone clearance -- see route_planes --zone-clearance.
COPLANAR_GAP = 0.0  # mm (0 = not coplanar)

# Crossing penalty
CROSSING_PENALTY = 1000.0

# Probe iterations
MAX_PROBE_ITERATIONS = 5000

# Length matching
LENGTH_MATCH_TOLERANCE = 0.1  # mm
MEANDER_AMPLITUDE = 1.0  # mm
# Meander arm pitch centre-to-centre, in MULTIPLES of the net's routed track
# width (#501). 2.0 = 2W pitch = 1W edge gap between adjacent arms.
MEANDER_SPACING = 2.0  # x track width

# Time matching (alternative to length matching)
TIME_MATCHING = False  # If True, match propagation time instead of length
TIME_MATCH_TOLERANCE = 1.0  # ps

# GND via placement for single-ended routing
# Net to pin GND return vias to. "" = AUTO (#489 §5): resolve the ground net per
# signal from its OWN ground domain. On a single-ground board that is the same net
# the old literal "GND" default resolved to; on a split-ground board it stops
# analog vias being stitched to the digital ground. Naming a net here still pins
# every return via to it, board-wide.
GND_VIA_NET = ""  # Net name for GND vias ("" = auto, per ground domain)
GND_VIA_DISTANCE = 2.0  # mm - max distance from signal via to GND via

# Area via stitching (#485): lattice pitch for bonding a plane net's pours
# across the layers it owns. Off by default (route_planes --stitch-vias /
# the planes tab checkbox turns it on); the stitched nets are always the
# requested plane nets owning >= 2 plane layers -- deliberately no selection
# knob.
STITCH_PITCH = 20.0  # mm

# Algorithm parameters
MAX_ITERATIONS = 200000
HEURISTIC_WEIGHT = 2.3  # 1.9 -> 2.3: #586 corpus dose-response peak (-30 verdict, DRC -67, cpu/mem ~0.85x; 1.7 and 2.5 both worse)
PROXIMITY_HEURISTIC_FACTOR = 0.02  # restored from 0 (1af3096): "quality-neutral"
# was measured on a CLI that never applied it -- route.py's argparse still passed an
# explicit 0.02, which overrides the module default, so the corpus kept routing at 0.02
# for two more commits. b50fc86 fixed that drift and connectivity dropped 17 nets on a
# 5-board probe the same day; restoring 0.02 recovers 14 of them (50 -> 36 incomplete,
# eis reaching zero). Neighbouring doses are NOT better (0.01 -> 49, 0.04 -> 55), so
# treat 0.02 as the known-good value rather than a tuned optimum.
MAX_RIPUP = 3  # briefly 5 (s2 rescan -30 on the curated set) -- REVERTED: holdout sets 11-15 showed ripup5+zoned ERASING the other flips' gains (v4 -2% vs lean -45% vs old defaults) at +37% CPU; deep rip-up stays retry-tier guidance
# Phase 3 tap rip-up abandon metric (#85 arbitration); documented in
# docs/rip-up-reroute.md "Abandon metrics". Must match phase3_routing.ABANDON_METRICS.
RIPUP_ABANDON_METRIC = 'stranded'
RIPUP_ABANDON_METRIC_CHOICES = ('stranded', 'total-pads', 'complete-nets',
                                'congestion', 'history', 'weighted',
                                'probe', 'weighted-probe')

# Rip-up blocker SELECTION algorithm (#424 audit): which foreign net the
# rip-up ladder targets first when a route fails. 'count' is the historical
# weighted-cell-count ranking; the alternatives re-rank the same rippable set.
RIPUP_BLOCKER_SELECT = 'count'
# 'cost' (#510 follow-up): rank by weighted-count / sqrt(pads)*sqrt(span) so a
# CHEAP net is preferred as the rip victim. Plain 'count' correlates with
# victim SIZE, so the router systematically rips the most expensive net it
# could have picked (muzy_zynq2: +3V3 ripped 67x = 40% of all torn copper).
RIPUP_BLOCKER_SELECT_CHOICES = ('count', 'near-target', 'bidir', 'mincut', 'cost')

# Layer direction preference (0=horizontal, 1=vertical, 255=none)
# Alternates H/V starting with horizontal on top layer
DIRECTION_PREFERENCE_COST = 250  # Cost penalty per off-axis move (0 = disabled).
# 5 -> 250: REVERTS #663 (be73378b), re-screened with the ORACLE LEGS LIVE.
#
# #663 took this 250 -> 5 and reported -22 incomplete nets on sets1-5. That screen
# ran on the old cloud image, which ships NO KiCad -- so find_kicad_cli() returned
# None, oracle_reconnect returned available=False, and every oracle leg (the plane
# finalize audit, the #589 re-audit, the oracle-summary check) was a no-op. Re-screened
# at ONE commit with kicad/kicad:10.0.0 in the image, sets1-5, decision rule
# pre-registered before any arm reported:
#
#     dirs    verdict (incomplete nets)   real DRC
#       5            95                      58     <- #663's value
#      25           116                      57
#      50           117                      62
#     250            89                      43     <- this
#
# 250 wins on BOTH axes (-6 nets; -15 DRC over 8 boards better / 1 worse) and lands
# exactly on v0.21.2's own numbers -- paired against the released engine it is
# W0/L0/T69 with identical DRC. This ONE constant accounted for 100% of main's
# regression against 0.21.2; nothing else in the 21 commits since the tag moved it.
#
# 25 and 50 are worse than either end: a genuine interior WORST, not a plateau.
# Do not "split the difference" here without measuring.
#
# Why #663 concluded the opposite: its 5 came from a 4-point sweep on ONE board
# (orangecrab), and that board is an outlier for this knob -- a single-board
# optimum that did not generalize. Do not re-derive this from one board.
#
# Two follow-ups measured and RETIRED, so they need not be re-litigated:
#   * Coherence: making the oracle-weld/plane sub-configs follow this constant
#     instead of their hardcoded 250 moved nothing (94/59 vs 95/58). The VALUE
#     mattered; the mixed state did not.
#   * Diff pairs at base/10 (the theory that a coupled pair cannot pay an
#     off-axis tax): +6 nets and +52 real DRC vs plain 250, over 5 boards worse
#     / 1 better. Refuted; the divisor was dropped.
# 250 is a compromise: 5000 (5x a move) reproduced human H/V lane style but
# starved routability on dense boards (sets 6-11 A/B: +104 incomplete nets,
# kbic65 98.9%->15.1%, route.py ~2x slower); the old 50 (~5% of a move) was
# functionally inert. 250 (~25% of a move) keeps a real lane nudge without the
# cost-5000 wall that made short diagonal diode/matrix hops unroutable.

# Bus routing - auto-detection and parallel routing of grouped nets
BUS_DETECTION_RADIUS = 5.0  # mm - max endpoint distance to form bus
BUS_MIN_NETS = 2  # Minimum nets to form a bus
BUS_ATTRACTION_RADIUS = 5.0  # mm - attraction radius from neighbor track
BUS_ATTRACTION_BONUS = 5000  # Cost bonus for staying near neighbor

# Guide corridor - route selected nets through a user-drawn polyline (issue #7)
GUIDE_CORRIDOR_ENABLED = False
GUIDE_CORRIDOR_LAYER = "User.1"  # User layer the guide polyline is drawn on
GUIDE_CORRIDOR_SPACING = 0.0  # mm; 0 = waypoints only at drawn segment endpoints (else subdivide long segments)

# Keepout zone - keep routed tracks out of a user-drawn polygon (issue #27)
KEEPOUT_ENABLED = False
KEEPOUT_LAYER = "User.2"  # User layer the keepout polygon is drawn on

# Clearance parameters
ROUTING_CLEARANCE_MARGIN = 1.0
HOLE_TO_HOLE_CLEARANCE = 0.20  # mm - JLC "Via Hole-to-Hole Spacing" (edge-to-edge),
                               # the floor that governs router-placed via drills.
                               # (JLCPCB's pad-hole-to-hole is a separate, larger
                               # 0.45 mm; not modelled here -- this value targets
                               # via spacing. list_nets._FAB_FLOORS 'hole_to_hole'.)
                               # Routing AND check_drc default to this so a bare run
                               # never places/passes vias closer than is manufacturable.
NPTH_TO_TRACK_CLEARANCE = 0.20  # mm - JLC "NPTH to Track" fab floor: minimum copper
                                # (track) to NPTH mounting-hole edge. The drill removes
                                # any copper closer, so a track can't be routed/graded
                                # nearer than this regardless of the (smaller) routing
                                # clearance. Used by the NPTH track keep-out + check_drc
                                # track-hole check (issue #233).
BOARD_EDGE_CLEARANCE = 0.0  # mm

# Default layers
DEFAULT_LAYERS = ['F.Cu', 'B.Cu']

# Ordering strategy
DEFAULT_ORDERING_STRATEGY = "mps"

# BGA Fanout defaults
BGA_TRACK_WIDTH = 0.3  # mm
BGA_CLEARANCE = 0.25  # mm
BGA_VIA_SIZE = 0.5  # mm
BGA_VIA_DRILL = 0.3  # mm
BGA_EXIT_MARGIN = 0.5  # mm
BGA_DIFF_PAIR_GAP = 0.1  # mm

# QFN Fanout defaults
QFN_TRACK_WIDTH = 0.1  # mm
QFN_CLEARANCE = 0.1  # mm
QFN_EXTENSION = 0.05  # mm - extension past pad edge before bend (0.1 -> 0.05: s2 rescan, -25 verdict on 65 QFN boards -- shorter stubs leave routing room)

# Differential Pair defaults
DIFF_PAIR_WIDTH = 0.3  # mm track width for differential pairs (GUI diff tab
# default). #381 D4: matches route_diff.py's --track-width CLI default (0.3); the
# old 0.1 made GUI/plan diff runs 3x narrower than the equivalent CLI command.
# Consumed ONLY by the GUI diff tab -- the CLI/engine diff width default comes
# from route_diff.py's argparse and batch_route_diff_pairs' TRACK_WIDTH, so this
# change is GUI-only and does not move any CLI behavior.
DIFF_PAIR_GAP = 0.101  # mm gap between P and N traces
DIFF_PAIR_MIN_TURNING_RADIUS = 0.2  # mm
DIFF_PAIR_MAX_SETBACK_ANGLE = 45.0  # degrees
DIFF_PAIR_MAX_TURN_ANGLE = 180.0  # degrees
DIFF_PAIR_CHAMFER_EXTRA = 1.5  # multiplier for meander chamfers
DIFF_PAIR_CENTERLINE_SETBACK = 0.0  # mm - 0 = auto (2x P-N spacing)

# Plane routing defaults (route_planes.py)
PLANE_ZONE_CLEARANCE = 0.2  # mm - zone fill clearance from other copper
PLANE_MIN_THICKNESS = 0.1  # mm - minimum zone copper thickness
PLANE_EDGE_CLEARANCE = 0.5  # mm - zone clearance from board edge
# mm - longest gap between a spine's Voronoi seeds on a plane layer several
# nets share (route_planes.py --voronoi-seed-interval, the planes tab control)
VORONOI_SEED_INTERVAL = 2.0
PLANE_MAX_SEARCH_RADIUS = 10.0  # mm - max radius to search for via position
# #487: an SMD plane-net pad at least this wide in BOTH axes is a thermal/
# exposed pad and gets a via ARRAY instead of one shared via. ON by default
# (Andy 2026-07-29); --no-thermal-vias / the planes-tab checkbox disable it.
THERMAL_PAD_MIN_MM = 2.0
THERMAL_VIAS = True
PLANE_PAD_STRAP_RADIUS = 1.5  # mm - max distance to strap a plane pad to an
                              # adjacent already-connected same-net pad instead
                              # of drilling another via (issue #349)
PLANE_MAX_RIP_NETS = 3  # max blocker nets to rip up
# Run-6 guard: nets with more pads than this are never PICKED as tap/join
# blockers by the plane scripts' rip ladders -- ripping a rail as collateral
# opens every one of its pads at once, and the in-step reconnect repeatedly
# failed to restore them (test-board run 6: VCC3V3/VCC1V1 destroyed twice,
# ripped_reconnect 0/2). Deliberately ripping a rail is still possible by
PLANE_TRACK_VIA_CLEARANCE = 0.8  # mm - clearance from track center to other nets' via centers
SAME_NET_PAD_CLEARANCE = -1.0  # mm - edge-to-edge clearance between via and same-net pads
                               # when placing plane stitching vias. -1 disables (allow via-in-pad).
                               # Any value >= 0 forces vias to be placed outside same-net pads
                               # with that much edge-to-edge clearance.

# Fine-pitch tap escalation (plane_pad_tap.py, issues #99/#104)
# When a tap can't be placed at the nominal clearance/grid on dense fine-pitch
# QFN/LQFP/BGA pads, the router escalates to a finer grid and steps the clearance
# DOWN toward the manufacturing floor (list_nets.fab_floors for the board's layer
# count), narrowing the tap track to the fab track floor. There is deliberately
# NO hard-coded "fine clearance"/"fine track" magic number -- the floor is the
# fab limit, and the ladder stops at the first clearance that routes (issue #226).
FINE_PITCH_NEIGHBOR_DIST = 0.65  # mm - same-component neighbor spacing => fine-pitch
FINE_PITCH_MIN_PAD_DIM = 0.35    # mm - pad min dimension below this => fine-pitch
FINE_TAP_GRID_STEP = 0.05        # mm - fine routing grid for tight tap retries
FINE_TAP_CLEARANCE_STEPS = 4     # clearance steps from nominal down to the fab floor
FINE_TAP_SEARCH_RADIUS = 3.0     # mm - cap on NEW-via search during the fine retry
                                 # (a far new via at fine width butterflies neighbours;
                                 # far EXISTING vias are reached via the distant-trace path)

# Repair disconnected planes defaults (repair_planes.py)
REPAIR_MAX_TRACK_WIDTH = 2.0  # mm - maximum track width for connections
REPAIR_MIN_TRACK_WIDTH = 0.2  # mm - minimum track width for connections
REPAIR_ANALYSIS_GRID_STEP = 0.5  # mm - grid step for connectivity analysis

# Per-net fine-parameter rescue (net_rescue.py, issues #331/#371)
# After the main loop, rip-up ladder, reroute loop and Phase 3 have all had
# their shot, each still-failed (or partially connected) net gets one scoped
# last-chance retry: a small obstacle-map WINDOW around the remaining gap at a
# finer grid, with the track narrowed to the fab floor and the clearance
# stepped down toward the fab floor (mirrors the plane-tap fine ladder, #226).
# The limits below bound the compute: the window is sized to the gap (never
# the board), and the grid auto-coarsens until the window fits the cell
# budget — even past the run's own grid_step for a very long gap, so gap
# LENGTH needs no cap of its own (#516: the old 40mm RESCUE_MAX_GAP_MM skip
# shipped >40mm connector nets disconnected while saving nothing — the cell
# budget already bounds the search).
RESCUE_GRID_STEP = 0.025          # mm - fine grid for the scoped rescue retry
RESCUE_CLEARANCE_STEPS = 4        # clearance rungs from nominal down to the fab floor
RESCUE_WINDOW_MARGIN = 4.0        # mm of window past the gap bbox on every side
RESCUE_MIN_WINDOW_HALF = 6.0      # mm - minimum window half-size (detour room)
RESCUE_MAX_WINDOW_CELLS = 4_000_000  # per-layer cell budget; grid coarsens to fit
RESCUE_MAX_EDGES_PER_NET = 8      # max gap-closing attempts per rescued net
RESCUE_MAX_ITERATIONS = 1_000_000  # per-rung A* backstop. Deliberately generous:
                                   # hopeless rungs exhaust the small fenced window
                                   # in far fewer iterations no matter the budget
                                   # (measured on ottercast: a 200k cap saved zero
                                   # time and cost 7 recoveries - fine grid needs
                                   # ~4x the coarse iteration count), so this only
                                   # guards degenerate --max-iterations values.


# GUI-specific ranges (min, max, increment, digits)
# These define the SpinCtrl ranges for the GUI
PARAM_RANGES = {
    # 4 digits: fab-floor widths/drills carry a 4th decimal (e.g. a 6-layer
    # min track 0.0762mm). At digits=3 the SpinCtrlDouble rounded 0.0762 -> 0.076,
    # so the GUI routed BELOW the floor and every such track tripped a
    # track-width DRC the CLI (full precision) does not (#362).
    'track_width': {'min': 0.05, 'max': 25.0, 'inc': 0.05, 'digits': 4},
    'clearance': {'min': 0.05, 'max': 5.0, 'inc': 0.05, 'digits': 4},
    'via_size': {'min': 0.2, 'max': 2.0, 'inc': 0.05, 'digits': 4},
    'via_drill': {'min': 0.1, 'max': 1.5, 'inc': 0.05, 'digits': 4},
    'grid_step': {'min': 0.01, 'max': 1.0, 'inc': 0.01, 'digits': 4},
    'via_cost': {'min': 1, 'max': 1000},
    'max_iterations': {'min': 1000, 'max': 100000000},
    'heuristic_weight': {'min': 1.0, 'max': 10.0, 'inc': 0.1, 'digits': 1},
    'proximity_heuristic_factor': {'min': 0.0, 'max': 0.2, 'inc': 0.01, 'digits': 2},
    'turn_cost': {'min': 0, 'max': 10000},
    'direction_preference_cost': {'min': 0, 'max': 10000},
    'max_ripup': {'min': 0, 'max': 50},
    'stub_proximity_radius': {'min': 0.0, 'max': 10.0, 'inc': 0.5, 'digits': 1},
    'stub_proximity_cost': {'min': 0.0, 'max': 5.0, 'inc': 0.1, 'digits': 1},
    'neckdown_length': {'min': 0.0, 'max': 50.0, 'inc': 0.5, 'digits': 1},
    'neckdown_taper_length': {'min': 0.0, 'max': 5.0, 'inc': 0.1, 'digits': 1},
    'coplanar_gap': {'min': 0.0, 'max': 5.0, 'inc': 0.05, 'digits': 3},
    'via_proximity_cost': {'min': 0.0, 'max': 100.0, 'inc': 1.0, 'digits': 1},
    'track_proximity_distance': {'min': 0.0, 'max': 10.0, 'inc': 0.5, 'digits': 1},
    'track_proximity_cost': {'min': 0.0, 'max': 5.0, 'inc': 0.1, 'digits': 1},
    'keep_away_free': {'min': 0.0, 'max': 10.0, 'inc': 0.5, 'digits': 1},
    'keep_away_cost': {'min': 0.0, 'max': 5.0, 'inc': 0.1, 'digits': 1},
    'routing_clearance_margin': {'min': 0.5, 'max': 2.0, 'inc': 0.1, 'digits': 1},
    'hole_to_hole_clearance': {'min': 0.0, 'max': 1.0, 'inc': 0.05, 'digits': 3},
    'board_edge_clearance': {'min': 0.0, 'max': 5.0, 'inc': 0.1, 'digits': 3},
    'bga_proximity_radius': {'min': 0.0, 'max': 20.0, 'inc': 0.5, 'digits': 1},
    'bga_proximity_cost': {'min': 0.0, 'max': 5.0, 'inc': 0.1, 'digits': 1},
    'vertical_attraction_radius': {'min': 0.0, 'max': 10.0, 'inc': 0.5, 'digits': 1},
    'vertical_attraction_cost': {'min': 0.0, 'max': 5.0, 'inc': 0.1, 'digits': 1},
    'ripped_route_avoidance_radius': {'min': 0.0, 'max': 10.0, 'inc': 0.5, 'digits': 1},
    'ripped_route_avoidance_cost': {'min': 0.0, 'max': 5.0, 'inc': 0.1, 'digits': 1},
    'impedance': {'min': 10, 'max': 200, 'inc': 1, 'digits': 0},
    'crossing_penalty': {'min': 0.0, 'max': 10000.0, 'inc': 100.0, 'digits': 0},
    'max_probe_iterations': {'min': 100, 'max': 100000},
    'length_match_tolerance': {'min': 0.01, 'max': 5.0, 'inc': 0.01, 'digits': 2},
    'meander_amplitude': {'min': 0.1, 'max': 10.0, 'inc': 0.1, 'digits': 1},
    'meander_spacing': {'min': 1.0, 'max': 10.0, 'inc': 0.5, 'digits': 1},
    'time_match_tolerance': {'min': 0.1, 'max': 50.0, 'inc': 0.1, 'digits': 1},
    'gnd_via_distance': {'min': 0.5, 'max': 10.0, 'inc': 0.5, 'digits': 1},
    'stitch_pitch': {'min': 1.0, 'max': 100.0, 'inc': 1.0, 'digits': 1},
    # 0 = auto/off for the three below (GUI convention; the engine takes None)
    'stitch_fence_pitch': {'min': 0.0, 'max': 100.0, 'inc': 1.0, 'digits': 1},
    'stitch_inset': {'min': 0.0, 'max': 10.0, 'inc': 0.1, 'digits': 2},
    'stitch_max_freq': {'min': 0.0, 'max': 20000.0, 'inc': 50.0, 'digits': 0},
    # Fanout parameters
    'exit_margin': {'min': 0.1, 'max': 5.0, 'inc': 0.1, 'digits': 1},
    'diff_pair_gap': {'min': 0.05, 'max': 5.0, 'inc': 0.01, 'digits': 2},
    'qfn_extension': {'min': 0.05, 'max': 10.0, 'inc': 0.05, 'digits': 2},
    # Differential pair routing parameters
    'diff_pair_width': {'min': 0.05, 'max': 5.0, 'inc': 0.05, 'digits': 2},
    'diff_pair_min_turning_radius': {'min': 0.05, 'max': 2.0, 'inc': 0.05, 'digits': 2},
    'diff_pair_max_setback_angle': {'min': 10.0, 'max': 90.0, 'inc': 5.0, 'digits': 0},
    'diff_pair_max_turn_angle': {'min': 45.0, 'max': 360.0, 'inc': 15.0, 'digits': 0},
    'diff_pair_chamfer_extra': {'min': 1.0, 'max': 3.0, 'inc': 0.1, 'digits': 1},
    # digits 3: a SpinCtrlDouble rounds its value to its digits, so a plan's
    # --diff-pair-centerline-setback 0.25 would have arrived as 0.2 at digits 1.
    'diff_pair_centerline_setback': {'min': 0.0, 'max': 10.0, 'inc': 0.1, 'digits': 3},  # 0 = auto
    # Plane routing parameters
    'plane_zone_clearance': {'min': 0.05, 'max': 2.0, 'inc': 0.05, 'digits': 2},
    # route_planes.py --min-thickness / --voronoi-seed-interval, 4 and 3
    # digits for the setback's reason above: the control must hold what the
    # CLI is handed (a fab-floor width like 0.0762), not a rounding of it.
    'plane_min_thickness': {'min': 0.01, 'max': 2.0, 'inc': 0.05, 'digits': 4},
    'voronoi_seed_interval': {'min': 0.05, 'max': 50.0, 'inc': 0.5, 'digits': 3},
    'plane_edge_clearance': {'min': 0.0, 'max': 5.0, 'inc': 0.1, 'digits': 1},
    'plane_max_search_radius': {'min': 1.0, 'max': 50.0, 'inc': 1.0, 'digits': 1},
    'plane_max_via_reuse_radius': {'min': 0.0, 'max': 10.0, 'inc': 0.5, 'digits': 1},
    'plane_max_rip_nets': {'min': 1, 'max': 10},
    'same_net_pad_clearance': {'min': 0.0, 'max': 5.0, 'inc': 0.05, 'digits': 2},
    # Repair planes parameters
    'repair_max_track_width': {'min': 0.1, 'max': 10.0, 'inc': 0.1, 'digits': 3},
    'repair_min_track_width': {'min': 0.05, 'max': 5.0, 'inc': 0.05, 'digits': 2},
    'repair_analysis_grid_step': {'min': 0.1, 'max': 2.0, 'inc': 0.1, 'digits': 1},
    # Bus routing parameters
    'bus_detection_radius': {'min': 0.5, 'max': 100.0, 'inc': 0.5, 'digits': 1},
    'bus_attraction_radius': {'min': 0.5, 'max': 10.0, 'inc': 0.5, 'digits': 1},
    'bus_attraction_bonus': {'min': 0, 'max': 10000},
    'bus_min_nets': {'min': 2, 'max': 20},
}
