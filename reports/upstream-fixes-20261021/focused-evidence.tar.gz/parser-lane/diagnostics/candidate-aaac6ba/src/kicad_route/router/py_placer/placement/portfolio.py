"""K diverse placement candidates from one seed placement.

The quench is a zero-temperature greedy descent, and the placement stack is
deterministic by DESIGN (#457): same input, same knobs, same board, byte for
byte. That is the right property for reproducibility and exactly the wrong one
for exploring -- every run walks into the same local minimum, so "more
placement options" cannot come from re-running.

Diversity is therefore INJECTED at the seed, never un-suppressed: each
candidate is a legal PERTURBATION of the input placement (seeded jitter /
rotation variants / block-interior swaps), quenched with the ordinary engine,
then scored WITHOUT routing and pruned to a diverse, ranked slate. The
determinism contract survives intact:

  * every candidate draws from its own ``random.Random(f"{seed}:{i}:{strat}")``
    stream, so candidate i is byte-reproducible independently of the others --
    which is what makes ``--only N`` an exact replay primitive for a ledger;
  * everything else iterates sorted; there is no unseeded randomness, no
    clock, and no set-of-strings order anywhere in this module;
  * the quench engine is consumed through its public surface and never
    modified -- a plain place_optimize.py run is bit-identical with this
    module in the tree.

Perturbations are generated ON a shared oracle QuenchState and validated with
``candidate_valid`` as they are proposed (later parts see earlier ones already
moved), then written to a seed board with ``write_placed_output`` and quenched
from THAT file. Writing the quench result against the seed file -- exactly what
place_optimize does for its own input -- is what neutralizes quench's return
filter (a part that lands back on its perturbed seed is omitted from the
return, which is only safe when the output is written over the same seed).
"""
from __future__ import annotations

import fnmatch
import math
import os
import random
import shutil
from dataclasses import dataclass, field
from typing import Dict, List, NamedTuple, Optional, Sequence, Set, Tuple

DEFAULT_STRATEGIES: Tuple[str, ...] = ('jitter', 'poses', 'swap')
# How many of the highest-pin-count free parts that have an angle to turn to
# (#1121: a part at its single declared rotation has none) the `poses`
# strategy enumerates rotation variants for. Rotations of multi-pin parts are where pin order lives
# (the U3 rot-180 case: 9 forced inversions -> 0); a 2-pad passive's rotation
# rarely changes anything the jitter cannot.
POSES_TOP_PARTS = 6
# Rejection-resampling budget per part for the seeded strategies. Bounded so a
# dense board terminates; a part that finds no legal sample simply stays put,
# which is a smaller perturbation, not an error.
SAMPLE_ATTEMPTS = 20
EPS = 1e-6


@dataclass
class Candidate:
    """One portfolio row: where it came from, what it became, how it measures."""
    index: int
    strategy: str
    seed_board: str = ''            # the perturbed (pre-quench) board, or ''
    board: str = ''                 # the quenched result, or '' when barren
    poses: List[Dict] = field(default_factory=list)   # the perturbation
    final_poses: Dict[str, Tuple[float, float, float]] = field(
        default_factory=dict)       # ref -> (x, y, rot) after the quench
    moved_refs: List[str] = field(default_factory=list)
    displacement_rms: float = 0.0
    metrics: Dict = field(default_factory=dict)
    gates: Dict = field(default_factory=dict)
    intent: Optional[Dict] = None
    health: Optional[Dict] = None
    route: Optional[Dict] = None
    route_full: Optional[Dict] = None   # --full-probe verdict (whole board)
    note: str = ''

    @property
    def viable(self) -> bool:
        return bool(self.board) and bool(self.gates.get('passed'))

    def to_dict(self) -> Dict:
        d = {'index': self.index, 'strategy': self.strategy,
             'seed_board': self.seed_board, 'board': self.board,
             'poses': self.poses,
             'final_poses': {r: [round(v, 4) for v in p]
                             for r, p in sorted(self.final_poses.items())},
             'moved_refs': self.moved_refs,
             'displacement_rms': round(self.displacement_rms, 3),
             'metrics': self.metrics, 'gates': self.gates,
             'note': self.note}
        if self.intent is not None:
            d['intent'] = self.intent
        if self.health is not None:
            d['health'] = self.health
        if self.route is not None:
            d['route'] = self.route
        if self.route_full is not None:
            d['route_full'] = self.route_full
        return d


# --------------------------------------------------------------------------
# board / state plumbing
# --------------------------------------------------------------------------

def free_refs(pcb_data, pcb_file: str,
              lock_globs: Optional[Sequence[str]] = None,
              refused: Optional[Dict[str, str]] = None,
              intent_locks: Optional[Sequence[str]] = None) -> List[str]:
    """Sorted refs the portfolio may perturb: pad-bearing, not `(locked yes)`
    on the board, not matching a --lock glob, not drawing the board's own
    outline (#829), and not locked by the intent gate (`intent_locks`, its
    `lock_refs`: `must_lock` and the edge claims, #1129). The same lock
    sources the quench itself honors, resolved once so every consumer agrees.

    The intent's locks matter because the quench FREEZES them (quench.py,
    "Locked via intent") but freezes a part where it stands: a strategy that
    had already turned a must_lock part shipped it turned. None (perturb's
    callers, which have no intent channel) leaves the list as it was.

    `refused` is an optional out-dict `{ref: why}`, the idiom `seeder.
    reseat_scope` uses: name the source, and end with what the caller can do
    about it. The #829 and intent-lock refusals are recorded -- the pad and
    file/--lock rules were always silent here and stay that way, because the
    quench discloses those.
    """
    from placement.parser import extract_locked_refs
    locked = set(extract_locked_refs(pcb_file))
    held = set(intent_locks or ())
    out = []
    for ref, fp in pcb_data.footprints.items():
        # `fp.pads` on purpose (#1143): the portfolio perturbs what the
        # quench moves, and the quench keeps an aperture-only part movable.
        if not fp.pads:
            continue
        if ref in locked:
            continue
        if lock_globs and any(fnmatch.fnmatchcase(ref, p) for p in lock_globs):
            continue
        if getattr(fp, 'owns_board_outline', False):
            # Not `owns_edge_cuts`: a relief parented to the part travels WITH
            # it and must keep moving (crkbd's 184 per-LED windows, #628's
            # owned rings). Only geometry outside the board-level outline is
            # the board's own.
            if refused is not None:
                refused[ref] = ("draws the board outline -- moving it would "
                                "resize the board, which is not this tool's "
                                "to change (#829)")
            continue
        if ref in held:
            if refused is not None:
                refused[ref] = ("locked by the intent (must_lock or an edge "
                                "claim) -- the quench freezes it where it "
                                "stands, so no strategy may move it first "
                                "(#1129)")
            continue
        out.append(ref)
    return sorted(out)


def ignore_net_ids(pcb_data, patterns: Optional[Sequence[str]]) -> Set[int]:
    """Net ids matching the --ignore-nets patterns (plane-routed rails)."""
    ids: Set[int] = set()
    if patterns:
        for net_id, net in pcb_data.nets.items():
            if any(fnmatch.fnmatchcase(net.name, p) for p in patterns):
                ids.add(net_id)
    return ids


def make_oracle(pcb_data, pcb_file: str, *, free: Sequence[str],
                clearance: float, board_edge_clearance: float,
                grid_step: float, ignore_ids: Set[int]):
    """The shared scoring/legality state. Guidance weights (pose_score), the
    run's geometry knobs, and `move_refs=free` so `.locked` on each part
    matches what the portfolio is allowed to touch."""
    import pose_score
    return pose_score.make_state(
        pcb_data, pcb_file, clearance=clearance,
        board_edge_clearance=board_edge_clearance, grid_step=grid_step,
        ignore_net_ids=ignore_ids, move_refs=set(free))


def _snapshot(state, refs: Sequence[str]) -> Dict[str, Tuple[float, float, float]]:
    return {r: (state.parts[r].x, state.parts[r].y, state.parts[r].rot)
            for r in refs if r in state.parts}


def _restore(state, snap: Dict[str, Tuple[float, float, float]]) -> None:
    for ref in sorted(snap):
        x, y, rot = snap[ref]
        p = state.parts[ref]
        if (p.x, p.y, p.rot) != (x, y, rot):
            state.apply_move(ref, x, y, rot)


def copy_siblings(src_board: str, dst_board: str) -> None:
    """Carry the project/rules siblings (#441): a board without its .kicad_pro
    grades at the stock netclass, so every written candidate gets the input's
    siblings -- the probe routes and any later adoption read them."""
    src_base = os.path.splitext(src_board)[0]
    dst_base = os.path.splitext(dst_board)[0]
    from copy_board import SIBLING_EXTS   # ONE list (#711)
    for ext in SIBLING_EXTS:
        s, d = src_base + ext, dst_base + ext
        if not os.path.isfile(s):
            continue
        # IN PLACE the sibling is already its own destination. `copyfile`
        # raises SameFileError there (PermissionError via copy2 on Windows),
        # and every in-place run crashed AFTER writing its board: place_seed
        # --repair/--reseat with nothing to move and the seed path,
        # place_optimize X X, beautify_labels X X. `samefile`, not an abspath
        # compare, so a case-only spelling on a case-insensitive disk counts.
        if os.path.exists(d) and os.path.samefile(s, d):
            continue
        shutil.copyfile(s, d)


# --------------------------------------------------------------------------
# perturbation strategies
# --------------------------------------------------------------------------
# Each strategy PROPOSES poses on the oracle state, validating with
# candidate_valid and applying accepted moves as it goes -- so a later part is
# tested against its already-perturbed peers, and the emitted set is legal as a
# WHOLE, not merely pairwise against the original board. The caller owns the
# snapshot/restore bracket.

def jitter_lattice(pcb_data, radius: float) -> Tuple[Optional[float], Dict]:
    """The pitch a jitter OFFSET is a multiple of, or None for no snap (#826).

    NOT `board_grid.resolve_snap_lattice`, and the difference is the whole
    design. That function's fallback is `grid_step`, which is the right off
    state for the QUENCH -- whose offsets were already multiples of `step`, so
    falling back to the raster restored exactly today's granularity. The jitter
    is CONTINUOUS, so snapping a no-lattice board to the 0.1 raster would
    change behaviour to buy nothing. The off state here is no snap at all, and
    the board still reaches it rather than a flag. Calling `resolve_snap_lattice`
    and then undoing its fallback would also write `resolved: 0.1` into the
    evidence while nothing snapped to 0.1, which is worse than useless.

    Refuses a lattice COARSER than the radius: below it the disc holds no
    destination but the seed itself, so every candidate goes barren and the CLI
    exits 4 without anything naming a lattice. Measured on interf_u_unrouted
    (0.3175): `--radius 0.3175` still perturbs 22 of 22 parts, `--radius 0.3`
    perturbs 0 of 22 after burning 440 draws. `> radius`, not `>=`, because the
    equality case demonstrably works.

    No coarse-lattice guard beyond that, deliberately: `infer_board_grid` can
    only ever return 0.05 or 0.3175 (only those two rungs have no proper
    divisor in the ladder), and at radius 4.0 a 0.3175 lattice offers ~500
    destinations, of which the sampler takes the first legal one --
    `SAMPLE_ATTEMPTS` is the retry budget, not a count of destinations used.
    Measured, the most boxed-in part on any 0.3175 board still has 9 legal
    destinations. Starvation is unreachable here, unlike at the fanout repair
    site.
    """
    from placement.board_grid import infer_board_grid
    ev = infer_board_grid(pcb_data)
    step = ev['step']
    if step is not None and step > radius:
        ev = dict(ev, reason='inferred %g mm exceeds the %g mm jitter radius, '
                             'which would leave the disc no destination but '
                             'the seed' % (step, radius))
        step = None
    # `step` is WHAT WAS USED, in every branch. The raw inference moves to
    # `inferred_step`, and it is kept rather than dropped because the radius
    # guard's reason is only readable beside it.
    #
    # The first version left `ev['step']` at the inferred value while
    # `resolved` went None, so a guarded run reported `{"step": 0.3175,
    # "resolved": null}` -- three fields describing a snap that never happened.
    # `infer_board_grid`'s own docstring promises `d['step']` as the terse
    # form, so a consumer reading it would have been told the opposite of what
    # happened, and `board_grid.describe(ev)` would have printed it.
    return step, dict(ev, step=step, inferred_step=ev['step'],
                      source='inferred' if step is not None else 'none',
                      resolved=step)


def perturb_jitter(state, refs: Sequence[str], rng: random.Random,
                   radius: float, attempts: int = SAMPLE_ATTEMPTS, *,
                   lattice: Optional[float] = None) -> List[Dict]:
    """Uniform-disc offset per free ref, rotation unchanged. The direct
    basin-escape for a zero-temperature descent: the quench cannot leave a
    local minimum, so the seed does it instead, bounded by `radius`.

    A part whose INCUMBENT pose is not fully legal is skipped, not jittered.
    Two real populations live there: parts off the board by design (edge
    connectors, castellated rows -- candidate_valid's toward-the-board branch
    would happily walk one inboard and silently break its overhang spec) and
    dense hand-packed parts already under the courtyard clearance (any
    accepted sample would be a lateral trade the quench's own gate refuses).
    Skipping draws nothing from the rng, so the stream stays stable.

    `lattice` (#826) is the pitch the OFFSET is a multiple of, or None for the
    continuous sampler this has always been. Given one, the escape still goes
    anywhere in the disc -- it just arrives on the grid the board was laid out
    on, so the quench that follows can preserve a lattice instead of inheriting
    an arbitrary residue. Measured: on 10 of the 11 tracked boards that declare
    a lattice, the continuous sampler destroyed it before the quench ever
    parsed the seed board (`tests/measure_826_jitter_lattice.py`).

    None is the default and `portfolio.generate` is the only caller that passes
    a lattice. `perturb.py`'s `scatter` damage kind deliberately does not: its
    own comment calls it "the POSITIVE CONTROL ... the arm that MUST recover",
    and a snapped offset would land the part exactly on the coset the quench
    generates from -- one nudge reaches it -- making the control easier to
    pass. That is the one direction a positive control must not move.
    """
    from placement.utility import snap_to_grid
    poses: List[Dict] = []
    for ref in refs:
        part = state.parts.get(ref)
        if part is None:
            continue
        if not state.candidate_valid(ref, part.x, part.y, part.rot):
            continue
        for _ in range(attempts):
            r = radius * math.sqrt(rng.random())
            th = 2.0 * math.pi * rng.random()
            dx = r * math.cos(th)
            dy = r * math.sin(th)
            if lattice is not None:
                # The OFFSET, never `part.x + dx`. `part.x` carries the board's
                # own phase and is not generally a multiple of anything, so
                # snapping the SUM would discard exactly what this is for.
                # #708's form, at a fourth site.
                dx = snap_to_grid(dx, lattice)
                dy = snap_to_grid(dy, lattice)
                if dx == 0.0 and dy == 0.0:
                    # Not a perturbation. Accepting it would be guaranteed to
                    # succeed -- `candidate_valid` on the incumbent pose was
                    # just asserted above -- so it would emit a pose identical
                    # to the seed, inflate the "N part(s) perturbed" line, and
                    # put a ref in `poses` that `_displacement` (d > 1e-4) does
                    # not count as moved.
                    continue
                if math.hypot(dx, dy) > radius + 1e-9:
                    # Snapped OUT of the disc. Tested AFTER the snap so the
                    # radius stays an exact bound, as `quench._candidate_
                    # positions` and `fanout_clearance` both do -- `--radius`
                    # is a number the operator reasons with ("10mm-class values
                    # destroy corridors"), not a soft target.
                    continue
            if lattice is None:
                # The continuous sampler's 0.1um raster, unchanged.
                x = round(part.x + dx, 4)
                y = round(part.y + dy, 4)
            else:
                # NOT rounded. `dx` is an exact lattice multiple, so
                # `part.x + dx` sits on the seed's coset exactly -- and
                # rounding the SUM to 4dp would knock it back off for any
                # board whose origins carry 5 or 6 decimals, which KiCad
                # writes for rotated and imported parts. Inert on today's
                # corpus (checked: no tracked lattice board has an origin
                # past 4dp, so the round was a no-op) and the whole point of
                # the change on a board that does. `write_placed_output`
                # formats the `(at ...)` node at %.6f, so the extra precision
                # survives the write.
                x = part.x + dx
                y = part.y + dy
            if state.candidate_valid(ref, x, y, part.rot):
                state.apply_move(ref, x, y, part.rot)
                poses.append({'reference': ref, 'new_x': x, 'new_y': y,
                              'new_rotation': part.rot})
                break
    return poses


def _pose_variants(part, claim) -> List[float]:
    """The angles the `poses` strategy may turn `part` to (#1121).

    Undeclared (`claim` None): its three quarter turns, as always. Declared
    (a `rotations_for_ref` claim): the angles `floorplan.declared_ladder`
    gives, in the author's order, other than the one the part already has --
    the rule the quench's swap applies (`quench._declared_admits`): a turn
    may go INTO the declaration, never out of it. So a part sitting at its
    single declared angle has no variant at all, and one sitting off it is
    offered that angle."""
    if claim is None:
        return [(part.rot + d) % 360 for d in (90.0, 180.0, 270.0)]
    from placement.floorplan import declared_ladder
    from placement.quench import _same_angle
    return [a % 360 for a in declared_ladder(claim)
            if not _same_angle(a, part.rot)]


def _poses_ranked(state, refs: Sequence[str], declared) -> List[str]:
    """The top `POSES_TOP_PARTS` multi-pin free parts that HAVE an angle to
    turn to. Filtered before the cut, so a declared part that cannot turn
    does not spend one of the slots; an undeclared part always has three
    variants, so an undeclared board ranks exactly as before #1121."""
    return sorted((r for r in refs
                   if r in state.parts and state.parts[r].pin_count >= 2
                   and _pose_variants(state.parts[r], declared.get(r))),
                  key=lambda r: (-state.parts[r].pin_count, r))[:POSES_TOP_PARTS]


def perturb_poses(state, refs: Sequence[str],
                  variant_index: int,
                  declared: Optional[Dict] = None) -> Optional[List[Dict]]:
    """Deterministic rotation variant: one of the top multi-pin free parts
    turned to a legal rotation that does not RAISE its forced-crossing floor.

    The inversion prune is the point -- ``pair_order.ref_inversions`` is a
    lower bound no router can remove, so a rotation that increases it is
    provably worse before any quench is paid (the U3 rot-180 story, run 5:
    the cost was indifferent, the inversion count was not). Returns None when
    `variant_index` runs past the legal variants: that strategy round is
    barren, which the caller reports rather than papers over.

    `declared` is the intent's rotation claims, `{ref: (rotation,
    candidates)}` from `floorplan.rotations_for_ref` (#1121): a declared
    part is turned only into its declaration (`_pose_variants`). None or {}
    is the strategy exactly as it was."""
    from placement.pair_order import ref_inversions
    declared = declared or {}
    ranked = _poses_ranked(state, refs, declared)
    variants: List[Tuple[str, float]] = []
    for ref in ranked:
        part = state.parts[ref]
        # Same incumbent guard as jitter: a part off the board or already
        # under clearance must not be offered rotations through
        # candidate_valid's improvement branch.
        if not state.candidate_valid(ref, part.x, part.y, part.rot):
            continue
        base_inv = ref_inversions(state, ref)
        claim1121 = declared.get(ref)
        for rot in _pose_variants(part, claim1121):
            if claim1121 is not None:
                # A declared angle need not be on the part's quarter-turn
                # lattice; judge it on its own box, as the quench nudge does.
                from placement.seeder import _materialise_rotation
                rot = _materialise_rotation(part, rot)
            if not state.candidate_valid(ref, part.x, part.y, rot):
                continue
            if ref_inversions(state, ref, part.x, part.y, rot) > base_inv:
                continue
            variants.append((ref, rot))
    if variant_index >= len(variants):
        return None
    ref, rot = variants[variant_index]
    part = state.parts[ref]
    state.apply_move(ref, part.x, part.y, rot)
    return [{'reference': ref, 'new_x': part.x, 'new_y': part.y,
             'new_rotation': rot}]


def perturb_swaps(state, blocks: Dict[str, Sequence[str]], rng: random.Random,
                  n_swaps: int, attempts: int = SAMPLE_ATTEMPTS) -> List[Dict]:
    """Exchange the positions of two free members of one block, n_swaps times.

    This is the rearrangement the quench's own swap phase cannot reach: its
    swaps are capped by max_displacement and same-footprint only, so two
    different parts across a zone never trade places. Each exchange is tested
    part-vs-world with the partner excluded (it vacates), plus an exact
    pair test of the two NEW poses against each other.

    Members are filtered to FREE parts here, not left to geometry:
    candidate_valid answers "is this pose legal", never "may this part move",
    so without the filter a swap could relocate a locked connector."""
    def _free_members(refs):
        # Free AND legally seated: the same incumbent guard jitter applies --
        # an off-board or sub-clearance part must not be traded through
        # candidate_valid's improvement branch.
        return sorted(r for r in refs
                      if r in state.parts and not state.parts[r].locked
                      and state.parts[r].pin_count > 0
                      and state.candidate_valid(
                          r, state.parts[r].x, state.parts[r].y,
                          state.parts[r].rot))

    eligible = sorted(name for name, refs in blocks.items()
                      if len(_free_members(refs)) >= 2)
    if not eligible:
        return []
    poses: Dict[str, Dict] = {}
    made = 0
    for _ in range(attempts):
        if made >= n_swaps:
            break
        name = eligible[rng.randrange(len(eligible))]
        members = _free_members(blocks[name])
        a, b = rng.sample(members, 2)
        pa, pb = state.parts[a], state.parts[b]
        ax, ay, bx, by = pa.x, pa.y, pb.x, pb.y
        if not state.candidate_valid(a, bx, by, pa.rot, exclude={b}):
            continue
        if not state.candidate_valid(b, ax, ay, pb.rot, exclude={a}):
            continue
        # candidate_valid excluded the partner, so the two NEW poses were
        # never tested against each other; do it exactly.
        if getattr(state, 'courtyards_ignored', False):
            # #1104: courtyards waived, so the two NEW poses are tested
            # against each other the way the waived seat tests a pair: pads
            # and holes at their own requirement, drills, bodies.
            if pa.sides & pb.sides:
                from .seeder import _drill_conflict
                ctx = state.legality_ctx
                if ctx is not None:
                    sf = ctx.pair_shortfall(a, b, pose_a=(bx, by, pa.rot),
                                            pose_b=(ax, ay, pb.rot))
                    if (sf.pad > 1e-9 or sf.pad_overlap or sf.stack
                            or sf.hole > 1e-9):
                        continue
                if _drill_conflict(state, a, (bx, by, pa.rot), b,
                                   (ax, ay, pb.rot)):
                    continue
            gap = None
        else:
            gap = pa.gap_to(pb, pa.rects(bx, by, pa.rot),
                            pb.rects(ax, ay, pb.rot))
        if gap is not None and gap < state.clearance:
            continue
        state.apply_move(a, bx, by, pa.rot)
        state.apply_move(b, ax, ay, pb.rot)
        poses[a] = {'reference': a, 'new_x': bx, 'new_y': by,
                    'new_rotation': pa.rot}
        poses[b] = {'reference': b, 'new_x': ax, 'new_y': ay,
                    'new_rotation': pb.rot}
        made += 1
    return [poses[r] for r in sorted(poses)]


# --------------------------------------------------------------------------
# generation
# --------------------------------------------------------------------------

def _final_poses(pcb_data, placements: List[Dict]) -> Dict[str, Tuple[float, float, float]]:
    """Seed poses overlaid with the quench's returned moves. The quench omits
    parts that ended exactly on their seed, so the overlay IS the final state."""
    # `fp.pads` on purpose (#1143): the overlay covers what the quench can
    # move, which includes a part whose only pads are apertures.
    out = {ref: (fp.x, fp.y, fp.rotation % 360)
           for ref, fp in pcb_data.footprints.items() if fp.pads}
    for p in placements:
        out[p['reference']] = (p['new_x'], p['new_y'], p['new_rotation'])
    return out


def _displacement(final: Dict[str, Tuple[float, float, float]],
                  origin: Dict[str, Tuple[float, float, float]],
                  free: Sequence[str]) -> Tuple[float, List[str]]:
    """(rms displacement over free refs, refs that moved) vs the input board."""
    moved = []
    acc = 0.0
    n = 0
    for ref in free:
        if ref not in final or ref not in origin:
            continue
        fx, fy, frot = final[ref]
        ox, oy, orot = origin[ref]
        d = math.hypot(fx - ox, fy - oy)
        rot_changed = abs((frot - orot) % 360) > 1e-3
        if d > 1e-4 or rot_changed:
            moved.append(ref)
        acc += d * d + (1.0 if rot_changed else 0.0)
        n += 1
    return (math.sqrt(acc / n) if n else 0.0), moved


def pose_distance_mm(final_a: Dict[str, Tuple[float, float, float]],
                     final_b: Dict[str, Tuple[float, float, float]],
                     free: Sequence[str]) -> float:
    """RMS pose distance over the free refs; a rotation difference counts a
    flat 1.0. Pose distance, not hpwl distance, deliberately: hpwl reads only
    per-net extremes, so a mirrored or permuted arrangement can tie a clone --
    this measures "a genuinely different placement" directly."""
    acc = 0.0
    n = 0
    for ref in free:
        if ref not in final_a or ref not in final_b:
            continue
        ax, ay, arot = final_a[ref]
        bx, by, brot = final_b[ref]
        acc += (ax - bx) ** 2 + (ay - by) ** 2
        if abs((arot - brot) % 360) > 1e-3:
            acc += 1.0
        n += 1
    return math.sqrt(acc / n) if n else 0.0


def _quench_to(src_board: str, dst_board: str, quench_kw: Dict,
               groups: Optional[Dict], cancel_check=None,
               progress_callback=None) -> Tuple[Dict, Dict]:
    """Parse src, quench in-process, write the result AGAINST src (the seed
    file), carry siblings. Returns (metrics, final_poses)."""
    from kicad_parser import parse_kicad_pcb
    from placement.quench import quench
    from placement.writer import write_placed_output
    pcb_local = parse_kicad_pcb(src_board)
    m: Dict = {}
    placements = quench(pcb_local, pcb_file=src_board, metrics_out=m,
                        groups=groups, cancel_check=cancel_check,
                        progress_callback=progress_callback, **quench_kw)
    write_placed_output(src_board, dst_board, placements)
    copy_siblings(src_board, dst_board)
    return m, _final_poses(pcb_local, placements)


def generate(input_file: str, out_dir: str, *, seed: int = 0,
             n_candidates: int = 12,
             strategies: Sequence[str] = DEFAULT_STRATEGIES,
             radius: float = 4.0,
             lock_globs: Optional[Sequence[str]] = None,
             ignore_nets: Optional[Sequence[str]] = None,
             swap_blocks: Optional[Dict[str, Sequence[str]]] = None,
             quench_kw: Optional[Dict] = None,
             groups: Optional[Dict] = None,
             only: Optional[int] = None,
             cancel_check=None, progress_callback=None) -> Dict:
    """Generate the portfolio: baseline quench (candidate 0) plus perturbed
    candidates 1..n_candidates-1, all boards written under `out_dir`.

    Deterministic by contract: candidate i's stream is
    ``random.Random(f"{seed}:{i}:{strategy}")`` and its `poses` variant index
    is the round number ``(i-1) // len(strategies)`` -- both functions of i
    alone, so ``only=i`` regenerates that candidate byte-identically without
    running the others.

    Returns {'baseline': Candidate|None, 'candidates': [Candidate], 'free': [...]}.
    """
    from kicad_parser import parse_kicad_pcb
    from placement.writer import write_placed_output

    os.makedirs(out_dir, exist_ok=True)
    qkw = dict(quench_kw or {})
    strategies = tuple(strategies)
    if not strategies:
        raise ValueError("no strategies enabled")

    pcb = parse_kicad_pcb(input_file)
    _refused: Dict[str, str] = {}
    free = free_refs(pcb, input_file, lock_globs, refused=_refused,
                     intent_locks=(qkw.get('intent_gate') or {}).get(
                         'lock_refs'))
    for _ref, _why in sorted(_refused.items()):
        print(f"  NOTE: {_ref} not perturbed: {_why}")
    ids = ignore_net_ids(pcb, ignore_nets)
    oracle = make_oracle(
        pcb, input_file, free=free,
        clearance=qkw.get('clearance', 0.25),
        board_edge_clearance=qkw.get('board_edge_clearance', 0.55),
        grid_step=qkw.get('grid_step', 0.1), ignore_ids=ids)
    origin = {ref: (p.x, p.y, p.rot) for ref, p in oracle.parts.items()}
    # #1121: the SAME block claims the quench is gated with (its
    # intent_gate), so the `poses` variant offers a block-declared part only
    # an angle the quench would admit too. Not held here: an
    # `arrays[].rotation` member. A part the gate locks (`must_lock`, an edge
    # claim) is not free at all: `free_refs` drops it (#1129).
    _declared = dict((qkw.get('intent_gate') or {}).get('rotations') or {})
    _held = sorted(r for r in free if r in _declared)
    if _held and 'poses' in strategies:
        print("[portfolio] poses: %d free part(s) declare a rotation (%s); "
              "each is turned only to an angle its declaration admits (#1121)"
              % (len(_held), ', '.join(_held)))

    # #826: resolved ONCE, from the INPUT board, never from the oracle state.
    # `--only N` must regenerate candidate N byte-identically without running
    # 1..N-1, so the lattice has to be a function of (input_file, radius)
    # alone -- a read off a partially-perturbed state would make it depend on
    # what earlier candidates did and the ledger's replay primitive would
    # silently stop replaying. `board_coordinates`' own docstring forbids a
    # filtered sample for the same reason.
    lattice, lattice_ev = jitter_lattice(pcb, radius)
    if lattice is not None:
        print("[portfolio] jitter offsets snap to %g mm (inferred, %.0f%% of "
              "%d footprint coordinates)"
              % (lattice, 100.0 * lattice_ev['occupancy'],
                 lattice_ev['n_values']))
    else:
        print("[portfolio] jitter offsets are continuous (no snap: %s)"
              % lattice_ev['reason'])

    baseline: Optional[Candidate] = None
    if only is None:
        print(f"[portfolio] candidate 0 (baseline): plain quench")
        board0 = os.path.join(out_dir, 'baseline_quenched.kicad_pcb')
        m, final = _quench_to(input_file, board0, qkw, groups, cancel_check=cancel_check,
                   progress_callback=progress_callback)
        rms, moved = _displacement(final, origin, free)
        baseline = Candidate(
            index=0, strategy='baseline', seed_board=input_file, board=board0,
            final_poses=final, moved_refs=moved, displacement_rms=rms,
            metrics=_quench_metrics(m))

    indices = [only] if only is not None else list(range(1, n_candidates))
    candidates: List[Candidate] = []
    for i in indices:
        # BETWEEN CANDIDATES, which is this loop's real unit: each one is a
        # full quench over the whole board. Checking inside the quench too
        # (it has its own hook) bounds the tail; this bounds the count.
        if cancel_check is not None and cancel_check():
            print(f"  portfolio: stopping before candidate {i} (budget)")
            break
        if i < 1:
            raise ValueError(f"candidate index {i} out of range (baseline is "
                             f"not regenerable via only=; it has no stream)")
        strategy = strategies[(i - 1) % len(strategies)]
        rng = random.Random(f"{seed}:{i}:{strategy}")
        snap = _snapshot(oracle, free)
        note = ''
        if strategy == 'jitter':
            poses = perturb_jitter(oracle, free, rng, radius,
                                   lattice=lattice)
        elif strategy == 'poses':
            poses = perturb_poses(oracle, free, (i - 1) // len(strategies),
                                  declared=_declared)
            if poses is None:
                poses = []
                note = ('poses: no rotation variant left at round '
                        f'{(i - 1) // len(strategies)}')
        elif strategy == 'swap':
            n_swaps = rng.randint(1, 3)
            poses = perturb_swaps(oracle, swap_blocks or {}, rng, n_swaps)
            if not poses and not swap_blocks:
                note = 'swap: no blocks resolved (pass --intent or --group-by)'
        else:
            raise ValueError(f"unknown strategy {strategy!r}")
        _restore(oracle, snap)

        cand = Candidate(index=i, strategy=strategy, poses=poses, note=note)
        if not poses:
            cand.note = cand.note or f'{strategy}: produced no perturbation'
            cand.gates = {'passed': False, 'reasons': [cand.note]}
            candidates.append(cand)
            print(f"[portfolio] candidate {i} ({strategy}): barren -- {cand.note}")
            continue

        print(f"[portfolio] candidate {i} ({strategy}): "
              f"{len(poses)} part(s) perturbed")
        seed_board = os.path.join(out_dir, f'cand_{i:02d}.seed.kicad_pcb')
        write_placed_output(input_file, seed_board, poses)
        copy_siblings(input_file, seed_board)
        board = os.path.join(out_dir, f'cand_{i:02d}.kicad_pcb')
        m, final = _quench_to(seed_board, board, qkw, groups, cancel_check=cancel_check,
                   progress_callback=progress_callback)
        rms, moved = _displacement(final, origin, free)
        cand.seed_board = seed_board
        cand.board = board
        cand.final_poses = final
        cand.moved_refs = moved
        cand.displacement_rms = rms
        cand.metrics = _quench_metrics(m)
        candidates.append(cand)

    return {'baseline': baseline, 'candidates': candidates,
            'free': free, 'jitter_lattice': lattice_ev}


def _quench_metrics(m: Dict) -> Dict:
    """The unweighted, cross-run-comparable slice of a quench's metrics_out."""
    after = m.get('after', {})
    leg = m.get('legality', {})
    return {'crossings': after.get('crossings'),
            'hpwl': round(after.get('hpwl', 0.0), 3),
            'length': round(after.get('length', 0.0), 3),
            'overlap_area': round(leg.get('overlap_area', 0.0), 4),
            'oob_count': leg.get('oob_count', 0),
            'oob_amount': round(leg.get('oob_amount', 0.0), 4),
            # Pad+drill layer tallies (AABB gate currency; absent -> 0 when
            # the layer is off, keeping old-metric candidates comparable).
            'pad_conflict_pairs': leg.get('pad_conflict_pairs', 0),
            'pad_shortfall': leg.get('pad_shortfall', 0.0),
            'hole_shortfall': leg.get('hole_shortfall', 0.0),
            # #1031: parts with an ILLEGAL pad in a rule-area keep-out band.
            'keepout_pad_parts': leg.get('keepout_pad_parts', 0),
            'keepout_pad_amount': leg.get('keepout_pad_amount', 0.0),
            # #826: which lattice THIS candidate's quench actually USED, in
            # the three-scalar vocabulary check_pockets' census already uses.
            # Read off the board the quench PARSES -- the candidate's jittered
            # seed board -- so before the jitter snapped it disagreed with the
            # baseline's on ten of the eleven lattice boards (None against
            # 0.3175 on splitflap). NOT on all eleven: glasgow_revC's jittered
            # seed still resolved 0.05, which is the same reason it is the one
            # survivor in the population table.
            #
            # `resolved`, NOT `step`. `quench` infers a lattice and can then
            # fall back (when it is coarser than `--step`), leaving `step` at
            # the INFERENCE and putting what it used in `resolved`. Reading
            # `step` reported a lattice the quench never used: measured, at
            # `--step 0.25` on an imperial board the shipped candidate has no
            # lattice at all and 0.120 occupancy, while this key said 0.3175.
            # A disclosure that exists to prove the fix is not inert must not
            # be able to report success on an inert run.
            'board_grid_step': (m.get('board_grid') or {}).get('resolved'),
            'board_grid_inferred': (m.get('board_grid') or {}).get('step'),
            # Occupancy belongs to the INFERENCE, so it is None on the
            # declining branch -- which is exactly the branch the defect
            # produces. Assert on `_step`; the number lives in `_reason`.
            'board_grid_occupancy': (m.get('board_grid') or {}).get(
                'occupancy'),
            'board_grid_reason': (m.get('board_grid') or {}).get('reason'),
            # #1051/#1052/#1043: the rigid groups and tethers this candidate's
            # quench held, and any member it released -- present only when
            # the intent declares that channel (`quench.disclosure`, the
            # same keys place_seed's polish reports).
            **_quench_disclosure(m)}


def _quench_disclosure(m: Dict) -> Dict:
    from placement.quench import disclosure
    return disclosure(m)


# --------------------------------------------------------------------------
# scoring, ranking, diversity
# --------------------------------------------------------------------------

def score_candidate(cand: Candidate, *, free: Sequence[str],
                    baseline_overlap: float, baseline_oob: int = 0,
                    baseline_pad_pairs: int = 0,
                    baseline_hole_shortfall: float = 0.0,
                    baseline_keepout_parts: int = 0,
                    clearance: float, board_edge_clearance: float,
                    grid_step: float, ignore_nets: Optional[Sequence[str]],
                    intent=None, group_sources: Sequence[str] = (),
                    input_violations=None) -> None:
    """Fill gates / inversions / intent / health for one quenched candidate.

    Hard gates (fail => not ranked, reason kept): legality (no MORE courtyard
    overlap and no MORE out-of-board parts than the baseline -- both measured
    against the baseline rather than zero, because a legitimate board can
    already carry both: edge connectors and castellated rows overhang the
    outline by design, and dense hand placements sit under the courtyard
    clearance) and, when an intent is given, no NEW intent error against the
    INPUT board (#1037) when `input_violations` -- `floorplan.grade(...)
    .violations` of the input, same arguments -- is given, else an error-free
    ``floorplan.grade``. Health signals are ADVISORY (they join the rank key,
    not the gate) -- routability.py states why: they say the floorplan will
    fight the router, not that it is wrong.

    What the #1037 delta CANNOT see, by `grade_delta`'s own contract: an
    error the input already carries that a candidate makes WORSE (a decap at
    3 mm moved to 9 mm is still the same one error), and an error SWAPPED for
    another of the same rule, ref, block and expected keys. Both read as no
    change. The absolute count stays in `cand.intent['errors']` beside
    `new_errors`, so a reader can still see them.
    """
    from kicad_parser import parse_kicad_pcb
    from placement.pair_order import pair_inversions

    if not cand.board:
        return
    pcb = parse_kicad_pcb(cand.board)
    ids = ignore_net_ids(pcb, ignore_nets)
    state = make_oracle(pcb, cand.board, free=free, clearance=clearance,
                        board_edge_clearance=board_edge_clearance,
                        grid_step=grid_step, ignore_ids=ids)
    inv_total = sum(m['inversions'] for m in pair_inversions(state).values())
    cand.metrics['inversions'] = inv_total

    reasons: List[str] = []
    overlap = cand.metrics.get('overlap_area', 0.0)
    if overlap > baseline_overlap + EPS:
        # The optimizer's courtyard RECTS (`metrics.overlap_area`), not
        # check_assembly's drawn-outline census -- labelled so (#1126).
        reasons.append(f"optimizer courtyard-rect overlap {overlap:.4f}mm2 "
                       f"exceeds the baseline's {baseline_overlap:.4f}mm2")
    oob = cand.metrics.get('oob_count', 0)
    if oob > baseline_oob:
        reasons.append(f"{oob} part(s) out of board vs the baseline's "
                       f"{baseline_oob}")
    # Pad+drill layer gates, same baseline-relative shape as the two above.
    pad_pairs = cand.metrics.get('pad_conflict_pairs', 0) or 0
    # run-19: a PILE seed's baseline carries hundreds of pad pairs, and "no
    # worse than the baseline" then licenses ANY smaller intersection count.
    # Above 50 the baseline is degenerate -- compare against 0, and say so.
    if baseline_pad_pairs > 50:
        if pad_pairs > 0:
            reasons.append(
                f"{pad_pairs} pad-clearance conflict pair(s) vs 0: the seed "
                f"baseline's {baseline_pad_pairs} is pile-degenerate (> 50) "
                f"and licenses nothing")
    elif pad_pairs > baseline_pad_pairs:
        reasons.append(f"{pad_pairs} pad-clearance conflict pair(s) vs the "
                       f"baseline's {baseline_pad_pairs}")
    hole_sf = cand.metrics.get('hole_shortfall', 0.0) or 0.0
    if hole_sf > baseline_hole_shortfall + EPS:
        reasons.append(f"pad-copper-in-hole-keepout {hole_sf:.4f}mm vs the "
                       f"baseline's {baseline_hole_shortfall:.4f}mm")
    # #1031: pads seated where the router's rule-area keep-out band leaves
    # no landing -- baseline-relative like every gate above.
    ko_parts = cand.metrics.get('keepout_pad_parts', 0) or 0
    if ko_parts > baseline_keepout_parts:
        reasons.append(f"{ko_parts} part(s) with pads in a rule-area keep-out "
                       f"band vs the baseline's {baseline_keepout_parts}")

    health_penalty = 0
    if intent is not None:
        from placement import floorplan
        result = floorplan.grade(intent, pcb, cand.board,
                                 group_sources=group_sources,
                                 clearance=clearance,
                                 board_edge_clearance=board_edge_clearance,
                                 with_health=True)
        errors = [v.to_dict() for v in result.errors]
        cand.intent = {'errors': len(errors), 'warnings': len(result.warnings),
                       'violations': errors[:10]}
        if input_violations is None:
            if errors:
                reasons.append(f"{len(errors)} intent violation(s): "
                               + '; '.join(v['message'] for v in errors[:3]))
        else:
            # #1037: the gate is what THIS candidate ADDS to the input board,
            # through the exit gate's own currency (floorplan.grade_delta,
            # as the seeder's no-worse test). Gating on the absolute count
            # made every candidate of a board with 11 pre-existing errors
            # inadmissible (run 32: 42-56 "violations" per candidate), and
            # the quench itself moves decaps, so even the near-identity
            # `poses` candidates were gated for the input's own errors.
            from placement import floorplan
            delta = floorplan.grade_delta(input_violations, result.violations)
            added = [d for d in delta if 'added' in d]
            new_n = sum(int(d['added']) for d in added) + (len(delta)
                                                           - len(added))
            keys = {(d['rule'], d.get('ref')) for d in added}
            new_msgs = [v['message'] for v in errors
                        if (v.get('rule'), v.get('ref')) in keys]
            cand.intent.update({
                'input_errors': sum(1 for v in input_violations
                                    if v.severity == floorplan.ERROR),
                'new_errors': new_n, 'new': delta[:10]})
            if delta:
                what = new_msgs[:3] or [
                    f"{d['rule']} {d.get('budget')} {d.get('before')} -> "
                    f"{d.get('after')}" if 'budget' in d else
                    f"{d['rule']} {d.get('ref') or ''}".strip()
                    for d in delta[:3]]
                reasons.append(f"{new_n} NEW intent error(s) vs the input "
                               f"board: " + '; '.join(what))
        h = result.health or {}
        rows = h.get('bus_corridors') or []
        # `intrusions` in the row is TRUNCATED for display (routability.health
        # keeps the five deepest). Summing len() of it silently saturated the
        # intrusion component at 5 per corridor, so a channel with twelve parts
        # parked in it scored the same as one with five. Read the untruncated
        # count; fall back to the list for health JSON written before it.
        intrusions = sum(int(r['intrusions_total']) if 'intrusions_total' in r
                         else len(r.get('intrusions') or ())
                         for r in rows)
        health_penalty = (int(h.get('bus_foreign_crossings') or 0)
                          + intrusions + int(h.get('blocks_displaced') or 0))
        cand.health = {
            'bus_foreign_crossings': h.get('bus_foreign_crossings'),
            'intrusions': intrusions,
            'blocks_displaced': h.get('blocks_displaced'),
            'block_displacement_max_mm': h.get('block_displacement_max_mm'),
            'penalty': health_penalty}
    cand.metrics['health_penalty'] = health_penalty
    cand.gates = {'passed': not reasons, 'reasons': reasons}


class RankKey(NamedTuple):
    """The static order, as a NamedTuple so the slots have names.

    It IS a tuple, so every ``rank_key(a) < rank_key(b)`` comparison and every
    positional index keeps working; the names exist so a future reorder fails
    loudly in tests that mean a specific term instead of passing by accident.
    """
    crossings_band: int
    health_banded: int
    inversions: int
    plane_islands: int
    hpwl: float
    plane_neck: int
    health_legacy: int
    displacement: float
    index: int


def rank_key(cand: Candidate, q: int = 0) -> RankKey:
    """The static order: lexicographic over numbers the repo already trusts,
    most significant first, no new magic weights.

      crossings      the first-class pre-route judge (raw count).
                     UNRESOLVED, AND DISCLOSED: this slot ranks on crossings
                     while the retired placement skill's non-negotiable 4
                     and evidence-map.md said to report crossings and NEVER
                     gate on it. Both cannot be right. The evidence behind
                     non-negotiable 4 is r = +0.780 against DISTANCE-TO-TRUTH,
                     which is not a routability measurement; the evidence for
                     this slot is that crossings is near-injective over a real
                     slate, so it decides. #703 measured the missing half:
                     within a board, rho(crossings, blocking) FAILS its sign
                     rule -- 5 boards right, 1 wrong, median rho = +0.515 over
                     six boards (docs/placement-predictors.md) -- and PASSES it
                     once the quench-produced candidates are excluded, i.e. the
                     answer depends on whether the sample contains placements
                     made by an optimizer that minimises crossings.
                     #789 then asked the question this slot is actually about:
                     does the ORDER agree with the routed order over the same
                     candidates? Kendall tau-b on a six-board slate came back
                     positive on 2 boards and negative on 3 (N=5, p = 1.000),
                     which pre-registered rule 5 calls NOT SHOWN TO AGREE and
                     which licenses nothing in either direction. So THE ORDER IS
                     UNCHANGED and the contradiction stays disclosed. Note this
                     is the ORDER: rule1_check's crossings BAR was a separate
                     question and #789 withdrew it.
                     (An earlier version of this note said "3 boards right, 1
                     wrong" -- the four-board era's figure, carried forward
                     unchanged when the study grew to six.)
      inversions     the forced-crossing floor -- equal-crossings ties break
                     toward the more REMOVABLE set (pair_order is a lower
                     bound a router cannot beat)
      plane_islands  --plane-score only (0 otherwise): how many pieces the
                     poured plane lands in. Before hpwl deliberately -- a
                     split pour is a MEASURED plane-step loss the repair
                     step must stitch, and hpwl is a proxy (#118: "routing
                     is as much about planes as traces")
      hpwl           order-invariant geometry
      plane_neck     --plane-score only: the #424 fragility field summed
                     over the fill (mm-equivalents, whole-mm rounded) --
                     a neck tiebreak below hpwl
      health         advisory floorplan-fight signals (0 without an intent)
      displacement   least disturbance wins what is left
      index          stability

    ``q`` is the crossings BAND width, and it is what lets the advisory health
    signal ever speak. Measured: crossings is near-injective over a real slate,
    so slot 1 decides and nothing below it runs -- health at slot 6 never
    spoke, and health at slot 2 would speak just as rarely. Banding the first
    slot is the lever, not reordering it.

      q = 0 (default)  legacy order, bit-identical: health stays in its old
                       slot 6 and crossings are compared raw.
      q >= 1           crossings quantised to ceil(c/q) and health promoted to
                       slot 2, so inside one band the term that says "this
                       floorplan will FIGHT the router" decides. inversions,
                       plane_* and hpwl are all the same family as crossings
                       ("how hard is this to route"); health is the only one
                       that is about the floorplan fighting back.

    Quantisation, never a tolerance compare: ``abs(a-b) <= tol`` is not
    transitive, and ``sorted()`` on a non-transitive key is undefined. Integer
    ceil-div is a function into a totally ordered set, so it is well defined.
    """
    m = cand.metrics
    crossings = m.get('crossings', 1 << 30)
    health = m.get('health_penalty', 0)
    banded = q >= 1
    return RankKey(
        crossings_band=-(-crossings // q) if banded else crossings,
        health_banded=health if banded else 0,
        inversions=m.get('inversions', 1 << 30),
        plane_islands=m.get('plane_islands', 0),
        hpwl=round(m.get('hpwl', float('inf')), 3),
        plane_neck=round(m.get('plane_neck', 0.0)),
        health_legacy=0 if banded else health,
        displacement=round(cand.displacement_rms, 2),
        index=cand.index)


def band_width(cands: Sequence[Candidate], band_frac: float,
               baseline_crossings: Optional[int] = None) -> int:
    """The band width q for `band_frac`, or 0 when banding is off/inert.

    Two ways to end up at 0, both deliberate:
      * band_frac <= 0 -- the default, legacy order.
      * every ranked candidate scores health_penalty 0 (no --intent, or an
        intent with no health block). Banding then coarsens the strongest
        signal to buy nothing, so it is refused rather than applied blind.
    """
    if band_frac <= 0:
        return 0
    viable = [c for c in cands if c.viable]
    if not any(c.metrics.get('health_penalty', 0) for c in viable):
        return 0
    if baseline_crossings is None:
        baseline_crossings = min((c.metrics.get('crossings', 0)
                                  for c in viable), default=0)
    return max(1, round(band_frac * baseline_crossings))


def rank_static(cands: Sequence[Candidate], q: int = 0) -> List[int]:
    """Indices of the gate-passing candidates, best first."""
    return [c.index for c in sorted((c for c in cands if c.viable),
                                    key=lambda c: rank_key(c, q))]


def rule1_check(cand: Candidate, baseline: Candidate) -> List[str]:
    """Rule 1 of the Step-0c acceptance conjunction, applied K-way (run-7
    S6): **hpwl** must be NO WORSE than the baseline row.

    HPWL ALONE. This sentence said "crossings and hpwl" while the code has
    checked only hpwl since #789 withdrew the crossings clause -- so the
    operative sentence of the rule stated a rule the function does not apply,
    and a reader who acts on the first sentence is wrong while believing they
    followed it. That is the defect family #936 catalogued, in the docstring
    of the acceptance rule itself. The withdrawal is explained three
    paragraphs down; it now also appears where the rule is defined (#937).

    The hard gates in score_candidate are legality + intent (rule 2). This
    metric clause was DOCUMENTED as pre-applied but never was, so a
    candidate measuring worse on both proxies could top the slate and ship
    through JSON_SUMMARY['best'] unremarked.

    THE CROSSINGS CLAUSE IS WITHDRAWN (#789). It used to bar a candidate on
    crossings while the drivers forbid gating on it (see `rank_key`), and
    `docs/placement-predictors.md` pre-registered the exit criterion in rule 2:
    if a run finds >= 1 board where a rule-1 violator routed to strictly LOWER
    `blocking` than the baseline, the clause is withdrawn. A six-board slate run
    found it on TWO -- esp_prog and kit-dev-coldfire -- so it is gone, and the
    measured direction survives in `rule1_advisory` rather than being deleted.

    WHAT THE WITHDRAWAL CHANGED, measured on the same six boards: NOTHING on
    the static order, on all six. That is structural -- `rank_key`'s slot 1 IS
    crossings, so a candidate barred for having MORE crossings than the
    baseline already sorts below every candidate with fewer, and `select_best`
    reaches a non-violator first.

    AND THE LIMIT OF THAT, because the first version of this docstring
    overstated it. The other arm ranked a probe by each candidate's TRUE routed
    `blocking`, and there the withdrawal reaches a candidate at `blocking` 2
    where the bar forced a fall-through to 3 -- but that arm CANNOT show harm:
    the new violator set is a subset of the old, and the list is sorted by the
    truth, so the pick can only move earlier. Under a probe that MIS-ranks it
    can be worse -- esp_prog's candidate 3 is crossings-barred and routes to
    `blocking` 6. So the honest statement is: no change on the static order,
    help only under a perfect probe, harm possible under a bad one. The record
    is `tests/placement_rule1_withdrawal.json` and its change detector is
    `tests/test_789_rule1_withdrawal.py`.

    HOW MUCH THAT DISCHARGE IS WORTH, stated because rule 2 pre-registered the
    question: the criterion's own null rate -- permuting `blocking` within a
    board -- is 100% on esp_prog and 99% on kit-dev, because almost every
    candidate on those slates routed below their baseline, so ANY permutation
    fires. The criterion was weak, it was pre-registered as expected-weak, and
    the withdrawal rests on the measured consequence above rather than on the
    criterion alone.

    `rank_key` slot 1 is NOT touched. Rule 2 was about the BAR; the ORDER is
    rule 5, and the same run left it NOT SHOWN TO AGREE (tau positive on 2
    boards, negative on 3, N=5), which licenses nothing. That contradiction
    stays disclosed.

    Pure: returns the violation strings; empty means it passes. Violators are
    still ranked, probed and recorded -- they are only barred from being the
    silent headline pick (select_best); a probe verdict that argues for one
    anyway is a decision the operator makes deliberately, reading
    portfolio.json.
    """
    out: List[str] = []
    bm, cm = baseline.metrics, cand.metrics
    bh, ch = bm.get('hpwl'), cm.get('hpwl')
    if bh is not None and ch is not None and ch > bh + EPS:
        out.append(f'hpwl {ch:.1f} > baseline {bh:.1f}')
    return out


def rule1_advisory(cand: Candidate, baseline: Candidate) -> List[str]:
    """The WITHDRAWN crossings clause -- still measured, no longer barring.

    Rule 2 said the withdrawal keeps its row WITH ITS MEASURED DIRECTION. A
    clause that stops measuring is a deleted clause, and a later reader would
    have no way to see what the bar used to say or to notice if the corpus
    changed under it. So the comparison still runs and still reports; it simply
    decides nothing, which is the standing `crossings` already has in the
    drivers under non-negotiable 4.

    Deliberately a SECOND function rather than a richer return type from
    `rule1_check`: that would break `tests/test_portfolio_rule1.py`'s contract,
    every `c.gates['rule1']` consumer and `portfolio.json`'s shape, for no
    gain -- `select_best`'s only input is the violator SET.
    """
    out: List[str] = []
    bx = baseline.metrics.get('crossings')
    cx = cand.metrics.get('crossings')
    if bx is not None and cx is not None and cx > bx:
        out.append(f'crossings {cx} > baseline {bx} '
                   f'(WITHDRAWN #789: reported, does not bar)')
    return out


def select_best(ranking_primary: Sequence[int], ranking_static: Sequence[int],
                rule1_violators: Set[int]) -> Optional[int]:
    """The slate's headline pick: the first ranked index that passes rule 1.

    `ranking_primary` (a probe ranking -- full-board when --full-probe ran,
    else the shared-window one) outranks the static ranking. The baseline
    (index 0) trivially passes rule 1 against itself, so "keep what you
    have" stays a first-class outcome. Returns None when nothing ranked
    passes -- the caller falls back to the baseline, never to a violator.
    """
    # NOT `+ [0]`. The baseline is genuinely absent from both lists when its
    # own probe produced no verdict -- `ranking_static` is built from `cands`,
    # which excludes index 0 -- and appending it here looks like the fix. It is
    # not: returning 0 directly SUPPRESSES the caller's
    # "every ranked candidate violates rule 1" note, which is the disclosure a
    # reader needs before adopting anything. `None` -> the caller falls back to
    # the baseline AND says why, which is the behaviour that must survive.
    # tests/test_portfolio_rule1.py caught this; the real fix for #713 item 2
    # is that a probe verdict is no longer erased by a clock in the first
    # place, plus the explicit NO VERDICT warning place_portfolio now prints.
    seen = set()
    for idx in list(ranking_primary) + list(ranking_static):
        if idx in seen:
            continue
        seen.add(idx)
        if idx == 0 or idx not in rule1_violators:
            return idx
    return None


def select_diverse(cands: Sequence[Candidate], order: Sequence[int],
                   keep: int, min_dist_mm: float,
                   free: Sequence[str],
                   baseline: Optional[Candidate]) -> Tuple[List[int], List[int]]:
    """Walk the ranked order, keeping a candidate only when it sits at least
    `min_dist_mm` (pose distance) from everything already kept -- the baseline
    included, so a candidate that quenched back into the incumbent's basin is
    recognized as "no new option" rather than presented twice. When fewer than
    `keep` survive, backfill by rank and SAY so (second return value): a slate
    padded with near-clones must not read as a diverse one.
    """
    by_index = {c.index: c for c in cands}
    kept: List[int] = []
    kept_poses = [baseline.final_poses] if baseline is not None else []
    for idx in order:
        if len(kept) >= keep:
            break
        c = by_index[idx]
        if all(pose_distance_mm(c.final_poses, p, free) >= min_dist_mm
               for p in kept_poses):
            kept.append(idx)
            kept_poses.append(c.final_poses)
    backfilled: List[int] = []
    if len(kept) < keep:
        for idx in order:
            if len(kept) >= keep:
                break
            if idx not in kept:
                kept.append(idx)
                backfilled.append(idx)
    return kept, backfilled
