"""Run the authorized atomic builtin update and installed-main checks once."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

MAIN = Path('/home/halbritt/git/kicad-route')
Q = MAIN / 'build/agent497-upstream-adoption'
SOURCE = '89a2efbf53057a0694b3cef365ec3acdc01b61f5f57d86bfbe8a62dc8f11db6d'
PINS = ['numpy==2.5.4', 'pillow==13.0.0', 'scipy==1.18.1', 'shapely==2.2.0']


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*argv):
    return subprocess.check_output(['git', *argv], cwd=MAIN, text=True).strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-main', required=True)
    parser.add_argument('--qualification-receipt', type=Path, required=True)
    args = parser.parse_args()
    proof = json.loads(args.qualification_receipt.read_text())
    assert proof['status'] == 'PASS', proof.get('status')
    assert proof['schema'] == 'kicad-route/independent-archon-test-verification/1'
    assert proof['source_sha256'] == SOURCE and proof['expected_node_count'] == 816
    assert proof['helper_sha256'] == 'ea7139f64062674af6cd4280a35ebdbaedffa2d24bf0619b4320133878be1146'
    assert all(proof['smoke']['junit_aggregate'][key] == 0 for key in ('failures', 'errors', 'skipped'))
    assert git('rev-parse', 'HEAD') == args.expected_main == git('rev-parse', 'origin/main')
    assert git('branch', '--show-current') == 'main'
    assert not git('status', '--porcelain'), 'main must be committed, pushed and clean'
    bridge = json.loads((Q / 'qualification-source-bridge.json').read_text())
    assert proof['source_commit'] == bridge['qualification_head']
    assert git('rev-parse', 'HEAD:src') == bridge['shipping_source_tree']
    dest = Q / 'deployment'
    assert not dest.exists(), 'refusing to reuse a deployment evidence directory'
    dest.mkdir()

    def write(name, obj):
        (dest / name).write_text(json.dumps(obj, indent=2) + '\n')

    previous = json.loads((MAIN / 'manifest.json').read_text())
    assert previous['krt']['source_sha256'].startswith('c6c09054f684')
    assert sorted(previous['krt']['venv']['packages']) == sorted(PINS)
    shutil.copy2(MAIN / 'manifest.json', dest / 'previous-manifest.json')
    constraints = dest / 'constraints.txt'
    constraints.write_text('\n'.join(PINS) + '\n')
    os.environ.update(KICAD_ROUTE_STATE=str(MAIN), KICAD_ROUTE_OUT=str(dest / 'install'),
                      KICAD_ROUTE_KRT_PYTHON='/usr/bin/python3.12',
                      UV_CONSTRAINT=str(constraints), UV_OFFLINE='1', CARGO_NET_OFFLINE='true',
                      PYTHONDONTWRITEBYTECODE='1', KICAD_ROUTE_LEDGER='off')
    sys.path.insert(0, str(MAIN / 'src'))
    from kicad_route import cli, common, engine, statemanifest
    assert engine.source_sha256(engine.SOURCE_ROOT) == SOURCE
    original_generation = common.router_generation()
    initial = {'status': 'RUNNING', 'started_utc': now(), 'main_commit': args.expected_main,
               'engine_source_sha256': SOURCE, 'previous_generation': str(original_generation),
               'qualification_receipt': str(args.qualification_receipt),
               'qualification_receipt_sha256': sha(args.qualification_receipt),
               'shipping_source_tree': bridge['shipping_source_tree']}
    write('execution.json', initial)
    steps = []
    phases = []
    try:
        cli.update_krt(steps)
        manifest = statemanifest.read(MAIN)
        active = common.router_generation()
        assert active != original_generation and active == engine.GENERATION
        assert engine.source_sha256(active / 'router') == SOURCE == manifest['krt']['source_sha256']
        assert sorted(manifest['krt']['venv']['packages']) == sorted(PINS)
        assert not statemanifest.verify(manifest, MAIN)
        shutil.copy2(MAIN / 'manifest.json', dest / 'installed-manifest-before-checks.json')
        write('installation.json', {**initial, 'status': 'PASS', 'generation': str(active),
              'steps': steps, 'manifest_sha256': sha(MAIN / 'manifest.json'), 'drift': []})
        commands = [
            ('doctor', ['/usr/bin/python3', str(MAIN / 'bin/kicad-route'), '--out',
                        str(dest / 'doctor'), 'doctor', '--offline']),
            ('determinism', ['/usr/bin/python3', str(MAIN / 'bin/kicad-route'), '--out',
                             str(dest / 'repeat'), 'determinism', '--backend', 'builtin',
                             '--runs', '2', '--budget', '180', '--default-clearance', '0.4', '--record']),
        ]
        for name, argv in commands:
            phase = {'name': name, 'argv': argv, 'started_utc': now(), 'status': 'RUNNING'}
            phases.append(phase)
            write('phases.json', phases)
            with (dest / (name + '.log')).open('w') as output:
                result = subprocess.run(argv, cwd=MAIN, env=os.environ, stdout=output, stderr=subprocess.STDOUT)
            phase.update(exit_code=result.returncode, finished_utc=now(),
                         status='PASS' if result.returncode == 0 else 'FAIL')
            write('phases.json', phases)
            print(json.dumps(phase), flush=True)
            assert result.returncode == 0, phase
        assert common.router_generation() == active
        assert not statemanifest.verify(statemanifest.read(MAIN), MAIN)
        assert git('rev-parse', 'HEAD') == args.expected_main
        assert not git('status', '--porcelain')
        shutil.copy2(MAIN / 'manifest.json', dest / 'installed-manifest.json')
        write('execution.json', {**initial, 'status': 'PASS', 'finished_utc': now(),
              'generation': str(active), 'phases': phases, 'steps': steps,
              'manifest_sha256': sha(MAIN / 'manifest.json'), 'drift': []})
    except BaseException as error:
        write('execution.json', {**initial, 'status': 'FAIL', 'finished_utc': now(),
              'steps': steps, 'phases': phases, 'error': repr(error)})
        raise


if __name__ == '__main__':
    main()
