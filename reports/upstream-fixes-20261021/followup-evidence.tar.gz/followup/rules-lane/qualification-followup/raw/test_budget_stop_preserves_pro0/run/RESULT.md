# Routing attempt: builtin on route_demo

- Backend: builtin 0.23.1 (owned-89a2efbf5305)
- Input: `route_demo.kicad_pcb` from working tree @ 4fb4fa14a968cf08127cc849d81eb0f9c20a1b05 (fingerprint ba2f343c49e2f971)
- Scope: all, 6 nets; protect: existing; budget 3 s
- Candidate: none

| Result | Status | Detail |
|---|---|---|
| process | FAIL | exit -9, 5.001 s; KRT exceeded the 3 s budget, did not stop at the stop file, and was killed (last output: 'controlled budget worker ready'); retry with a larger --budget; KRT checks the stop file only between nets of its main pass, and --backend-env KICAD_NET_RESCUE=0 / KICAD_PLANE_FINALIZE=0 switch off its longest later passes |
| routing | NOT_RUN | - unconnected in scope, - total (input: -) |
| validation | NOT_RUN | backend produced no candidate |

Unsupported or approximated by this backend:

- KRT reads only a subset of .kicad_dru custom rules; every rule is still graded by KiCad DRC
- KRT's cleanup may neck wide new segments near foreign pads without a flag; the new_copper_netclass_geometry check reports any new copper below its net class

