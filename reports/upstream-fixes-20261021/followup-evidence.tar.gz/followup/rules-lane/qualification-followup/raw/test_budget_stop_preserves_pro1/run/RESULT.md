# Routing attempt: builtin on route_demo

- Backend: builtin 0.23.1 (owned-89a2efbf5305)
- Input: `route_demo.kicad_pcb` from working tree @ 4fb4fa14a968cf08127cc849d81eb0f9c20a1b05 (fingerprint ba2f343c49e2f971)
- Scope: all, 6 nets; protect: existing; budget 3 s
- Candidate: `/tmp/pytest-of-halbritt/pytest-1525/test_budget_stop_preserves_pro1/run/candidate/route_demo/route_demo.kicad_pcb`

| Result | Status | Detail |
|---|---|---|
| process | PASS | exit 0, 5.592 s; budget reached: KRT stopped early and wrote the board as it stood |
| routing | INCOMPLETE | 6 unconnected in scope, 6 total (input: 6) |
| validation | PASS | no new findings |

| Preservation check | Status |
|---|---|
| project_files | PASS |
| board_outline | PASS |
| layers | PASS |
| stackup | PASS |
| board_setup | PASS |
| nets_and_netclasses | PASS |
| pad_connectivity | PASS |
| footprints | PASS |
| zones | PASS |
| keepouts | PASS |
| copper_graphics | PASS |
| protected_copper | PASS |
| new_copper_netclass_geometry | PASS |
| routing_scope | PASS |
| net_completion | PASS |
| pour_integrity | PASS |

Native DRC (original rules and severities):

```json
{
 "violations_total": 0,
 "parity_total": 0,
 "new_violations": {
  "count": 0,
  "by_type": {},
  "by_severity": {}
 },
 "preexisting_violations": 0,
 "resolved_violations": 0,
 "new_parity": {
  "count": 0,
  "by_type": {},
  "by_severity": {}
 },
 "resolved_parity": 0
}
```

Unsupported or approximated by this backend:

- KRT reads only a subset of .kicad_dru custom rules; every rule is still graded by KiCad DRC
- KRT's cleanup may neck wide new segments near foreign pads without a flag; the new_copper_netclass_geometry check reports any new copper below its net class

Blocked by (heuristic straight/L corridors, not a proof; details `/tmp/pytest-of-halbritt/pytest-1525/test_budget_stop_preserves_pro1/run/validate/blocked-by.json`):

| Blocker | Category | Blocks (best layer) | Blocks (any layer) |
|---|---|---|---|
| keepout 'route_keepout' (no tracks, no vias, no zone fills) on B.Cu, F.Cu | keepout | 2 | 3 |

- `/SIG_A`: 1 open; best layer F.Cu with 1 hard blockers (keepout 'route_keepout')
- `/SIG_A_OUT`: 1 open; best layer F.Cu with 1 hard blockers (keepout 'route_keepout')
- `/SIG_B_OUT`: 1 open; best layer F.Cu with 0 hard blockers
- `/VIN`: 2 open; best layer F.Cu with 0 hard blockers
- `GND`: 1 open; best layer F.Cu with 0 hard blockers
- 4 connection(s) have an unobstructed corridor: the obstacle is elsewhere (congestion, detours, the backend's search or budget)

Route statistics:

```json
{
 "new_tracks": 0,
 "new_vias": 0,
 "new_track_length_mm": 0,
 "new_track_length_mm_by_layer": {},
 "new_copper_nets": 0,
 "removed_existing_tracks": 0,
 "removed_existing_vias": 0
}
```
