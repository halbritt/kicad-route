
import os
from pathlib import Path
import shutil
import signal
import sys
import time

cooperative = True
Path(__file__).with_suffix(".pid").write_text(str(os.getpid()))
print("controlled budget worker ready", flush=True)
if not cooperative:
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    while True:
        time.sleep(0.01)
while not Path(os.environ["KICAD_STOP_FILE"]).exists():
    time.sleep(0.01)
shutil.copy2(sys.argv[1], sys.argv[sys.argv.index("--output") + 1])
print("saved unchanged input checkpoint after STOP", flush=True)
