import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('independent_test_verifier',HERE/'verify-archon-tests.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
ROOT=Path('/home/halbritt/.cache/agent-worktrees/kicad-route/agent497-upstream-primary')


class PopulationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=HERE)
        self.addCleanup(self.temp.cleanup)
        self.xml=Path(self.temp.name)/'junit.xml'
        self.nodes=['tests/test_example.py::test_plain[x::y]',
                    'tests/test_owned_parser_contracts.py::LegacyTokenTests::test_dialects']
        self.events=[{'parent':self.nodes[1],'parameters':{'dialect':n}} for n in (9,10)]

    def write(self,extra=False):
        root=ET.Element('testsuites');suite=ET.SubElement(root,'testsuite',tests='4',failures='0',errors='0',skipped='0')
        ET.SubElement(suite,'testcase',classname='test_example',name='test_plain[x::y]')
        ET.SubElement(suite,'testcase',classname='tests.test_owned_parser_contracts.LegacyTokenTests',name='test_dialects')
        if extra:
            for n in (9,10):
                ET.SubElement(suite,'testcase',classname='tests.test_owned_parser_contracts.LegacyTokenTests',name=f'test_dialects (dialect={n})')
        ET.ElementTree(root).write(self.xml)
        return root,suite

    def check(self):return v.verify_junit(self.xml,self.nodes,self.events)

    def test_successful_subtest_events_without_rows(self):
        self.write();r=self.check()
        self.assertEqual((r['base_nodes'],r['testcase_rows'],r['derived_subtest_events']),(2,2,2))

    def test_explicit_derived_subtest_rows(self):
        self.write(True);self.assertEqual(self.check()['rendered_subtest_rows'],2)

    def test_duplicate_base_cannot_masquerade_as_subtest(self):
        tree,suite=self.write();suite.append(copy.deepcopy(list(suite)[-1]));ET.ElementTree(tree).write(self.xml)
        with self.assertRaisesRegex(RuntimeError,'duplicate JUnit base'):self.check()

    def test_missing_base_refused_even_when_aggregate_correct(self):
        tree,suite=self.write();suite.remove(list(suite)[0]);ET.ElementTree(tree).write(self.xml)
        with self.assertRaisesRegex(RuntimeError,'omitted'):self.check()

    def test_skip_refused(self):
        tree,suite=self.write();ET.SubElement(list(suite)[0],'skipped');ET.ElementTree(tree).write(self.xml)
        with self.assertRaisesRegex(RuntimeError,'failure/error/skip'):self.check()

    def test_aggregate_must_include_exact_events(self):
        tree,suite=self.write();suite.set('tests','5');ET.ElementTree(tree).write(self.xml)
        with self.assertRaisesRegex(RuntimeError,'aggregate differs'):self.check()

    def test_partial_explicit_events_refused(self):
        tree,suite=self.write(True);suite.remove(list(suite)[-1]);ET.ElementTree(tree).write(self.xml)
        with self.assertRaisesRegex(RuntimeError,'partial explicit'):self.check()

    def test_unknown_explicit_event_refused(self):
        tree,suite=self.write(True);list(suite)[-1].set('name','test_dialects (dialect=11)');ET.ElementTree(tree).write(self.xml)
        with self.assertRaisesRegex(RuntimeError,'unmapped'):self.check()

    def test_actual_pytest91_parser_junit_thirteen_bases_six_events(self):
        path=HERE/'parser-lane/tests/agent497-parser-final.xml'
        xml=ET.parse(path)
        nodes=[]
        for case in xml.iter('testcase'):
            klass=case.get('classname').split('.')[-1]
            nodes.append('tests/test_owned_parser_contracts.py::'+klass+'::'+case.get('name'))
        events=v.derived_subtests(ROOT/'src/kicad_route/router/tests/test_parser_legacy_tokens.py',set(nodes))
        r=v.verify_junit(path,nodes,events)
        self.assertEqual((r['base_nodes'],r['derived_subtest_events'],r['aggregate']['tests'],r['testcase_rows']),(13,6,19,13))

    def test_actual_failed_fullsuite_refused(self):
        q=HERE/'archon-tests'
        path=next((q/'full-smoke/smoke').glob('*/junit.xml'))
        nodes=json.loads((q/'collection-nodes.json').read_text())
        events=v.derived_subtests(ROOT/'src/kicad_route/router/tests/test_parser_legacy_tokens.py',set(nodes))
        with self.assertRaisesRegex(RuntimeError,'failure/error/skip'):v.verify_junit(path,nodes,events)


class IdentityTests(unittest.TestCase):
    def setUp(self):
        q=HERE/'archon-tests'
        self.ready=json.loads((q/'test-readiness.json').read_text())
        self.before=json.loads((q/'test-installed-manifest-before.json').read_text())
        self.result=json.loads(next((q/'repeat').rglob('result.json')).read_text())

    def test_actual_repeat_identity_and_strict_command(self):
        v.require_repeat_identity(self.result,self.ready,self.before)
        flags=v.constants(ROOT/'src/kicad_route/cli.py')
        self.assertEqual(v.check_backend_command(self.result,self.ready,flags)['strict_environment']['KICAD_FINALIZE_RIP'],'0')

    def test_two_equal_but_wrong_backend_identities_refused(self):
        self.result['backend']['execution_identity']['extension_module_sha256']='0'*64
        self.result['tool_identity']['backend']['extension_module_sha256']='0'*64
        with self.assertRaisesRegex(RuntimeError,'content identity'):v.require_repeat_identity(self.result,self.ready,self.before)

    def test_other_active_generation_refused(self):
        self.result['backend']['runtime']['generation']='/testwork/state-candidate/.router-generations/other'
        with self.assertRaisesRegex(RuntimeError,'different source/generation'):v.require_repeat_identity(self.result,self.ready,self.before)

    def test_stop_safety_flag_missing_refused(self):
        flags=v.constants(ROOT/'src/kicad_route/cli.py')
        command=next(row for row in self.result['process']['commands'] if '--no-stub-layer-swap' in row.get('argv',[]))
        command['argv'].remove('--no-stub-layer-swap')
        with self.assertRaisesRegex(RuntimeError,'strict worker flag'):v.check_backend_command(self.result,self.ready,flags)

    def test_disabled_escalation_environment_mutation_refused(self):
        flags=v.constants(ROOT/'src/kicad_route/cli.py')
        command=next(row for row in self.result['process']['commands'] if '--no-stub-layer-swap' in row.get('argv',[]))
        command['env']['KICAD_TERMINAL_ESCALATION']='1'
        with self.assertRaisesRegex(RuntimeError,'environment changed'):v.check_backend_command(self.result,self.ready,flags)

    def test_actual_persisted_record_excludes_only_postwrite_recorded_in(self):
        q=HERE/'archon-tests'
        record=json.loads(next((q/'repeat/determinism').glob('*/determinism.json')).read_text())
        after=json.loads((q/'test-installed-manifest-after.json').read_text())
        self.assertEqual(after['determinism']['krt'],{key:value for key,value in record.items() if key!='recorded_in'})


if __name__=='__main__':unittest.main()
