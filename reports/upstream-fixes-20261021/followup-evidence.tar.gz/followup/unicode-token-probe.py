"""Native UTF-8 pad/net round trips for the frozen legacy-token repair."""
from pathlib import Path
import hashlib,json,sys
source=Path(sys.argv[1]);out=Path(__file__).resolve().parent/'unicode-token-probe';out.mkdir(exist_ok=True)
sys.path.insert(0,str(source/'src/kicad_route/router/py_router'))
import kicad_parser as parser
import kicad_writer as writer
import pcbnew
names=['温度Ω','питаниеµ']
rows=[]
for dialect,back,silk in [(9,31,37),(10,2,5)]:
 version=20241229 if dialect==9 else 20260206
 table='(net 0 "") (net 1 温度Ω) (net 2 питаниеµ)' if dialect==9 else ''
 nets=['1 温度Ω','2 питаниеµ'] if dialect==9 else names
 text=f'''(kicad_pcb (version {version}) (generator "pcbnew")
 (general (thickness 1.6)) (paper "A4")
 (layers (0 "F.Cu" signal) ({back} "B.Cu" signal) ({silk} "F.SilkS" user))
 (setup (pad_to_mask_clearance 0)) {table}
 (footprint "test:bare" (layer "F.Cu") (at 10 20)
  (fp_text reference "J1" (at 0 -2) (layer "F.SilkS")
   (effects (font (size 1 1) (thickness 0.15))))
  (pad 1 smd rect (at 0 0) (size 1 2) (layers "F.Cu") (net {nets[0]}))
  (pad 2 smd rect (at 3 0) (size 1 2) (layers "F.Cu") (net {nets[1]}))))'''
 path=out/f'input-{dialect}.kicad_pcb';path.write_text(text,encoding='utf-8')
 parsed=parser.parse_kicad_pcb(path);pads=parsed.footprints['J1'].pads
 assert [p.net_name for p in pads]==names
 native=pcbnew.LoadBoard(str(path));assert native is not None
 actual=sorted((p.GetNumber(),p.GetNetname())for fp in native.GetFootprints()for p in fp.Pads())
 assert actual==list(zip(['1','2'],names)),actual
 changed=writer.swap_pad_nets_in_content(text,*pads)
 target=out/f'swapped-{dialect}.kicad_pcb';target.write_text(changed,encoding='utf-8')
 assert [p.net_name for p in parser.parse_kicad_pcb(target).footprints['J1'].pads]==names[::-1]
 native=pcbnew.LoadBoard(str(target));assert native is not None
 actual=sorted((p.GetNumber(),p.GetNetname())for fp in native.GetFootprints()for p in fp.Pads())
 assert actual==list(zip(['1','2'],names[::-1])),actual
 rows.append({'dialect':dialect,'status':'PASS','native_swapped_names':actual,'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
receipt={'status':'PASS','source':str(source),'parser_sha256':hashlib.sha256(Path(parser.__file__).read_bytes()).hexdigest(),'writer_sha256':hashlib.sha256(Path(writer.__file__).read_bytes()).hexdigest(),'cases':rows,'scope':'Bare UTF-8 pad-net parse and swap matched native pcbnew for both dialects; no routing/DRC claim.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n');print(json.dumps(receipt,ensure_ascii=False))
