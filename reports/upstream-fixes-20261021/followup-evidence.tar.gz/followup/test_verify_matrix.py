"""Bounded pure-data guards for the post-terminal verifier; no native jobs."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('verify_matrix',HERE/'verify-matrix.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
CAN=[{'p':'/CAN+','n':'/CAN-','routed':True,'status':'ROUTED'}]


def result():
    return {'schema':'kicad-route/route/2','process':{'status':'PASS','commands':[{'stalled':False}]},
            'routing':{'status':'COMPLETE','unconnected_total':0,'unrouted_nets':[]},
            'validation':{'status':'PASS','preservation':{'original_rules':'PASS'},'drc':{'new_violations':{'count':0}}},
            'input':{'fingerprint':'input'},'evidence':{'candidate_copper_signature':{'sha256':'copper'}},'pairs':copy.deepcopy(CAN)}


def store(root,files):
    rows=[]
    for index,(original,data) in enumerate(files.items()):
        relative=f'file-{index}.json';path=root/relative;path.write_text(json.dumps(data))
        rows.append({'source':original,'retained':relative,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    path=root/'index.json';path.write_text(json.dumps({'host':'archon','files':rows}))
    return v.EvidenceStore(path,hashlib.sha256(path.read_bytes()).hexdigest())


class VerifierTests(unittest.TestCase):
    def test_independent_median_sorts_five_and_preserves_exact_boundary(self):
        before=[{key:value for key in v.METRICS} for value in [50,10,40,20,30]]
        after=[{key:value for key in v.METRICS} for value in [55,11,44,22,33]]
        metrics=v.median_metrics(before,after)
        for item in metrics.values():
            self.assertEqual(item,{'reference_median':30,'candidate_median':33,'ratio':1.1,'limit':1.1})
        for invalid in (True,float('nan'),0):
            broken=copy.deepcopy(after);broken[0]['wall_s']=invalid
            with self.subTest(invalid=invalid),self.assertRaises(RuntimeError):v.median_metrics(before,broken)
        with self.assertRaises(RuntimeError):v.median_metrics(before[:-1],after)

    def test_joint_missing_pairs_cannot_be_hidden_by_matching_summaries(self):
        raw=result();raw['pairs']=[]
        quality=v.quality_from_result(raw)
        with self.assertRaisesRegex(RuntimeError,'pair population'):v.verify_quality(quality,CAN)
        v.verify_quality(v.quality_from_result(result()),CAN)

    def test_duplicate_or_reversed_oriented_pairs_refused(self):
        for pairs in (CAN+CAN,[dict(CAN[0],p='/CAN-',n='/CAN+')]):
            raw=result();raw['pairs']=pairs
            with self.subTest(pairs=pairs),self.assertRaises(RuntimeError):v.verify_quality(v.quality_from_result(raw),CAN)

    def test_native_pass_does_not_override_actual_stall_flag(self):
        raw=result();raw['process']['commands'][0]['stalled']=True
        quality=v.quality_from_result(raw)
        self.assertTrue(quality['wall_clock_stop'])
        with self.assertRaisesRegex(RuntimeError,'censored'):v.verify_quality(quality,CAN)

    def test_time_summary_must_equal_actual_indexed_GNU_output(self):
        timing={'wall_s':12.3,'user_s':8.0,'system_s':1.0,'max_rss_kib':2000}
        sample={**timing,'result':'/evidence/board/reference-1/run/result.json','process_tree_peak_rss_kib':3000,
                'memory_sampling':{'poll_wait_s':.05,'samples':20,'max_interval_s':.08}}
        with tempfile.TemporaryDirectory(dir=HERE) as directory:
            evidence=store(Path(directory),{'/evidence/board/reference-1/time.json':timing})
            v.verify_timing(evidence,sample)
            sample['wall_s']=12.0
            with self.assertRaisesRegex(RuntimeError,'raw GNU-time'):v.verify_timing(evidence,sample)

    def test_canonical_result_name_does_not_hide_deprecated_command_alias(self):
        proto={'reference_cli':'/work/reference/bin/kicad-route'}
        board={'output':'/evidence/board','project':'/work/reference/board','args':['--budget','180']}
        raw=result();raw['tool_identity']={'python':{'executable':'/usr/bin/python3'}}
        command=['/usr/bin/time','-q','-f','{"wall_s":%e,"user_s":%U,"system_s":%S,"max_rss_kib":%M}',
                 '-o','/evidence/board/reference-1/time.json','/usr/bin/python3',proto['reference_cli'],
                 '--out','/evidence/board/reference-out','run','--backend','builtin','--dir',board['project'],
                 '--run-dir','/evidence/board/reference-1/run','--json','--budget','180']
        with tempfile.TemporaryDirectory(dir=HERE) as directory:
            evidence=store(Path(directory),{'/evidence/board/reference-1/command.json':command})
            v.verify_command(evidence,proto,board,'reference',1,{'timed_command':command},raw)
        command[12]='krt'
        with tempfile.TemporaryDirectory(dir=HERE) as directory:
            evidence=store(Path(directory),{'/evidence/board/reference-1/command.json':command})
            with self.assertRaisesRegex(RuntimeError,'argv/backend'):
                v.verify_command(evidence,proto,board,'reference',1,{'timed_command':command},raw)


if __name__=='__main__':unittest.main()
