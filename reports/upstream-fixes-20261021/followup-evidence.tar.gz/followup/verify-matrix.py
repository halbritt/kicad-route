#!/usr/bin/env python3
"""Read-only post-terminal verification of the frozen six-fix Archon matrix.

Only retained, SHA-indexed files are read. No native execution, remote work,
source edits, rule changes, retries or replacement of a prior verdict occur.
The existing portable inventory resolver is retained unchanged by SHA.
"""
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import re
import sys

sys.dont_write_bytecode=True
Q=Path(__file__).resolve().parent
STORE_SHA='99b1078290d27f13401adbac060ac1b6758bcfc60dcd1f2fe68f7acd4feef3e7'
store_path=Q/'acceptance_profile.py'
if hashlib.sha256(store_path.read_bytes()).hexdigest()!=STORE_SHA:
    raise RuntimeError('Existing portable evidence resolver bytes changed')
spec=importlib.util.spec_from_file_location('upstream_evidence_store',store_path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
EvidenceStore,digest,require=module.EvidenceStore,module.digest,module.require
PROTOCOL='/evidence/archon-protocol.json'
PROTOCOL_SHA='23ced002d30ff310d18cab5c96688798773f40d96bb0b78fb78ac1c13b0bcd1d'
CPU_CONTROLS=('cpu.max','cpu.max.burst','cpu.weight','cpu.idle','cpuset.cpus.effective')
HOST_CONTROLS=(*CPU_CONTROLS,'memory.max','memory.high')
METRICS=('wall_s','max_rss_kib','process_tree_peak_rss_kib')
BOARD_NAMES=['diff-pair','four-layer','multipoint','route-demo']


def number(value):return type(value) in (int,float) and math.isfinite(value)


def canonical_group(value):
    return isinstance(value,str) and value.startswith('/') and (value=='/' or
        all(part not in ('','.','..') for part in value[1:].split('/')))


def inside(group,parent):
    return canonical_group(group) and canonical_group(parent) and (group==parent or group.startswith(parent.rstrip('/')+'/'))


def cpuset(value):
    result=set()
    for field in value.strip().split(','):
        ends=field.split('-');require(len(ends) in (1,2),'malformed effective CPU set')
        first,last=int(ends[0]),int(ends[-1]);require(0<=first<=last<100000,'invalid effective CPU range')
        for cpu in range(first,last+1):require(cpu not in result,'duplicate effective CPU');result.add(cpu)
    return result


def cpu_stat(value):
    result={}
    for line in value.splitlines():
        fields=line.split();require(len(fields)==2 and fields[0] not in result,'duplicate/malformed raw CPU stat')
        counter=int(fields[1]);require(counter>=0,'negative CPU stat');result[fields[0]]=counter
    require('usage_usec' in result,'missing raw CPU usage');return result


def utc(value):return dt.datetime.fromisoformat(value.replace('Z','+00:00'))


def host_controls(value,protocol):
    require(value['host']==value['actual_hostname']=='archon' and
        value['container_id']==protocol['container_id'] and value['image_id']==protocol['container_image_id'] and
        value['container_hostname']==protocol['container_hostname'],'host/container/image identity differs')
    require(type(value['init_pid']) is int and value['init_pid']>0 and value['init_affinity']==protocol['cpu_affinity'] and
        value['init_nice']==value['init_scheduler']==0,'host initPID/CPU/normal-priority identity differs')
    raw=value['raw_init_cgroup'].splitlines();require(len(raw)==1 and raw[0].startswith('0::'),'invalid host raw cgroup membership')
    group=raw[0][3:];require(canonical_group(group) and PurePosixPath(group).name=='docker-'+protocol['container_id']+'.scope',
        'host container membership does not bind actual container')
    leaf=PurePosixPath('/sys/fs/cgroup')/group.lstrip('/')
    require(str(leaf)==value['host_leaf'],'host cgroup leaf differs from membership')
    config=value['docker_resource_config']
    require(all(config.get(key)==0 for key in ('NanoCpus','CpuShares','CpuPeriod','CpuQuota','CpuRealtimePeriod','CpuRealtimeRuntime','Memory','MemorySwap')) and
        config.get('CpusetCpus')==config.get('CpusetMems')==config.get('CgroupParent')=='','Docker resources differ from unmodified full-CPU profile')
    rows=value['ancestors'];require(rows and rows[0]['path']==str(leaf) and rows[-1]['path']=='/sys/fs/cgroup','host ancestor population incomplete')
    for index,row in enumerate(rows):
        if index:require(PurePosixPath(rows[index-1]['path']).parent==PurePosixPath(row['path']),'omitted host ancestor')
        controls=row['controls'];maximum=controls.get('cpu.max')
        if maximum is not None:
            quota,period=maximum.split();require(quota=='max' and int(period)>0,'finite or invalid hidden ancestor quota')
        else:require(index==len(rows)-1,'nonroot host quota missing')
        require(cpuset(controls['cpuset.cpus.effective'])==set(protocol['cpu_affinity']),'hidden host CPU set differs')
        require(controls.get('cpu.idle') in (None,'0'),'host idle scheduling differs')
        cpu_stat(controls['cpu.stat'])
    require(value.get('host_cpu_pressure') and value.get('host_io_pressure'),'host pressure receipts missing')
    return {'container_id':value['container_id'],'image_id':value['image_id'],'init_pid':value['init_pid'],
        'raw_init_cgroup':value['raw_init_cgroup'],'init_affinity':value['init_affinity'],'init_nice':value['init_nice'],
        'init_scheduler':value['init_scheduler'],'docker_resource_config':config,
        'ancestors':[{'path':r['path'],'controls':{key:r['controls'].get(key) for key in HOST_CONTROLS}} for r in rows]}


def container_controls(value,protocol):
    group=value['group'];require(canonical_group(group) and value['proc_self_cgroup'].splitlines()==['0::'+group],
        'container namespace membership noncanonical or misbound')
    require(value['cpu_affinity']==protocol['cpu_affinity'] and value['nice']==value['scheduler']==0 and
        number(value['monotonic_s']),'container affinity/priority/clock differs')
    leaf,mount=PurePosixPath(value['leaf']),PurePosixPath(value['mount'])
    require(leaf.is_relative_to(mount) and ('/'+str(leaf.relative_to(mount)) if leaf!=mount else '/')==group,
        'container cgroup mount/leaf mapping differs')
    rows=value['ancestors'];require(rows and rows[0]['path']==str(leaf) and rows[-1]['path']==str(mount),'container ancestor population incomplete')
    for index,row in enumerate(rows):
        if index:require(PurePosixPath(rows[index-1]['path']).parent==PurePosixPath(row['path']),'omitted container ancestor')
        controls=row['controls'];maximum=controls['cpu.max'].get('text')
        if maximum is not None:
            quota,period=maximum.split();require(quota=='max' and int(period)>0,'finite container CPU quota')
        else:require(index==len(rows)-1 and 'No such file or directory' in controls['cpu.max'].get('error',''),'unusable quota observation')
        effective=controls['cpuset.cpus.effective']
        if 'text' in effective:require(cpuset(effective['text'])==set(protocol['cpu_affinity']),'container effective CPU set differs')
        else:require('No such file or directory' in effective.get('error',''),'unusable cpuset observation')
        idle=controls['cpu.idle'].get('text')
        require(idle is None or idle.strip()=='0','container idle scheduling')
        cpu_stat(row['observations']['cpu.stat']['text'])
    require(all(value['host_resources'][key].get('text') for key in ('/proc/stat','/proc/pressure/cpu','/proc/pressure/io','/proc/pressure/memory')),
        'container host resource diagnostics missing')
    return {'group':group,'cpu_affinity':value['cpu_affinity'],'nice':value['nice'],'scheduler':value['scheduler'],
        'ancestors':[{'path':r['path'],'controls':r['controls']} for r in rows]}


def membership_proof(monitor,group,cli,samples,before,after):
    rows=monitor['members'];require(type(monitor['sampler_calls']) is int and monitor['sampler_calls']==samples and samples>0 and
        monitor['observed_births']==len(rows) and rows,'membership/RSS sampler population differs')
    keys={(r['pid'],r['birth_ticks']) for r in rows};require(len(keys)==len(rows) and
        all(type(pid) is int and pid>0 and type(birth) is int and birth>0 for pid,birth in keys),'duplicate/invalid observed birth')
    roots={r['gnu_time_root_pid'] for r in rows};require(len(roots)==1,'membership mixes native roots')
    allowed={'observed','exited-before-membership-verification','pid-reused-before-membership-verification'}
    for row in rows:
        require(row['status'] in allowed and number(row['observed_monotonic_s']) and
            before<=row['observed_monotonic_s']<=after,'membership status/observation clock invalid')
        if row['status']=='observed':require(inside(row['group'],group) and row.get('in_scope') is True,'observed descendant escaped container scope')
    observed=[r for r in rows if r['status']=='observed']
    require(any(r['pid'] in roots for r in observed),'GNU-time root membership unobserved')
    require(any(r['pid'] not in roots and cli in r.get('argv',[]) for r in observed),'actual CLI child membership unobserved')
    races=[r for r in rows if r['status']!='observed']
    require(monitor['outside_scope']==monitor['read_errors']==[] and monitor['exit_races']==races,'membership summaries differ from raw birth records')
    return {'observed_in_scope':len(observed),'explicit_birth_races':len(races)}


def expected_input(protocol,board):
    project=PurePosixPath(board['project']);suffixes={'.kicad_sch','.kicad_pcb','.kicad_pro','.kicad_dru','.kicad_wks','.kicad_sym','.lib','.dcm','.mod'}
    return {str(PurePosixPath(r['path']).relative_to(project)):r['sha256'] for r in protocol['hash_prerequisites']
        if PurePosixPath(r['path']).is_relative_to(project) and (PurePosixPath(r['path']).suffix in suffixes or
        PurePosixPath(r['path']).name in ('sym-lib-table','fp-lib-table'))}


def tool_proof(store,protocol,tools,board,side,sample):
    result=store.read(sample['result']);identity=result['tool_identity'];runtime=protocol['target_runtime'][side]
    require(sample['tool_identity']==identity and sample['backend']==result['backend'],'raw tool/backend summaries differ')
    require(identity['kicad_route']['commit']==next(r['head'] for r in protocol['source_heads'] if r['path']=='/work/'+side) and
        identity['kicad_route']['dirty'] is False,'actual source checkout identity differs')
    require(identity['kicad_cli']==dict(tools['kicad_cli'],version=tools['kicad_version']) and
        identity['pcbnew']['build_version']==tools['pcbnew_build'] and identity['python']['version']==tools['python_version']=='3.12.3',
        'actual native grading/interpreter differs from prepared toolchain')
    require(identity['state_manifest_sha256']==runtime['manifest_sha256'] and identity['state_manifest_drift']==[],
        'actual native manifest drift or wrong runtime generation')
    expected={'name':'builtin','tag':runtime['source']['build'],'version':runtime['source']['version'],
        'grid_router_version':runtime['source']['version'],'source_sha256':runtime['source']['source_sha256'],
        'extension_module_sha256':runtime['module_sha256'],'venv_packages_sha256':runtime['packages_sha256']}
    backend=identity['backend'];require(all(backend.get(k)==v for k,v in expected.items()),'actual executed owned backend differs from prepared build')
    expected['venv_python_version']='3.12.3'
    require(backend.get('venv_python_version')=='3.12.3' and result['backend']['execution_identity']==expected,
        'actual execution identity differs')
    require(result['backend']['name']=='builtin' and result['backend']['source_sha256']==runtime['source']['source_sha256'],
        'raw result public backend/source differs')
    require(sample['cli_sha256']==next(r['sha256'] for r in protocol['hash_prerequisites'] if r['path']==protocol[side+'_cli']),
        'executed CLI bytes differ')
    files=expected_input(protocol,board);require(files and sample['reference_files']==result['evidence']['reference_files']==files,
        'actual native input population/hashes differ')
    return {'backend':expected,'native':identity['kicad_cli'],'pcbnew':identity['pcbnew'],'wrapper_python':identity['python']}


def prepared_runtimes(store,protocol,tools):
    result={}
    for side in ('reference','candidate'):
        runtime=protocol['target_runtime'][side];state=PurePosixPath(protocol[side+'_state'])
        path=str(state/'manifest.json');manifest=store.read(path);krt=manifest['krt']
        require(store.artifact(path)['sha256']==runtime['manifest_sha256'] and
            krt['source_sha256']==runtime['source']['source_sha256'] and krt['version']==runtime['source']['version'] and
            krt['commit']==runtime['source']['commit'],'prepared manifest source identity differs')
        module=str(state/krt['extension_module']['path'])
        require(module==runtime['module'] and store.artifact(module)['sha256']==krt['extension_module']['sha256']==runtime['module_sha256'],
            'captured native extension differs from selected manifest/runtime')
        venv=krt['venv'];packages=venv['packages']
        package_sha=hashlib.sha256(('\n'.join(packages)+'\n').encode()).hexdigest()
        require(venv['python_version']=='3.12.3' and packages==runtime['packages'] and
            package_sha==venv['packages_sha256']==runtime['packages_sha256'],'prepared interpreter/packages differ')
        require(manifest['kicad']['kicad_cli']==dict(tools['kicad_cli'],version=tools['kicad_version']) and
            manifest['kicad']['pcbnew_build_version']==tools['pcbnew_build'],'prepared native grading manifest differs')
        prep_path=f'/evidence/preparation-{side}/preparation.json';prep=store.read(prep_path)
        require(prep['status']=='PASS' and prep['side']==side and prep['state']==str(state) and prep['runtime']==runtime and
            prep['source_commit']==krt['commit'] and prep['gates'] and all(g['passed'] is True for g in prep['gates']) and
            all(step['exit_code']==0 for step in prep['steps']) and runtime['dependency_pyc_count']==1619,
            'prepared runtime receipt is not all-gatesPASS/matched bytecode preparation')
        result[side]={'manifest':store.artifact(path),'module':store.artifact(module),'preparation':store.artifact(prep_path),
            'source_sha256':krt['source_sha256'],'extension_sha256':runtime['module_sha256'],
            'python_version':venv['python_version'],'packages_sha256':package_sha,'dependency_pyc_count':runtime['dependency_pyc_count']}
    require(result['reference']['packages_sha256']==result['candidate']['packages_sha256'],
        'prepared same-container scientific dependencies differ')
    return result



def pair_population(value):
    require(isinstance(value,list),'pair population is not a list')
    pairs=[]
    for row in value:
        require(isinstance(row,dict) and isinstance(row.get('p'),str) and row['p'] and
                isinstance(row.get('n'),str) and row['n'] and row['p']!=row['n'],'malformed oriented pair')
        pairs.append((row['p'],row['n']))
    require(len(pairs)==len(set(pairs)),'duplicate oriented pair')
    return set(pairs)


def quality_from_result(result):
    process,routing,validation=(result[key] for key in ('process','routing','validation'))
    pairs=result.get('pairs',[])
    if result['schema'].endswith('/2') and 'pairs' not in result:pairs=None
    commands=process.get('commands')
    return {'process':process.get('status'),'routing':routing.get('status'),
            'validation':validation.get('status'),'unconnected':routing.get('unconnected_total'),
            'open_nets':routing.get('unrouted_nets'),'preservation':validation.get('preservation'),
            'new_violations':validation.get('drc',{}).get('new_violations',{}).get('count'),
            'input_fingerprint':result.get('input',{}).get('fingerprint'),
            'copper':result.get('evidence',{}).get('candidate_copper_signature',{}).get('sha256'),
            'pairs':pairs,'wall_clock_stop':None if not commands else any(
                row.get(flag) for row in [process,*commands] for flag in ('budget_reached','stalled','killed'))}


def verify_quality(quality,expected_pairs):
    require(quality['process']==quality['validation']=='PASS','routing/native validation failed')
    require(quality['routing'] in ('COMPLETE','INCOMPLETE') and type(quality['unconnected']) is int and
            quality['unconnected']>=0 and isinstance(quality['open_nets'],list),'invalid routing completion evidence')
    require(type(quality['new_violations']) is int and quality['new_violations']==0,'new native violations')
    require(isinstance(quality['preservation'],dict) and quality['preservation'] and
            all(value=='PASS' for value in quality['preservation'].values()),'failed preservation')
    require(quality['input_fingerprint'] and quality['copper'] and quality['wall_clock_stop'] is False,
            'missing input/copper identity or censored attempt')
    require(pair_population(quality['pairs'])==pair_population(expected_pairs),'frozen expected pair population differs')
    require(all(pair.get('routed') is True and pair.get('status')=='ROUTED' for pair in quality['pairs']),
            'pair routing failed')


def median_metrics(reference,candidate):
    """Independent fixed-five median arithmetic, without invoking the comparator."""
    require(len(reference)==len(candidate)==5,'not exactly five measured attempts per side')
    result={}
    for metric in METRICS:
        values=[[row.get(metric) for row in side] for side in (reference,candidate)]
        require(all(number(value) and value>0 for side in values for value in side),'invalid measured '+metric)
        before,after=(sorted(side)[2] for side in values)
        result[metric]={'reference_median':before,'candidate_median':after,'ratio':after/before,'limit':1.10}
    return result


def verify_command(store,protocol,board,side,index,sample,result):
    directory=PurePosixPath(board['output'])/f'{side}-{index}'
    command=store.read(str(directory/'command.json'))
    expected=['/usr/bin/time','-q','-f',
              '{"wall_s":%e,"user_s":%U,"system_s":%S,"max_rss_kib":%M}',
              '-o',str(directory/'time.json'),result['tool_identity']['python']['executable'],
              protocol[side+'_cli'],'--out',str(PurePosixPath(board['output'])/(side+'-out')),
              'run','--backend','builtin','--dir',board['project'],
              '--run-dir',str(directory/'run'),'--json',*board['args']]
    require(command==sample['timed_command']==expected,'actual full timed CLI argv/backend/args differ')
    return store.artifact(str(directory/'command.json'))


def verify_timing(store,sample):
    directory=PurePosixPath(sample['result']).parent.parent
    timing=store.read(str(directory/'time.json'))
    for name in ('wall_s','user_s','system_s','max_rss_kib'):
        require(number(timing.get(name)) and timing[name]>=0 and timing[name]==sample.get(name),
                'raw GNU-time metric differs from sample: '+name)
    require(timing['wall_s']>0 and timing['max_rss_kib']>0 and
            number(sample['process_tree_peak_rss_kib']) and sample['process_tree_peak_rss_kib']>0,
            'nonpositive full-CLI time or RSS')
    sampling=sample['memory_sampling']
    require(sampling['poll_wait_s']==0.05 and type(sampling['samples']) is int and sampling['samples']>0 and
            number(sampling['max_interval_s']) and sampling['max_interval_s']>=0,'invalid sampled-RSS observation')


def verify_native_records(store,sample,board):
    result=store.read(sample['result']);run=PurePosixPath(sample['result']).parent
    evidence=result['evidence'];validation=result['validation']
    actual=store.artifact(result['candidate']['board'])['sha256']
    require(validation['candidate_board_sha256']==validation['validated_board_sha256']==actual==
            evidence['candidate_board_sha256'],'native validation/evidence not bound to final retained board')
    require(validation['rules_files']['not_loaded']==[],'native grader did not load original rules')
    records=evidence['records'];require(records,'native grading records missing')
    for relative,expected in records.items():
        path=PurePosixPath(relative)
        require(not path.is_absolute() and '..' not in path.parts and
                store.artifact(str(run/path))['sha256']==expected,'native grading record locator/hash mismatch')
    preservation=store.read(str(run/'validate/preservation.json'))
    require(isinstance(preservation,list) and preservation and
            len({row['check'] for row in preservation})==len(preservation) and
            {row['check']:row['status'] for row in preservation}==validation['preservation'],
            'raw preservation checks differ from result')
    findings=store.read(str(run/'validate/new-findings.json'))
    require(findings['violations']==[] and findings['schematic_parity']==[],
            'raw new native findings are not empty')
    commands=validation['drc_commands']
    require(isinstance(commands,list) and commands and all(command['exit_code']==0 for command in commands),
            'native grading commands failed/missing')
    require(any('--refill-zones' in command['argv'] for command in commands) and
            any('--severity-all' in command['argv'] for command in commands),'native refill/final DRC missing')
    for command in commands:
        argv=command['argv']
        require(argv[:3]==['kicad-cli','pcb','drc'] and argv[-1]==result['candidate']['board'],
                'native grading command does not grade retained candidate')
        report=argv[argv.index('-o')+1];store.read(report);store.resolve(command['log'])
    if board['expected_pairs']:
        require(store.read(str(run/'validate/pairs.json'))==result['pairs'],'raw native pair grading differs')
    attempt=store.read(str(run/'attempt.json'));ref=PurePosixPath(attempt['reference_dir'])
    require(not ref.is_absolute() and '..' not in ref.parts,'unsafe original reference directory')
    for name,expected in evidence['reference_files'].items():
        relative=PurePosixPath(name)
        require(not relative.is_absolute() and '..' not in relative.parts and
                store.artifact(str(run/ref/relative))['sha256']==expected,'retained actual reference bytes differ')
    return len(records)


def verify_board(store,protocol,board,driver):
    output=PurePosixPath(board['output'])
    comparison=store.read(str(output/'comparison.json'));report=store.read(str(output/'samples.json'))
    require(comparison['schema']==report['schema']=='kicad-route/engine-comparison/2' and
            comparison['project']==report['project']==board['project'] and
            comparison['args']==report['args']==board['args'] and
            comparison['mode']==report['mode']==protocol['comparison_mode']=='algorithm-change' and
            comparison['cpu_affinity']==report['cpu_affinity']==protocol['cpu_affinity'] and
            comparison['expected_pairs']==report['expected_pairs']==board['expected_pairs'] and
            comparison['reference_backend']==comparison['candidate_backend']==
            report['reference_backend']==report['candidate_backend']=='builtin',
            'raw comparison board/profile/args/backend identity differs')
    require(comparison['archon_protocol']==str(PurePosixPath(protocol['metadata_output'])/'protocol.json'),
            'comparison points to wrong frozen protocol')
    require(all(comparison[key]==report[key] for key in ('reference','candidate','warmup')),
            'comparison differs from final raw samples')
    require(len(report['reference'])==len(report['candidate'])==5 and set(report['warmup'])=={'reference','candidate'},
            'missing warmup or measured population')
    expected={str(output/f'{side}-{index}/run/result.json') for side in ('reference','candidate') for index in range(6)}
    samples=report['reference']+report['candidate']+list(report['warmup'].values())
    require(len(samples)==12 and {sample['result'] for sample in samples}==expected and
            store.descendants(str(output),'*/run/result.json')==expected,'missing/extra/dropped raw native result')
    expected_dirs={f'{side}-{index}' for side in ('reference','candidate') for index in range(6)}
    for original in store.descendants(str(output)):
        first=PurePosixPath(original).relative_to(output).parts[0]
        if re.fullmatch(r'(reference|candidate)-\d+',first):
            require(first in expected_dirs,'extra attempted sample directory')
    for side in ('reference','candidate'):
        require([row['result'] for row in report[side]]==[str(output/f'{side}-{index}/run/result.json') for index in range(1,6)],
                'measured list order differs')
        require(report['warmup'][side]['result']==str(output/f'{side}-0/run/result.json'),'warmup locator differs')
    quality=[]
    for side in ('reference','candidate'):
        for index,sample in enumerate([report['warmup'][side],*report[side]]):
            result=store.read(sample['result']);raw_quality=quality_from_result(result)
            require(sample['exit_code']==result['exit_code']==0 and raw_quality==sample['quality']==driver.quality(result),
                    'sample/raw result quality or CLI exit differs')
            verify_quality(raw_quality,board['expected_pairs']);quality.append(raw_quality)
            verify_timing(store,sample);verify_command(store,protocol,board,side,index,sample,result)
    baseline=[report['warmup']['reference']['quality'],*[row['quality'] for row in report['reference']]]
    minimum=min(row['unconnected'] for row in baseline)
    allowed=set.intersection(*(set(row['open_nets']) for row in baseline))
    needs_complete=any(row['routing']=='COMPLETE' for row in baseline)
    for row in quality:
        require(row['input_fingerprint']==baseline[0]['input_fingerprint'] and
                set(row['preservation'])==set(baseline[0]['preservation']),'input/preservation population differs')
        require(row['unconnected']<=minimum and not (set(row['open_nets'])-allowed) and
                (not needs_complete or row['routing']=='COMPLETE'),'completion regressed versus reference')
    metrics=median_metrics(report['reference'],report['candidate'])
    verdict=driver.compare(report['reference'],report['candidate'],report['warmup'],report['mode'])
    require(metrics==verdict['metrics'] and comparison['pair_population_failures']==report['pair_population_failures']==[] and
            comparison['verdict']==verdict,'independent median/raw comparator result differs from reported verdict')
    require(verdict['passed']==all(row['candidate_median']<=row['reference_median']*1.1 for row in metrics.values()),
            'strict median gate verdict differs')
    return report,{'board':board['name'],'passed':verdict['passed'],'metrics':metrics,
                   'copper_geometry_equal':verdict['copper_geometry_equal'],
                   'reference_completion':{'minimum_open':minimum,'all_complete':all(row['routing']=='COMPLETE' for row in baseline)},
                   'report':store.artifact(str(output/'comparison.json'))}

def verify(store,session,exit_code):
    require(isinstance(session,str) and session and exit_code in (0,1),'actual terminal session/exit observation required')
    require(store.artifact(PROTOCOL)['sha256']==PROTOCOL_SHA,'frozen protocol bytes differ')
    protocol=store.read(PROTOCOL)
    require(protocol['execution_ready'] is True and protocol['measured_repetitions']==5 and
            protocol['warmups_per_side']==1 and [row['name'] for row in protocol['boards']]==BOARD_NAMES and
            protocol['comparison_mode']=='algorithm-change' and protocol['reference_backend']==protocol['candidate_backend']=='builtin' and
            protocol['cpu_affinity']==list(range(16)) and protocol['allowed_existing_policy_quotas']=={},
            'frozen four-board/48-attempt/all16CPU profile differs')
    require([pair_population(row['expected_pairs']) for row in protocol['boards']]==
            [{('/CAN+','/CAN-')},set(),set(),set()],'frozen CAN pair expectation differs')
    for row in [*protocol['hash_prerequisites'],protocol['host_before_attestation']]:
        require(store.artifact(row['path'])['sha256']==row['sha256'],'frozen prerequisite drift: '+row['path'])
    require(store.artifact(protocol['harness'])['sha256']==protocol['harness_sha256'],'frozen harness differs')
    driver=store.load_comparison(protocol['driver'],protocol['driver_sha256'])
    metadata=PurePosixPath(protocol['metadata_output']);terminal_path=str(metadata/'matrix.json');terminal=store.read(terminal_path)
    require(terminal['schema']=='kicad-route/archon-matrix/1' and terminal['status'] in ('PASS','FAIL') and
            terminal['completed_samples']==48 and len(terminal['boards'])==4 and
            terminal['protocol_sha256']==PROTOCOL_SHA and store.artifact(str(metadata/'protocol.json'))['sha256']==PROTOCOL_SHA,
            'matrix is not terminal with all48 completions under frozen protocol')
    require(exit_code==(0 if terminal['status']=='PASS' else 1),'observed launcher exit disagrees with terminal matrix')
    host_before=store.read(protocol['host_before_attestation']['path']);host_after=store.read(protocol['host_after_attestation_path'])
    require(host_controls(host_before,protocol)==host_controls(host_after,protocol),'host/container/initPID/ancestor profile changed')
    require(host_after.get('observed_matrix_status')==terminal['status'] and host_after.get('observed_completed_samples')==48,
            'host-after was not captured after all48 terminal attempts')
    for first,last in zip(host_before['ancestors'],host_after['ancestors']):
        first,last=cpu_stat(first['controls']['cpu.stat']),cpu_stat(last['controls']['cpu.stat'])
        require(set(first)==set(last) and all(last[key]>=first[key] for key in first),'host CPU accounting reset')
    initial=store.read(str(metadata/'initial-resources.json'));profile=container_controls(initial,protocol)
    require(utc(host_before['observed_utc'])<=utc(initial['utc']),'host-before follows matrix start')
    tools=store.read('/evidence/container-tools.json')
    require(tools['kicad_version']=='10.0.7' and tools['python_version']=='3.12.3','native KiCad/Python toolchain differs')
    prepared=prepared_runtimes(store,protocol,tools)
    expected_labels=[f"{board['name']}-{side}-{index}" for board in protocol['boards'] for index in range(6)
                     for side in (('reference','candidate') if index%2==0 else ('candidate','reference'))]
    expected_resources={str(metadata/'samples'/(label+'.json')) for label in expected_labels}
    require(store.descendants(str(metadata/'samples'),'*.json')==expected_resources,'resource record population is not exactly48')
    log=store.resolve(protocol['outer_log']).read_text()
    require([line.removesuffix(': running') for line in log.splitlines() if line.endswith(': running')]==expected_labels,
            'actual launch log order/count differs from frozen48 sequence')
    boards=[];last_clock=initial['monotonic_s'];last_utc=utc(initial['utc']);identities={};births=races=records=completed=0
    resource_failures=[];observed_quality=[]
    for board,row in zip(protocol['boards'],terminal['boards']):
        require(row['name']==board['name'] and row['output']==board['output'] and row['completed_samples']==12,
                'terminal board identity/population differs')
        report,verdict=verify_board(store,protocol,board,driver)
        require(row['verdict']==store.read(str(PurePosixPath(board['output'])/'comparison.json'))['verdict'] and
                row['status']==('PASS' if verdict['passed'] else 'FAIL'),'terminal board verdict differs from raw recomputation')
        for index in range(6):
            for side in (('reference','candidate') if index%2==0 else ('candidate','reference')):
                sample=report['warmup'][side] if index==0 else report[side][index-1]
                label=f"{board['name']}-{side}-{index}";resource=store.read(str(metadata/'samples'/(label+'.json')))
                before,after=resource['before'],resource['after']
                require(resource['label']==label and container_controls(before,protocol)==profile==container_controls(after,protocol) and
                        after['monotonic_s']>before['monotonic_s']>=last_clock and number(resource['driver_call_wall_s']) and
                        0<resource['driver_call_wall_s']<=after['monotonic_s']-before['monotonic_s'],
                        'actual per-attempt control profile or chronological order differs: '+label)
                require(utc(before['utc'])>=last_utc and utc(after['utc'])>=utc(before['utc']),
                        'sample UTC order differs: '+label)
                for old,new in zip(before['ancestors'],after['ancestors']):
                    old,new=cpu_stat(old['observations']['cpu.stat']['text']),cpu_stat(new['observations']['cpu.stat']['text'])
                    require(set(old)==set(new) and all(new[key]>=old[key] for key in old),'container CPU accounting reset')
                membership=membership_proof(resource['membership_monitor'],initial['group'],protocol[side+'_cli'],
                                             sample['memory_sampling']['samples'],before['monotonic_s'],after['monotonic_s'])
                births+=membership['observed_in_scope'];races+=membership['explicit_birth_races']
                resource_failures.extend(label+': '+failure for failure in resource['resource_violations'])
                last_clock,last_utc=after['monotonic_s'],utc(after['utc'])
                identity=tool_proof(store,protocol,tools,board,side,sample)
                if side in identities:require(identity==identities[side],'actual tool identity changed between attempts')
                identities[side]=identity
                records+=verify_native_records(store,sample,board);completed+=1;observed_quality.append(sample['quality'])
        boards.append(verdict)
    require(utc(host_after['observed_utc'])>=last_utc,'host-after precedes native completion')
    require(terminal['resource_violations']==resource_failures,'terminal resource violations differ from raw observations')
    require(identities['reference']['native']==identities['candidate']['native'] and
            identities['reference']['pcbnew']==identities['candidate']['pcbnew'] and
            identities['reference']['wrapper_python']==identities['candidate']['wrapper_python'],
            'reference/candidate used different native grading tools')
    passed=all(row['passed'] for row in boards) and not resource_failures
    require(terminal['all_comparisons_passed'] is passed and terminal['status']==('PASS' if passed else 'FAIL'),
            'terminal overall verdict differs from independently recomputed gates')
    return {'schema':'kicad-route/upstream-archon-verification/1','status':'PASS' if passed else 'FAIL','host':'archon',
            'matrix_session':session,'observed_matrix_exit_code':exit_code,'completed_attempts':completed,
            'measured_attempts':40,'separate_warmups':8,'completed_boards':4,'comparison_mode':'algorithm-change','gate_limit':1.10,
            'protocol':store.artifact(PROTOCOL),'matrix':store.artifact(terminal_path),
            'evidence_index':{'path':str(store.index_path),'sha256':digest(store.index_path)},
            'verifier_sha256':digest(Path(__file__)),'resolver_sha256':STORE_SHA,'boards':boards,
            'quality':{'all48_raw_result_summaries_checked':True,'frozen_pair_population_checked':True,
                       'all48_uncensored':True,'all48_native_validation_and_preservation_passed':True,
                       'all48_complete':all(row['routing']=='COMPLETE' for row in observed_quality),
                       'original_rule_and_final_board_hashes_checked':True,'grading_record_hashes_verified':records},
            'resources':{'observed_in_scope_births':births,'explicit_birth_races':races,
                         'resource_violations':resource_failures,'all48_order_control_membership_checked':True,
                         'host_before':store.artifact(protocol['host_before_attestation']['path']),
                         'host_after':store.artifact(protocol['host_after_attestation_path'])},
            'runtime':{'prepared':prepared,'actual':identities},
            'limits':['Sampled process-tree RSS is the frozen observer peak (lower bound), not a reconstructed continuous peak.',
                      'Membership is once per observed birth; explicit reap/reuse races are retained, not continuous migration tracing.',
                      'Algorithm-change mode permits copper geometry changes; all original native and 1.10 gates remain enforced.',
                      'External index SHA and actual terminal session/exit are root observations, not inferred from imported metadata.'],
            'native_reruns':False,'source_or_state_mutations':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--index',type=Path,required=True);parser.add_argument('--index-sha256',required=True)
    parser.add_argument('--matrix-session',required=True);parser.add_argument('--matrix-exit-code',type=int,required=True)
    parser.add_argument('--out',type=Path,default=Q/'archon-final-verification.json');args=parser.parse_args()
    require(not args.out.exists(),'refusing to replace a previous independent verification')
    try:
        result=verify(EvidenceStore(args.index,args.index_sha256),args.matrix_session,args.matrix_exit_code)
    except Exception as error:
        result={'schema':'kicad-route/upstream-archon-verification/1','status':'FAIL',
                'matrix_session':args.matrix_session,'observed_matrix_exit_code':args.matrix_exit_code,
                'error':f'{type(error).__name__}: {error}','protocol_sha256':PROTOCOL_SHA,
                'evidence_index':{'path':str(args.index),'observed_sha256':args.index_sha256},
                'native_reruns':False,'source_or_state_mutations':False}
    args.out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'report':str(args.out),'sha256':digest(args.out)}))
    return 0 if result['status']=='PASS' else 1


if __name__=='__main__':raise SystemExit(main())
