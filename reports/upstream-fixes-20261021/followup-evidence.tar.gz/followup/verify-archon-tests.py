#!/usr/bin/env python3
"""Independently check completed ordinary smoke/repeats without rerunning tests.\n\nRun as UID1000 in the dedicated test container. Original qualifier artifacts\nare read only; this helper emits a separate receipt and JUnit normalization map.\n"""
import argparse
import ast
from collections import Counter, defaultdict
import datetime as dt
import hashlib
import importlib.metadata
import itertools
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode=True
ROOT=Path('/testwork/candidate')
STATE=Path('/testwork/state-candidate')
HEAD='4fb4fa14a968cf08127cc849d81eb0f9c20a1b05'
SOURCE='89a2efbf53057a0694b3cef365ec3acdc01b61f5f57d86bfbe8a62dc8f11db6d'
NODES=815


def require(value,message):
    if not value:raise RuntimeError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    path=Path(path)
    require(path.is_file() and not path.is_symlink(),'missing/nonregular artifact: '+str(path))
    return json.loads(path.read_text())


def node_address(value,root=ROOT):
    """Map one collected pytest node to explicit canonical/JUnit addresses."""
    path,separator,rest=value.partition('::')
    require(separator and rest,'malformed collected node')
    file=PurePosixPath(path)
    if file.is_absolute():
        require(file.is_relative_to(PurePosixPath(str(root))),'collected node outside source')
        file=file.relative_to(PurePosixPath(str(root)))
    require(file.parts and file.parts[0]=='tests' and file.suffix=='.py' and '..' not in file.parts,
            'collected node is not tests/<file>.py')
    base,bracket,parameters=rest.partition('[')
    pieces=base.split('::')
    require(pieces[-1].startswith('test_'),'collected node is not a test')
    name=pieces[-1]+(bracket+parameters if bracket else '')
    module='.'.join(file.with_suffix('').parts)
    suffix='.'+'.'.join(pieces[:-1]) if len(pieces)>1 else ''
    classes={module+suffix,module.removeprefix('tests.')+suffix}
    return str(file)+'::'+rest,{(cls,name) for cls in classes}


def derived_subtests(source,nodes):
    """Derive the six deterministic dialect subTest events from frozen source.\n\n    Pytest9.1 counts successful unittest subTest call events in testsuite.tests\n    even when it renders only the parent testcase. They are not collected nodes.\n    """
    tree=ast.parse(Path(source).read_text())
    klass=next(node for node in tree.body if isinstance(node,ast.ClassDef) and node.name=='LegacyTokenTests')
    events=[]
    for function in klass.body:
        if not isinstance(function,ast.FunctionDef):continue
        calls=[node for node in ast.walk(function) if isinstance(node,ast.Call) and
               isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and
               node.func.value.id=='self' and node.func.attr=='subTest']
        for call in calls:
            loops=[node for node in ast.walk(function) if isinstance(node,ast.For) and call in list(ast.walk(node))]
            domains={}
            for loop in loops:
                require(isinstance(loop.target,ast.Name),'unsupported subtest loop target')
                values=ast.literal_eval(loop.iter)
                require(isinstance(values,(tuple,list)) and values,'unsupported subtest loop domain')
                domains[loop.target.id]=values
            keys=[];values=[]
            for keyword in call.keywords:
                require(keyword.arg and isinstance(keyword.value,ast.Name) and keyword.value.id in domains,
                        'unrecognized source-derived subtest parameter')
                keys.append(keyword.arg);values.append(domains[keyword.value.id])
            require(keys and not call.args,'unsupported subTest message/parameters')
            parent='tests/test_owned_parser_contracts.py::LegacyTokenTests::'+function.name
            require(parent in nodes,'subtest parent missing from exact collection')
            for combination in itertools.product(*values):
                events.append({'parent':parent,'parameters':dict(zip(keys,combination)),
                               'source':str(source),'source_sha256':sha(source),'line':call.lineno})
    require(len(events)==6 and len({(row['parent'],json.dumps(row['parameters'],sort_keys=True)) for row in events})==6,
            'frozen source does not describe the expected six dialect subtest calls')
    return events


def verify_junit(path,nodes,events,root=ROOT):
    canonical=[];lookup=defaultdict(set)
    for node in nodes:
        normalized,addresses=node_address(node,root);canonical.append(normalized)
        for address in addresses:lookup[address].add(normalized)
    require(len(canonical)==len(set(canonical)),'duplicate collected base node')
    tree=ET.parse(path).getroot()
    require(not any(node.tag in {'failure','error','skipped'} for node in tree.iter()),'JUnit has failure/error/skip elements')
    suites=[node for node in tree.iter('testsuite') if not list(node.iterfind('testsuite'))]
    require(suites,'JUnit contains no testsuite')
    counts={key:sum(int(suite.get(key,'0')) for suite in suites) for key in ('tests','failures','errors','skipped')}
    require(all(counts[key]==0 for key in ('failures','errors','skipped')),'JUnit aggregate failures/errors/skips')
    extras={}
    for event in events:
        _,addresses=node_address(event['parent'],root)
        parameters=', '.join(key+'='+repr(value) for key,value in event['parameters'].items())
        for cls,name in addresses:
            # Explicit parameter-bearing spellings only; duplicate bare parent
            # rows never masquerade as independently identified subtests.
            for label in (name+' ('+parameters+')',name+' ['+parameters+']',name+'['+parameters+']'):
                extras[(cls,label)]=(event['parent'],event['parameters'])
    seen=Counter();subseen=Counter();normalization=[]
    for index,case in enumerate(tree.iter('testcase')):
        address=(case.get('classname'),case.get('name'))
        candidates=lookup.get(address,set())
        if candidates:
            require(len(candidates)==1,'ambiguous JUnit node mapping')
            normalized=next(iter(candidates));seen[normalized]+=1
            require(seen[normalized]==1,'duplicate JUnit base testcase: '+normalized)
            normalization.append({'row':index,'classname':address[0],'name':address[1],'kind':'base','node':normalized})
        else:
            require(address in extras,'unmapped JUnit testcase: '+repr(address))
            parent,parameters=extras[address];key=(parent,json.dumps(parameters,sort_keys=True));subseen[key]+=1
            require(subseen[key]==1,'duplicate explicit JUnit subtest')
            normalization.append({'row':index,'classname':address[0],'name':address[1],
                                  'kind':'explicit_subtest','parent':parent,'parameters':parameters})
    require(set(seen)==set(canonical) and len(seen)==len(canonical),'JUnit omitted collected base nodes')
    require(not subseen or len(subseen)==len(events),'partial explicit subtest-row population')
    require(counts['tests']==len(canonical)+len(events),'JUnit aggregate differs from base nodes plus derived subtest call events')
    return {'base_nodes':len(seen),'derived_subtest_events':len(events),'rendered_subtest_rows':len(subseen),
            'testcase_rows':len(normalization),'aggregate':counts,'normalization':normalization,
            'subtest_derivation':events,'count_basis':'Exact collected base nodes plus deterministic source-derived unittest subTest call events; successful events may be counted without separate XML testcase rows.'}


def expected_identity(ready,before):
    krt=before['krt']
    return {'name':'builtin','tag':krt['describe'],'version':krt['version'],
            'grid_router_version':krt['grid_router_version'],'source_sha256':ready['source_sha256'],
            'extension_module_sha256':ready['module_sha256'],'venv_packages_sha256':krt['venv']['packages_sha256'],
            'venv_python_version':krt['venv']['python_version']}


def require_repeat_identity(result,ready,before,state=STATE):
    expected=expected_identity(ready,before);identity=result['tool_identity'];backend=result['backend']
    require(backend['name']=='builtin' and backend['source_sha256']==ready['source_sha256'] and
            backend['runtime']['generation']==ready['generation'] and
            backend['runtime']['source']==str(Path(ready['generation'])/'router') and
            backend['runtime']['venv']==str(Path(ready['generation'])/'venv'),
            'raw repeat executed a different source/generation')
    require(backend['execution_identity']==expected and all(identity['backend'].get(key)==value for key,value in expected.items()),
            'raw repeat backend content identity differs from readiness')
    require(identity['backend']['commit']==identity['kicad_route']['commit']==ready['source_commit'] and
            identity['kicad_route']['dirty'] is False and identity['state_manifest_drift']==[],
            'raw repeat source checkout changed or manifest drifted')
    require(identity['kicad_cli']==before['kicad']['kicad_cli'] and
            identity['pcbnew']['build_version']==before['kicad']['pcbnew_build_version'] and
            identity['python']['version']=='3.12.3' and identity['python']['executable']=='/usr/bin/python3',
            'raw repeat native/Python toolchain differs from readiness')
    require(result['settings']['backend']=='builtin' and result['settings']['budget_s']==180 and
            result['settings']['default_clearance_mm']==0.4 and result['settings']['backend_args']==[] and
            result['settings']['backend_env']=={},'raw repeat settings differ from ordinary strict invocation')
    return expected


def constants(path):
    tree=ast.parse(Path(path).read_text());names={'KRT_FLAGS','KRT_ENV','KRT_PROTECT_EXISTING_FLAGS','KRT_PROTECT_EXISTING_ENV'}
    return {node.targets[0].id:ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and
            len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in names}


def check_backend_command(result,ready,flags):
    generation=Path(ready['generation']);commands=result['process']['commands']
    backend=[row for row in commands if row.get('argv',[])[:2]==
             [str(generation/'venv/bin/python'),str(generation/'router/py_router/route.py')]]
    require(len(backend)==1,'actual strict builtin worker command missing/ambiguous')
    command=backend[0];argv=command['argv'];required=flags['KRT_FLAGS']+flags['KRT_PROTECT_EXISTING_FLAGS']
    for flag in required:require(flag in argv,'strict worker flag missing: '+flag)
    for name,value in (('--escalation','off'),('--fab-tier','standard')):
        require(argv.count(name)==1 and argv[argv.index(name)+1]==value,'strict worker setting changed')
    expected={**flags['KRT_ENV'],**flags['KRT_PROTECT_EXISTING_ENV']}
    require(all(command.get('env',{}).get(key)==value for key,value in expected.items()),'strict worker environment changed')
    return {'argv':argv,'strict_environment':expected}


def active_runtime(common,engine,statemanifest,ready,before,state=STATE):
    selected=common.router_generation(state)  # fresh lookup; never engine.GENERATION's import snapshot
    require(selected is not None and str(selected)==ready['generation'],'active generation changed since readiness')
    current=statemanifest.read(state)
    require(current and not statemanifest.verify(current,state),'current installed manifest drift')
    require(str((state/current['krt']['generation']).resolve())==ready['generation'],'active manifest generation differs')
    require(engine.source_sha256(selected/'router')==engine.source_sha256(engine.SOURCE_ROOT)==SOURCE==ready['source_sha256'],
            'installed/checkout source differs from readiness')
    module=statemanifest.extension_module(selected/'venv')
    require(module is not None and sha(module)==ready['module_sha256']==before['krt']['extension_module']['sha256'],
            'active native extension differs from readiness')
    require(statemanifest.venv_packages(selected/'venv')==ready['packages']==before['krt']['venv']['packages'] and
            statemanifest.venv_python_version(selected/'venv')==before['krt']['venv']['python_version']=='3.12.3',
            'active dependency/Python environment differs from readiness')
    return current,{'generation':str(selected),'source_sha256':SOURCE,'module_sha256':sha(module),
                    'packages':ready['packages'],'venv_python':'3.12.3','drift':[]}


def verify(evidence,qualifier,expected_head=HEAD,expected_node_count=NODES):
    require(os.getuid()==1000,'verification must use actual test UID1000')
    evidence=Path(evidence).resolve();ready=read(evidence/'test-readiness.json');receipt=read(evidence/'qualification-receipt.json')
    require(ready['status']=='READY' and ready['source_commit']==expected_head and ready['source_sha256']==SOURCE and
            ready['collected_node_count']==expected_node_count and ready['drift']==[],'readiness/source/population differs')
    require(sha(qualifier)==ready['helper_sha256'],'frozen ordinary qualifier bytes differ from readiness')
    require(receipt['status']=='PASS','ordinary qualifier did not pass; original failure remains authoritative')
    os.environ['KICAD_ROUTE_STATE']=str(STATE);os.environ['PYTHONDONTWRITEBYTECODE']='1'
    sys.path.insert(0,str(ROOT/'src'))
    from kicad_route import common,engine,statemanifest,determinism
    require(sys.version.split()[0]=='3.12.3' and importlib.metadata.version('pytest')=='9.1.0' and
            importlib.metadata.version('jsonschema')=='4.26.0','system parser/test/Python environment differs')
    require(subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()==expected_head and
            not subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain','--untracked-files=no'],text=True).strip(),
            'current source HEAD/clean status differs')
    before=read(evidence/'test-installed-manifest-before.json')
    require(sha(evidence/'test-installed-manifest-before.json')==ready['manifest_sha256'],'readiness manifest bytes differ')
    manifest,runtime=active_runtime(common,engine,statemanifest,ready,before)
    manifest_sha=sha(STATE/'manifest.json')
    commands=read(evidence/'commands.json')
    expected={'smoke':['/usr/bin/python3',str(ROOT/'bin/kicad-route'),'--out',str(evidence/'full-smoke'),'smoke'],
              'determinism':['/usr/bin/python3',str(ROOT/'bin/kicad-route'),'--out',str(evidence/'repeat'),
                             'determinism','--backend','builtin','--runs','2','--budget','180','--default-clearance','0.4','--record']}
    require(commands['commands']==expected and commands['state']==str(STATE) and
            commands['source_commit']==expected_head and commands['source_sha256']==SOURCE,'ordinary command provenance differs')
    wanted_env={'HOME':'/testwork/home','CARGO_HOME':'/testwork/cargo','UV_CACHE_DIR':'/testwork/home/.cache/uv',
                'KICAD_ROUTE_STATE':str(STATE),'KICAD_ROUTE_LEDGER':'off','PYTHONDONTWRITEBYTECODE':'1'}
    require(commands['environment']==wanted_env,'ordinary invocation environment differs')
    phases=read(evidence/'phase-status.json')['phases']
    require(phases==receipt['phases'] and [row['name'] for row in phases]==['smoke','determinism'] and
            all(row['status']=='PASS' and row['exit_code']==0 and row['drift']==[] and row['argv']==expected[row['name']] for row in phases),
            'ordinary smoke/repeat terminal phase evidence differs or drifted')
    require(receipt['gates'] and all(row['passed'] is True for row in receipt['gates']),'original qualification gate failed')
    summaries=list((evidence/'full-smoke/smoke').glob('*/summary.json'))
    require(len(summaries)==1,'missing/extra ordinary full-smoke summary')
    summary_path=summaries[0];summary=read(summary_path)
    require(summary['status']=='PASS' and summary['pytest_exit_code']==0,'ordinary full smoke failed')
    nodes=read(evidence/'collection-nodes.json')
    require(len(nodes)==len(set(nodes))==expected_node_count,'preflight collection differs from declared exact unique base population')
    canonical={node_address(node)[0] for node in nodes}
    events=derived_subtests(ROOT/'src/kicad_route/router/tests/test_parser_legacy_tokens.py',canonical)
    population=verify_junit(summary_path.parent/'junit.xml',nodes,events)
    records=list((evidence/'repeat/determinism').glob('*/determinism.json'))
    require(len(records)==1,'missing/extra recorded determinism receipt')
    record_path=records[0];record=read(record_path)
    require(record['reproducible'] is True and record.get('record_error') is None and
            record['recorded_in']==str(STATE/'manifest.json') and record['backend']=='builtin' and len(record['runs'])==2,
            'ordinary determinism record did not pass/write exactly2 repeats')
    layers=[];identities=[];results=[];paths=[];flags=constants(ROOT/'src/kicad_route/cli.py')
    require(set(flags)=={'KRT_FLAGS','KRT_ENV','KRT_PROTECT_EXISTING_FLAGS','KRT_PROTECT_EXISTING_ENV'},'strict flag provenance missing')
    for run in record['runs']:
        path=Path(run['run_dir']);path=path if path.is_absolute() else evidence/'repeat'/path
        require(path.resolve().is_relative_to((evidence/'repeat').resolve()) and not path.is_symlink(),
                'repeat result outside newly declared output namespace')
        paths.append(str(path.resolve()));result=read(path/'result.json')
        require(result['exit_code']==0 and result['process']['status']=='PASS' and
                result['routing']['status']=='COMPLETE' and result['validation']['status']=='PASS' and
                not determinism.wall_clock_stops(result['process']),'raw repeat failed/incomplete/censored')
        require(result['validation']['preservation'] and all(value=='PASS' for value in result['validation']['preservation'].values()) and
                result['validation']['drc']['new_violations']['count']==0,'raw repeat native preservation/DRC failed')
        layer=determinism.layer_record(result);require(layer==run,'recorded layer differs from raw result')
        require(sha(result['candidate']['board'])==result['validation']['candidate_board_sha256']==result['evidence']['candidate_board_sha256'],
                'raw repeat native/evidence hashes do not bind final board')
        layers.append(layer);identities.append(require_repeat_identity(result,ready,before));command=check_backend_command(result,ready,flags)
        results.append({'result':str(path/'result.json'),'sha256':sha(path/'result.json'),'raw_layer':layer,
                        'state_manifest_sha256':result['tool_identity']['state_manifest_sha256'],'strict_backend_command':command})
        require(statemanifest.execution_build_id(result['tool_identity'],'builtin')==record['build_id'],
                'recorded build differs from actual raw execution')
    require(len(set(paths))==2,'determinism receipt repeats one result directory')
    comparison=determinism.compare(layers)
    require(comparison['reproducible'] is True and comparison['reasons']==[] and
            all(record['same'][key]==value for key,value in comparison['same'].items()) and
            record['same']['execution_build'] is True and identities[0]==identities[1],
            'independent raw geometry/outcome/build comparison failed')
    require(statemanifest.build_id(manifest,'builtin')==record['build_id'] and manifest['determinism']['krt']=={key:value for key,value in record.items() if key!='recorded_in'},
            'determinism record is not the current installed build record')
    require(sha(evidence/'test-installed-manifest-after.json')==manifest_sha==sha(STATE/'manifest.json') and
            str(common.router_generation(STATE))==ready['generation'],'final manifest/active generation changed or snapshot differs')
    require(receipt['generation']==ready['generation'] and receipt['source_commit']==expected_head and receipt['source_sha256']==SOURCE,
            'qualification receipt names different source/generation')
    mapping=evidence/'independent-junit-map.json'
    require(not mapping.exists(),'refusing to replace prior independent JUnit mapping')
    mapping.write_text(json.dumps(population,indent=2)+'\n')
    return {'schema':'kicad-route/independent-archon-test-verification/1','status':'PASS','verified_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
            'source_commit':expected_head,'source_sha256':SOURCE,'runtime':runtime,'expected_node_count':expected_node_count,
            'ordinary_qualifier':{'path':str(qualifier),'sha256':sha(qualifier)},
            'ordinary_qualification_receipt':{'path':str(evidence/'qualification-receipt.json'),'sha256':sha(evidence/'qualification-receipt.json')},
            'smoke':{'summary':str(summary_path),'junit':str(summary_path.parent/'junit.xml'),'junit_sha256':sha(summary_path.parent/'junit.xml'),
                     'exact_base_nodes':population['base_nodes'],'derived_subtest_events':population['derived_subtest_events'],
                     'rendered_subtest_rows':population['rendered_subtest_rows'],'testcase_rows':population['testcase_rows'],
                     'junit_aggregate':population['aggregate'],'mapping':str(mapping),'mapping_sha256':sha(mapping)},
            'determinism':{'record':str(record_path),'record_sha256':sha(record_path),'independent_comparison':comparison,
                           'distinct_raw_results':results,'actual_ready_backend':identities[0],'build_id':record['build_id'],
                           'current_generation_freshly_checked':True,'manifest_drift':[]},
            'helper_sha256':sha(__file__),'native_test_or_route_reruns':False,'production_source_or_state_mutations':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--evidence',type=Path,default=Path('/test-evidence'))
    parser.add_argument('--qualifier',type=Path);parser.add_argument('--out',type=Path)
    parser.add_argument('--expected-head',default=HEAD,help='Exact predeclared qualification checkout commit; readiness and all raw results must agree')
    parser.add_argument('--expected-node-count',type=int,default=NODES,help='Exact predeclared collected base-node count, excluding derived subtest events')
    args=parser.parse_args()
    require(len(args.expected_head)==40 and all(c in '0123456789abcdef' for c in args.expected_head),'expected HEAD must be exact full lowercase commit')
    require(args.expected_node_count>0,'expected node count must be positive')
    evidence=args.evidence.resolve();out=args.out or evidence/'independent-verification.json'
    qualifier=args.qualifier or evidence/'qualify-archon-tests.py'
    require(not out.exists(),'refusing to replace previous independent verification')
    try:result=verify(evidence,qualifier,args.expected_head,args.expected_node_count)
    except Exception as error:
        result={'schema':'kicad-route/independent-archon-test-verification/1','status':'FAIL',
                'verified_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'error':f'{type(error).__name__}: {error}',
                'evidence':str(evidence),'helper_sha256':sha(__file__),
                'native_test_or_route_reruns':False,'production_source_or_state_mutations':False}
    out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'report':str(out),'sha256':sha(out)}))
    return 0 if result['status']=='PASS' else 1


if __name__=='__main__':raise SystemExit(main())
