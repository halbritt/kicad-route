"""Bind the declared comparison only after both exact local runtimes exist."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path('/evidence')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def claim(p):return {'path':str(p),'sha256':sha(p)}
p=read(ROOT/'protocol-template.json')
attest=read(ROOT/'before-host-attestation.json')
preps={side:read(ROOT/('preparation-'+side)/'preparation.json') for side in ('reference','candidate')}
declared=read(ROOT/'qualification-plan-final.json')
assert declared['status']=='READY_FOR_IDENTITY_BINDING'
assert declared['comparison_mode']=='algorithm-change'
assert declared['candidate_source_sha256']!=declared['reference_source_sha256']
for side,prep in preps.items():
    assert prep['side']==side
    assert prep['checkout']=='/work/'+side
    assert prep['state']=='/work/state-'+side
    assert prep['source_commit']==declared[side+'_commit']
    assert prep['runtime']['source']['commit']==declared[side+'_commit']
    assert prep['runtime']['source']['source_sha256']==declared[side+'_source_sha256']

assert all(r['status']=='PASS' and all(g['passed'] for g in r['gates']) for r in preps.values())
assert preps['reference']['runtime']['packages']==preps['candidate']['runtime']['packages']
assert preps['reference']['runtime']['dependency_pyc_count']==preps['candidate']['runtime']['dependency_pyc_count']
p.update(status='PREREGISTERED_READY_NOT_STARTED',execution_ready=True,
 driver='/work/candidate/scripts/compare_router.py',harness='/evidence/run-archon-matrix.py',
 reference_cli='/work/reference/bin/kicad-route',candidate_cli='/work/candidate/bin/kicad-route',
 reference_state='/work/state-reference',candidate_state='/work/state-candidate',
 source_heads=[{'path':'/work/'+side,'head':preps[side]['source_commit']} for side in preps],
 cpu_affinity=attest['init_affinity'],allowed_existing_policy_quotas={},
 container_image_id=attest['image_id'],container_id=attest['container_id'],container_hostname=attest['container_hostname'],
 host_before_attestation=claim(ROOT/'before-host-attestation.json'),
 metadata_output='/evidence/archon-metadata',outer_log='/evidence/archon-matrix.log',
 host_after_attestation_path='/evidence/after-host-attestation.json',
 target_runtime={side:preps[side]['runtime'] for side in preps},
 preregistered_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
 retention_index={'script':'/evidence/index-archon-evidence.py','output':'/evidence/archon-evidence-index.json','schema':'kicad-route/retained-evidence-index/1'},
 launch_command='PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 /evidence/run-archon-matrix.py --protocol /evidence/archon-protocol.json > /evidence/archon-matrix.log 2>&1')
paths=[Path(p['driver']),ROOT/'run-archon-matrix.py',ROOT/'test_archon_matrix.py',ROOT/'harness-tests-final-boundary.log',ROOT/'prepare-runtime.py',ROOT/'capture-host.py',ROOT/'capture-container-tools.py',ROOT/'container-tools.json',ROOT/'index-archon-evidence.py',ROOT/'test_archon_index.py',ROOT/'transport-pytest.log',ROOT/'qualification-plan.json',ROOT/'qualification-plan-final.json',ROOT/'freeze-protocol.py',ROOT/'protocol-template.json']
for side,prep in preps.items():
 paths.extend([ROOT/('preparation-'+side)/'preparation.json',ROOT/('preparation-'+side)/'manifest.json',Path(prep['state'])/'manifest.json',Path(prep['runtime']['module'])])
 for name in ('bin/kicad-route','src/kicad_route/common.py','src/kicad_route/cli.py','src/kicad_route/engine.py'):
  paths.append(Path('/work')/side/name)
for board in p['boards']:
 folder=Path(board['project'])
 checkout=Path('/work/reference')
 tracked=subprocess.check_output(['git','-C',str(checkout),'ls-files','--',str(folder.relative_to(checkout))],text=True).splitlines()
 assert tracked, folder
 paths.extend(checkout/name for name in tracked)
p['hash_prerequisites']=[claim(path) for path in dict.fromkeys(paths)]
p['driver_sha256']=sha(p['driver']);p['harness_sha256']=sha(p['harness'])
output=ROOT/'archon-protocol.json'
assert not output.exists(),output
output.write_text(json.dumps(p,indent=2)+'\n')
print(json.dumps({'protocol':str(output),'sha256':sha(output),'reference':preps['reference']['source_commit'],'candidate':preps['candidate']['source_commit'],'candidate_source':preps['candidate']['runtime']['source']['source_sha256']}))
