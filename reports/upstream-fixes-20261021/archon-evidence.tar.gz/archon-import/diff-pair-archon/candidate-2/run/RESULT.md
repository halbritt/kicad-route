# Routing attempt: builtin on diff-pair

- Backend: builtin 0.23.1 (owned-89a2efbf5305)
- Input: `pair.kicad_pcb` from working tree @ 784fd6d5f7d9e0c9aeff3ebcebe970c96bc6570b (fingerprint a7d83a96e7699b7c)
- Scope: all, 3 nets; protect: existing; budget 180 s
- Candidate: `/evidence/diff-pair-archon/candidate-2/run/candidate/diff-pair/pair.kicad_pcb`

| Result | Status | Detail |
|---|---|---|
| process | PASS | exit 0, 2.578 s |
| routing | COMPLETE | 0 unconnected in scope, 0 total (input: 3) |
| validation | PASS | no new findings |

| Preservation check | Status |
|---|---|
| project_files | PASS |
| board_outline | PASS |
| layers | PASS |
| stackup | PASS |
| board_setup | PASS |
| nets_and_netclasses | PASS |
| pad_connectivity | PASS |
| footprints | PASS |
| zones | PASS |
| keepouts | PASS |
| copper_graphics | PASS |
| protected_copper | PASS |
| new_copper_netclass_geometry | PASS |
| routing_scope | PASS |
| net_completion | PASS |
| pour_integrity | PASS |

Differential pairs (lengths and skew in mm; native planar copper):

| P | N | Status | Width / gap | P length | N length | Skew | Gap violations |
|---|---|---|---|---|---|---|---|
| /CAN+ | /CAN- | ROUTED | 0.25 / 0.35 | 29.8125 | 29.8125 | 0.0 | 0 |

Native DRC (original rules and severities):

```json
{
 "violations_total": 0,
 "parity_total": 0,
 "new_violations": {
  "count": 0,
  "by_type": {},
  "by_severity": {}
 },
 "preexisting_violations": 0,
 "resolved_violations": 0,
 "new_parity": {
  "count": 0,
  "by_type": {},
  "by_severity": {}
 },
 "resolved_parity": 0
}
```

Unsupported or approximated by this backend:

- KRT reads only a subset of .kicad_dru custom rules; every rule is still graded by KiCad DRC
- KRT's cleanup may neck wide new segments near foreign pads without a flag; the new_copper_netclass_geometry check reports any new copper below its net class

Route statistics:

```json
{
 "new_tracks": 3,
 "new_vias": 0,
 "new_track_length_mm": 89.625,
 "new_track_length_mm_by_layer": {
  "F.Cu": 89.625
 },
 "new_copper_nets": 3,
 "removed_existing_tracks": 0,
 "removed_existing_vias": 0
}
```
