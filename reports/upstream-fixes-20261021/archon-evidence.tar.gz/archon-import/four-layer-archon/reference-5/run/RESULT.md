# Routing attempt: builtin on four-layer-plane

- Backend: builtin 0.23.1 (owned-c6c09054f684)
- Input: `four-layer-plane.kicad_pcb` from working tree @ 784fd6d5f7d9e0c9aeff3ebcebe970c96bc6570b (fingerprint fc7e1d7cb3efdd21)
- Scope: all, 2 nets; protect: existing; budget 180 s
- Candidate: `/evidence/four-layer-archon/reference-5/run/candidate/four-layer-plane/four-layer-plane.kicad_pcb`

| Result | Status | Detail |
|---|---|---|
| process | PASS | exit 0, 1.844 s |
| routing | COMPLETE | 0 unconnected in scope, 0 total (input: 5) |
| validation | PASS | no new findings |

| Preservation check | Status |
|---|---|
| project_files | PASS |
| board_outline | PASS |
| layers | PASS |
| stackup | PASS |
| board_setup | PASS |
| nets_and_netclasses | PASS |
| pad_connectivity | PASS |
| footprints | PASS |
| zones | PASS |
| keepouts | PASS |
| copper_graphics | PASS |
| protected_copper | PASS |
| new_copper_netclass_geometry | PASS |
| routing_scope | PASS |
| net_completion | PASS |
| pour_integrity | PASS |

Native DRC (original rules and severities):

```json
{
 "violations_total": 4,
 "parity_total": 0,
 "new_violations": {
  "count": 0,
  "by_type": {},
  "by_severity": {}
 },
 "preexisting_violations": 4,
 "resolved_violations": 0,
 "new_parity": {
  "count": 0,
  "by_type": {},
  "by_severity": {}
 },
 "resolved_parity": 0
}
```

Unsupported or approximated by this backend:

- KRT's cleanup may neck wide new segments near foreign pads without a flag; the new_copper_netclass_geometry check reports any new copper below its net class

Route statistics:

```json
{
 "new_tracks": 18,
 "new_vias": 1,
 "new_track_length_mm": 31.904,
 "new_track_length_mm_by_layer": {
  "F.Cu": 31.904
 },
 "new_copper_nets": 2,
 "removed_existing_tracks": 0,
 "removed_existing_vias": 0
}
```
