import datetime,hashlib,json,os,pathlib,shutil,subprocess,sys

def command(argv):return subprocess.check_output(argv,text=True,stderr=subprocess.STDOUT).strip()
def binary(path):
 p=pathlib.Path(path).resolve()
 return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
import pcbnew,_pcbnew
r={'schema':'kicad-route/archon-container-tools/1','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uname':list(os.uname()),'python_version':sys.version.split()[0],'python':binary(sys.executable),'kicad_version':command(['kicad-cli','--version']),'kicad_cli':binary(shutil.which('kicad-cli')),'pcbnew_build':pcbnew.GetBuildVersion(),'pcbnew_module':binary(_pcbnew.__file__),'os_release':pathlib.Path('/etc/os-release').read_text(),'affinity':sorted(os.sched_getaffinity(0)),'nice':os.getpriority(os.PRIO_PROCESS,0),'scheduler':os.sched_getscheduler(0),'cgroup':pathlib.Path('/proc/self/cgroup').read_text(),'meminfo':pathlib.Path('/proc/meminfo').read_text(),'tools':{}}
for name,args in [('rustc',['rustc','-vV']),('cargo',['cargo','--version']),('uv',['uv','--version']),('gcc',['gcc','--version']),('glibc',['ldd','--version']),('gnu_time',['/usr/bin/time','--version'])]:
 path=command(['rustup','which',name]) if name in ('rustc','cargo') else shutil.which(args[0])
 r['tools'][name]={'version':command(args),'binary':binary(path)}
pathlib.Path('/evidence/container-tools.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
