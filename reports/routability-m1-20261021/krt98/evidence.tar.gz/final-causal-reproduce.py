import ast
import json
from pathlib import Path
import subprocess
from kicad_route import cli, common, provenance

base_commit = '3ae2c036d1f5ba8d0b717adc0db7a5f42c53fe5b'
source = subprocess.check_output(['git', 'show', f'{base_commit}:src/kicad_route/provenance.py'], text=True)
node = next(node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef) and node.name == 'net_completion')
namespace = {'common': common}
exec(compile(ast.Module(body=[node], type_ignores=[]), 'pre-98-provenance.py', 'exec'), namespace)
roots = sorted({p.resolve() for p in Path('/tmp/pytest-of-halbritt').glob('pytest-*/test_partial_net_cannot_swap_j0')}, key=lambda p: p.stat().st_mtime, reverse=True)
for root in roots:
    after_path = root / 'after-components.json'
    before_paths = list(root.rglob('baseline-terminals.json'))
    if not after_path.exists() or not before_paths:
        continue
    before_path = before_paths[0]
    before, after = common.load_json(before_path), common.load_json(after_path)
    if not before or not after or 'nets' not in before or 'nets' not in after:
        continue
    def numbers(facts):
        return sorted(sorted(facts['inventory'][uid]['number'] for uid in group) for group in facts['nets']['N0000'])
    if numbers(before) != [['1','2'],['3']] or numbers(after) != [['1'],['2','3']]:
        continue
    raw_before_path = before_path.parent/'baseline-drc.json'
    raw_after_path = root/'after/candidate-drc.json'
    raw_before, raw_after = common.load_json(raw_before_path), common.load_json(raw_after_path)
    old = namespace['net_completion'](raw_before, raw_after, common.load_json(root/'facts.json'), cli.item_nets)
    new = provenance.net_completion(before, after)
    assert old['status'] == common.PASS and new['status'] == common.FAIL
    result = {'baseline_commit':base_commit,'fixture':str(root),
              'native_partitions_by_pad_number':{'before':numbers(before),'after':numbers(after)},
              'native_partitions_by_uuid':{'before':before['nets'],'after':after['nets']},
              'raw_open_counts':[len(raw_before['unconnected_items']),len(raw_after['unconnected_items'])],
              'old_result':old,'new_result':new,'producer':before['identity']['producer'],
              'artifacts':{str(p):common.sha256(p) for p in (before_path,after_path,raw_before_path,raw_after_path)}}
    Path('/tmp/krt98-causal-reproduction.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({key:result[key] for key in ('fixture','native_partitions_by_pad_number','raw_open_counts','old_result','new_result')},indent=2))
    break
else:
    raise SystemExit('No verified native partial-swap fixture found')
