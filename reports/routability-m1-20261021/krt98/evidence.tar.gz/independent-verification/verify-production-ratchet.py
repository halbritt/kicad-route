"""Exercise the production preservation ratchet without recomputing native clusters."""
import copy
import hashlib
import json
from pathlib import Path
from kicad_route import provenance

ROOT = Path(__file__).resolve().parent
source = Path(provenance.__file__)
source_sha = hashlib.sha256(source.read_bytes()).hexdigest()
facts = {role: json.loads((ROOT / (role + '-production-terminals.json')).read_text()) for role in ('origin', 'r0', 'fr')}
cases = []
for before, after, expected_count in [('origin', 'r0', 53), ('origin', 'fr', 53), ('r0', 'fr', 203)]:
    result = provenance.net_completion(facts[before], facts[after])
    cases.append({'scenario': before + ' to ' + after, 'result': result,
                  'passed': result['status'] == 'PASS' and result['nets_connected_in_input'] == expected_count
                  and result['nets_lost'] == [] and result['split_components'] == []})
for before, after in [(None, facts['r0']), (facts['origin'], None)]:
    result = provenance.net_completion(before, after)
    cases.append({'scenario': 'missing native coverage', 'result': result,
                  'passed': result['status'] == 'NOT_RUN' and result['nets_connected_in_input'] is None})
# Preserve the full native terminal inventory but deliberately split one previously
# connected group on a net that was already incomplete. An old whole-net-only
# ratchet cannot detect this regression. These are in-memory synthetic challenges.
reference = facts['origin']
net, group = next((net, group) for net, groups in reference['nets'].items() if len(groups) > 1
                  for group in groups if len(group) > 1)
candidate = copy.deepcopy(reference)
candidate['nets'][net].remove(group)
candidate['nets'][net].extend([[group[0]], group[1:]])
result = provenance.net_completion(reference, candidate)
cases.append({'scenario': 'split preserved group within already-incomplete net', 'net': net,
              'group': group, 'result': result, 'passed': result['status'] == 'FAIL'
              and result['nets_lost'] == [] and len(result['split_components']) == 1 and net in result['detail']})
# Joining components is valid, even when another separate component remains.
candidate = copy.deepcopy(reference)
groups = candidate['nets'][net]
groups[:2] = [groups[0] + groups[1]]
result = provenance.net_completion(reference, candidate)
cases.append({'scenario': 'join partial components', 'result': result, 'passed': result['status'] == 'PASS'})
report = {'schema': 'kicad-route/independent-native-ratchet-verification/1',
          'source': str(source), 'source_sha256': source_sha,
          'source_unchanged': source_sha == hashlib.sha256(source.read_bytes()).hexdigest(),
          'cases': cases, 'passed': all(case['passed'] for case in cases)}
(ROOT / 'production-ratchet-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'passed': report['passed'], 'source_sha256': source_sha, 'cases': [{'scenario': c['scenario'], 'status': c['result']['status'], 'passed': c['passed']} for c in cases]}, indent=2))
