"""Compare the production native extractor to frozen, independently audited partitions."""
from pathlib import Path
import hashlib
import json
import subprocess
import time
from kicad_route import native_components

ROOT = Path(__file__).resolve().parent
expected = json.loads((ROOT / 'expected.json').read_text())
source_root = native_components.KICAD_SCRIPT.parents[1]
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
producer_before = native_components.producer_identity()
head = subprocess.run(['git', '-C', str(source_root), 'rev-parse', 'HEAD'], capture_output=True, text=True, check=True).stdout.strip()
assert head == '37497a09dc59a31d9bac8d9272cad741675e8dee', head
assert producer_before['native_components.py'] == 'fc5099d821f972212b0a2e30bfb15b9755336684902cea933d6db88446b361e0'
records = []
for board in expected['boards']:
    role = board['role']
    path = Path(board['directory']) / 'ca2.kicad_pcb'
    before = {p.name: sha(p) for p in path.parent.iterdir() if p.is_file()}
    started = time.monotonic()
    facts, rec = native_components.extract(path, ROOT / (role + '-production-terminals.json'), board['board_sha256'])
    elapsed = time.monotonic() - started
    actual = {net: sorted(sorted(c) for c in groups) for net, groups in facts.get('nets', {}).items()}
    target = board['partitions']
    differences = {net: {'expected': target.get(net), 'actual': actual.get(net)}
                   for net in set(target) | set(actual) if target.get(net) != actual.get(net)}
    unchanged = before == {p.name: sha(p) for p in path.parent.iterdir() if p.is_file()}
    row = {'role': role, 'status': facts['status'], 'reasons': facts.get('reasons'),
           'duration_s': elapsed, 'board_sha256': sha(path), 'unchanged': unchanged,
           'net_population': len(actual), 'incomplete_nets': sum(len(c) > 1 for c in actual.values()),
           'complete_nets': sum(len(c) == 1 for c in actual.values()),
           'component_deficit': sum(max(0, len(c) - 1) for c in actual.values()),
           'partition_mismatches': differences, 'command': rec,
           'passed': facts['status'] == 'PASS' and not differences and unchanged and elapsed < 60}
    records.append(row)
    print(json.dumps({k: v for k, v in row.items() if k not in ('command', 'partition_mismatches')}), flush=True)
producer_after = native_components.producer_identity()
report = {'schema': 'kicad-route/independent-native-verification/1', 'state': 'frozen-production-candidate',
          'source_head': head, 'producer_before': producer_before, 'producer_after': producer_after,
          'source_unchanged': producer_before == producer_after, 'expected_sha256': sha(ROOT / 'expected.json'),
          'results': records, 'passed': producer_before == producer_after and all(r['passed'] for r in records)}
(ROOT / 'production-extractor-verification.json').write_text(json.dumps(report, indent=2) + '\n')
