"""Public contract probes for malformed native evidence shapes, with no extraction."""
from pathlib import Path
import copy,json
from kicad_route import common,native_components,provenance
ROOT=Path(__file__).resolve().parent
ref=json.loads((ROOT/'origin-production-terminals.json').read_text())
cand=json.loads((ROOT/'r0-production-terminals.json').read_text())
cases=[]
for label in ['rules-list','native-cli-string','pcbnew-string','board-hash-number','footprint-list','pad-number-list']:
 before,after=copy.deepcopy(ref),copy.deepcopy(cand)
 for facts in [before,after]:
  if label=='rules-list':facts['identity']['rules']=['malformed-rules']
  elif label=='native-cli-string':facts['identity']['kicad_cli']='not-a-native-tool-identity'
  elif label=='pcbnew-string':facts['identity']['pcbnew']=facts['native_identity']='not-a-pcbnew-identity'
  elif label=='board-hash-number':facts['identity']['board_sha256']=facts['board_sha256_before']=facts['board_sha256_after']=7
  else:
   pad=next(iter(facts['inventory'].values()))
   pad['footprint' if label=='footprint-list' else 'number']=[]
   facts['inventory_sha256']=common.sha256_of(facts['inventory'])
 try:
  result=provenance.net_completion(before,after)
  cases.append({'scenario':label,'status':result['status'],'passed':result['status']=='NOT_RUN'})
 except Exception as exc:
  cases.append({'scenario':label,'exception':type(exc).__name__,'message':str(exc),'passed':False})
report={'candidate':'8d866f65ac9ee2e50c2a83b6303663c3d5c99dff','producer':native_components.producer_identity(),'cases':cases}
(ROOT/'typed-guard-challenges.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
