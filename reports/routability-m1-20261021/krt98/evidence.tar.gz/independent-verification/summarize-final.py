"""Seal selected independent acceptance results for the frozen KICADROUTE-98 tip."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parent
AUDIT=ROOT.parent/'krt91-audit-agent507'
SOURCE=Path('/home/halbritt/.cache/agent-worktrees/kicad-route/krt98-native-terminals')
PIN='8d866f65ac9ee2e50c2a83b6303663c3d5c99dff'
NATIVE_PROOF_PIN='37497a09dc59a31d9bac8d9272cad741675e8dee'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
head=subprocess.run(['git','-C',str(SOURCE),'rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
assert head==PIN
assert not subprocess.run(['git','-C',str(SOURCE),'status','--porcelain'],capture_output=True,text=True,check=True).stdout
expected=read(ROOT/'expected.json')
reports={name:read(ROOT/name) for name in ['production-extractor-verification.json','production-coverage-verification.json','production-ratchet-verification.json','typed-guard-challenges.json']}
checks={name:(r.get('passed') if 'passed' in r else all(case['passed'] for case in r['cases'])) for name,r in reports.items()}
assert all(checks.values())
assert reports['production-extractor-verification.json']['source_head']==NATIVE_PROOF_PIN
changed=subprocess.run(['git','-C',str(SOURCE),'diff','--name-only',NATIVE_PROOF_PIN,PIN],capture_output=True,text=True,check=True).stdout.splitlines()
assert changed==['src/kicad_route/provenance.py'],changed
source_names=['native_components.py','kicad/native_components.py','kicad/facts.py','provenance.py','baselinecache.py']
sources={name:sha(SOURCE/'src/kicad_route'/name) for name in source_names}
assert all(sources[name]==digest for name,digest in reports['production-extractor-verification.json']['producer_after'].items())
assert sources['provenance.py']==reports['production-ratchet-verification.json']['source_sha256']
assert reports['production-extractor-verification.json']['source_unchanged']
assert reports['production-coverage-verification.json']['producer_unchanged']
assert reports['production-ratchet-verification.json']['source_unchanged']
facts={role:read(ROOT/(role+'-production-terminals.json')) for role in ('origin','r0','fr')}
partial=[(name,c) for name,groups in facts['origin']['nets'].items() if len(groups)>1 for c in groups if len(c)>1]
assert len(partial)==5
partial_checks={role:all(any(set(c)<=set(after) for after in facts[role]['nets'][net]) for net,c in partial) for role in ['r0','fr']}
assert all(partial_checks.values())
false_losses={net:{role:len(facts[role]['nets'][net]) for role in facts} for net in expected['false_loss_nets']}
assert len(false_losses)==10 and all(row['origin']>1 for row in false_losses.values())
unchanged=[]
for b in expected['boards']:
 for name,digest in b['files'].items():
  for label,path in [('archived_input',AUDIT/'snapshots'/b['role']/name),('isolated_input',Path(b['directory'])/name)]:
   unchanged.append({'kind':label,'path':str(path),'sha256':sha(path),'unchanged':sha(path)==digest})
for item in ['source_audit','source_summary']:
 record=expected[item];unchanged.append({'kind':item,'path':record['path'],'sha256':sha(record['path']),'unchanged':sha(record['path'])==record['sha256']})
raw=[]
for historical in read(AUDIT/'baseline-counts.json')['historical']:
 for name in ['raw_reference','raw_candidate']:
  record=historical[name];p=Path(record['path']);report=read(p)
  raw.append({'path':str(p),'sha256':sha(p),'unchanged':sha(p)==record['sha256'],'native_unconnected_entries':len(report['unconnected_items'])})
assert all(record['unchanged'] for record in [*unchanged,*raw])
summary={'schema':'kicad-route/independent-historical-reconciliation-verification/1','candidate':PIN,'native_graph_proof_reused_from':NATIVE_PROOF_PIN,'native_graph_proof_reuse_reason':'git diff changes only provenance diagnostic text; all three native producer hashes and baseline cache hash unchanged; public ratchet including affected-net name rerun', 'prior_summary':{'path':'superseded-37497a0/summary.json','sha256':sha(ROOT/'superseded-37497a0/summary.json')},'state':'independent checks PASS; parent composed gate owns release','producer_source_sha256':sources,'reports':{name:{'sha256':sha(ROOT/name),'passed':passed} for name,passed in checks.items()},'historical_native_results':[{k:r[k] for k in ['role','board_sha256','net_population','complete_nets','incomplete_nets','component_deficit','duration_s','passed']} for r in reports['production-extractor-verification.json']['results']],'ten_false_loss_component_counts':false_losses,'partial_connected_groups_on_incomplete_origin_nets':len(partial),'partial_groups_preserved':partial_checks,'raw_historical_reports':raw,'unchanged_archived_and_isolated_inputs':unchanged,'origin_reconciliation':{'actual_complete_nets':53,'actual_incomplete_nets':182,'terminal_component_deficit':686,'capped_drc_connections':499,'audited_drc_incomplete_net_names':80,'incorrect_complete_count_from_capped_report':155,'actual_origin_complete_nets_lost':0},'scope':'production extraction on isolated copies, public coverage/ratchet challenges on in-memory evidence; no target routing, native DRC/refill rerun, source edit, policy change or historical receipt mutation','independent_acceptance_passed':True}
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'candidate':PIN,'independent_acceptance_passed':True,'sources':sources,'report_sha256':sha(ROOT/'summary.json'),'standard_coverage_cases':len(reports['production-coverage-verification.json']['cases']),'ratchet_cases':len(reports['production-ratchet-verification.json']['cases']),'typed_guard_cases':len(reports['typed-guard-challenges.json']['cases']),'raw_histories_and_inputs_unchanged':True},indent=2))
