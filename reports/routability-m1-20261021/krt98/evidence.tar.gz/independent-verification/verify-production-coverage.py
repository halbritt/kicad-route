"""Challenge public coverage admission using retained extractor evidence."""
from pathlib import Path
import copy
import json
from kicad_route import native_components as native

ROOT = Path(__file__).resolve().parent
origin = json.loads((ROOT / 'origin-production-terminals.json').read_text())
r0 = json.loads((ROOT / 'r0-production-terminals.json').read_text())
source = native.producer_identity()
cases = []
def check(name, accepted):
    cases.append({'scenario': name, 'accepted': accepted, 'passed': accepted is False})
check('missing coverage', native.compatible(None, r0))
for field, value in [('schema', 999), ('status', 'NOT_RUN'), ('identity', None),
                     ('inventory_sha256', 'stale-seal'), ('jumpers_sha256', 'stale-seal')]:
    stale = copy.deepcopy(r0)
    stale[field] = value
    check('missing or stale ' + field, native.compatible(origin, stale))
stale = copy.deepcopy(r0)
stale['board_sha256_before'] = '0' * 64
check('stale board evidence', native.compatible(origin, stale))
for key in ('rules', 'producer', 'pcbnew', 'kicad_cli'):
    stale = copy.deepcopy(r0)
    stale['identity'][key] = {'stale': True}
    check('stale ' + key, native.compatible(origin, stale))
for mode in ('missing-pad', 'duplicated-pad', 'invented-pad', 'changed-net'):
    malformed = copy.deepcopy(r0)
    name = next(name for name, groups in malformed['nets'].items() if len(groups[0]) > 1)
    if mode == 'missing-pad':
        malformed['nets'][name][0].pop()
    elif mode == 'duplicated-pad':
        malformed['nets'][name][0].append(malformed['nets'][name][0][0])
    elif mode == 'invented-pad':
        malformed['nets'][name][0][0] = 'not-a-real-native-pad'
    else:
        uid = malformed['nets'][name][0][0]
        malformed['inventory'][uid]['net'] = 'different-net'
    check(mode, native.compatible(origin, malformed))
facts, rec = native.extract(ROOT / 'snapshots/origin/ca2.kicad_pcb', ROOT / 'wrong-graded-sha-terminals.json', '0' * 64)
cases.append({'scenario': 'board differs from expected graded hash', 'status': facts['status'],
              'reasons': facts['reasons'], 'passed': facts['status'] == 'NOT_RUN' and not native.coverage(facts)})
report = {'schema': 'kicad-route/independent-native-coverage-verification/1',
          'producer': source, 'producer_unchanged': source == native.producer_identity(),
          'unmodified_origin_r0_compatible': native.compatible(origin, r0),
          'cases': cases, 'passed': all(case['passed'] for case in cases)}
(ROOT / 'production-coverage-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
