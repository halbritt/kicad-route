from pathlib import Path
import json,hashlib,shutil,time
import pcbnew
OUT=Path(__file__).resolve().parent
raw=json.loads((OUT/'baseline-counts.json').read_text()); lost=raw['historical'][0]['lost_nets']; results=[]
boards=[('origin',raw['historical'][0]['files']['reference']),('r0',raw['historical'][0]['files']['candidate']),('fr',raw['historical'][1]['files']['candidate'])]
for role,files in boards:
 t=time.monotonic(); dest=OUT/'snapshots'/role;dest.mkdir(parents=True,exist_ok=True)
 for f in files:
  if Path(f['path']).suffix not in {'.kicad_pcb','.kicad_pro','.kicad_dru'}:continue
  shutil.copyfile(f['path'],dest/Path(f['path']).name)
 boardpath=next(dest.glob('*.kicad_pcb'));digest=hashlib.sha256(boardpath.read_bytes()).hexdigest();b=pcbnew.LoadBoard(str(boardpath));b.BuildConnectivity();cn=b.GetConnectivity(); row={'role':role,'board':str(boardpath),'sha256':digest,'nets':{},'rule_areas':[]}
 pads={}
 for f in b.GetFootprints():
  for p in f.Pads():
   if p.GetNetname() in lost:pads.setdefault(str(p.GetNetname()),[]).append((f.GetReference(),p))
 for net,pairs in sorted(pads.items()):
  terminals=[];components=set()
  for ref,p in sorted(pairs,key=lambda rp:(rp[0],rp[1].GetNumber())):
   connected=sorted({i.m_Uuid.AsString() for i in cn.GetConnectedItems(p) if i.GetClass()=='PAD'})
   components.add(tuple(connected))
   terminals.append({'ref':ref,'pad':p.GetNumber(),'uuid':p.m_Uuid.AsString(),'position_nm':[p.GetPosition().x,p.GetPosition().y],'net':net,'connected_pad_uuids':connected})
  row['nets'][net]={'terminal_components':len(components),'components_pad_uuids':[list(x) for x in sorted(components)],'terminals':terminals}
 for f,zs in [('BOARD',b.Zones())]+[(f.GetReference(),f.Zones()) for f in b.GetFootprints()]:
  for z in zs:
   if not z.GetIsRuleArea():continue
   row['rule_areas'].append({'owner':f,'uuid':z.m_Uuid.AsString(),'name':z.GetZoneName(),'layers':[b.GetLayerName(l) for l in z.GetLayerSet().Seq()],'no_tracks':z.GetDoNotAllowTracks(),'no_vias':z.GetDoNotAllowVias(),'no_zone_fills':z.GetDoNotAllowZoneFills()})
 row['duration_seconds']=time.monotonic()-t
 assert digest==hashlib.sha256(boardpath.read_bytes()).hexdigest()
 results.append(row)
(OUT/'terminal-components.json').write_text(json.dumps({'method':'KiCad10.0.7 pcbnew.LoadBoard; BuildConnectivity; GetConnectedItems(pad, flags=0), matching-net native clusters including zones; saved fills unchanged; source code retained beside evidence. No DRC rerun or route.', 'boards':results},indent=2)+'\n')
for r in results:print(r['role'],r['sha256'],round(r['duration_seconds'],3),{n:d['terminal_components'] for n,d in r['nets'].items()},'rule_areas',len(r['rule_areas']))
