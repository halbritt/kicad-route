from pathlib import Path
from collections import Counter
import json,hashlib,sys
sys.path.insert(0,'/home/halbritt/git/kicad-route/src')
from kicad_route.netnames import nets_in_description
B=Path('/home/halbritt/.cache/agent499-microsd/iter8d/route/runs/candidate')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source(p):return {'path':str(p),'sha256':sha(p)}
def nets(u,known):return {n for i in u['items'] for n in nets_in_description(i['description'],known)}
report={'historical':[]}
for n in ['iter8d-campaign-r0','iter8d-fr-leftovers']:
 p=(B/n/'latest').resolve(); a=json.loads((p/'attempt.json').read_text()); facts=json.loads((p/'facts/reference-facts.json').read_text());known=set(facts['nets']);bp=(p/a['baseline']['report']).resolve(); cp=p/'validate/candidate-drc.json'; bd=json.loads(bp.read_text());cd=json.loads(cp.read_text()); before={x for u in bd['unconnected_items'] for x in nets(u,known)};after={x for u in cd['unconnected_items'] for x in nets(u,known)};lost=sorted((known-before)&after)
 row={'run':str(p),'input':json.loads((p/'snapshot.json').read_text()),'raw_reference':source(bp),'raw_candidate':source(cp),'input_connections':len(bd['unconnected_items']),'input_incomplete_nets':len(before),'candidate_connections':len(cd['unconnected_items']),'candidate_incomplete_nets':len(after),'candidate_violations':dict(Counter(v['type'] for v in cd['violations'])),'lost_nets':lost,'lost_items':{n:[u for u in cd['unconnected_items'] if n in nets(u,known)] for n in lost},'input_refill':json.loads((bp.parent/'baseline-info.json').read_text())['refill'],'files':{}}
 for role in ['reference','candidate']:
  row['files'][role]=[source(q) for q in sorted((p/role/'candidate').iterdir()) if q.is_file()]
 report['historical'].append(row)
Path('/tmp/krt91-baseline-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps([{k:v for k,v in r.items() if k in ['run','raw_reference','raw_candidate','input_connections','input_incomplete_nets','candidate_connections','candidate_incomplete_nets','candidate_violations','lost_nets','input_refill']} for r in report['historical']],indent=2))
