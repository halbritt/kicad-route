from pathlib import Path
import json,hashlib,time
import pcbnew
OUT=Path(__file__).resolve().parent
result=[]
for role in ['origin','r0','fr']:
 t=time.monotonic(); p=next((OUT/'snapshots'/role).glob('*.kicad_pcb'));b=pcbnew.LoadBoard(str(p));b.BuildConnectivity();cn=b.GetConnectivity();by_net={}
 for f in b.GetFootprints():
  for pad in f.Pads():
   if pad.GetNetCode()>0:by_net.setdefault(pad.GetNetname(),[]).append(pad)
 counts={}
 for n,pads in sorted(by_net.items()):
  seen=set();components=[]
  for pad in pads:
   uid=pad.m_Uuid.AsString()
   if uid in seen:continue
   s={i.m_Uuid.AsString() for i in cn.GetConnectedItems(pad) if i.GetClass()=='PAD'};seen.update(s);components.append(sorted(s))
  counts[n]={'pad_count':len(pads),'components':components}
 row={'role':role,'pcb_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'duration_s':time.monotonic()-t,'nets_with_terminals':len(counts),'incomplete_terminal_nets':sum(len(r['components'])>1 for r in counts.values()),'terminal_component_deficit':sum(max(0,len(r['components'])-1) for r in counts.values()),'nets':counts};result.append(row)
 print({k:v for k,v in row.items() if k!='nets'})
(OUT/'all-native-terminal-components.json').write_text(json.dumps(result,indent=2)+'\n')
